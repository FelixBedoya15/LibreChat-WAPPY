$ErrorActionPreference = "Stop"
Write-Host "================================================================" -ForegroundColor Cyan
Write-Host "  🟣 INSTALADOR OFICIAL WAPPY DOTS + TENSHI IA (Windows 10/11)" -ForegroundColor Green
Write-Host "  Motor de Voz 24kHz · Hermes Core · Team de Agentes · Web HUD" -ForegroundColor Cyan
Write-Host "================================================================"
$ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
$WappyHome = Join-Path $env:USERPROFILE ".wappy"
$TunnelDir = Join-Path $WappyHome "tunnel"
$MemoryDir = Join-Path $WappyHome "memory"

if (-not (Get-Command bun -ErrorAction SilentlyContinue)) {
  Write-Host "⚡ Instalando Bun Runtime para Windows..." -ForegroundColor Yellow
  powershell -c "irm bun.sh/install.ps1 | iex"
  $env:Path = "$env:USERPROFILE\.bun\bin;$env:Path"
}

New-Item -ItemType Directory -Force -Path $TunnelDir, $MemoryDir | Out-Null
Copy-Item -Path "$ScriptDir\wappy-tunnel\*" -Destination $TunnelDir -Recurse -Force
if (Test-Path "$ScriptDir\wappy-tunnel\.env") {
  Copy-Item -Path "$ScriptDir\wappy-tunnel\.env" -Destination "$TunnelDir\.env" -Force
}
Copy-Item -Path "$ScriptDir\wappy-memory\*" -Destination $MemoryDir -Recurse -Force -ErrorAction SilentlyContinue

Set-Location $TunnelDir
bun install

Write-Host "🚀 Iniciando Túnel Wappy Dots + Tenshi en http://localhost:3001 ..." -ForegroundColor Green
Start-Process -FilePath "bun" -ArgumentList "run server/src/gemini-tunnel/standalone-server.ts" -WorkingDirectory $TunnelDir -WindowStyle Hidden
Start-Sleep -Seconds 3
Start-Process "http://localhost:3001/api/gemini-tunnel/mobile/app"
Write-Host "✅ ¡Wappy Dots + Tenshi activo en tu equipo Windows!" -ForegroundColor Green
