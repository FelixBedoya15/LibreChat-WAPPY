#!/usr/bin/env bash
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"

echo "================================================================"
echo "  🟣 INSTALADOR OFICIAL WAPPY DOTS + TENSHI IA (macOS)"
echo "  Isla Dinámica en tu Notch · Voz 24kHz · Hermes Autonomous Core"
echo "================================================================"
echo ""

# 1. Verificar o instalar Bun
if ! command -v bun >/dev/null 2>&1 && [ ! -x "$HOME/.bun/bin/bun" ]; then
  echo "⚡ Instalando motor Bun Runtime..."
  curl -fsSL https://bun.sh/install | bash
fi
export PATH="$HOME/.bun/bin:/opt/homebrew/bin:/usr/local/bin:$PATH"

# 2. Instalar ~/.wappy/tunnel y ~/.wappy/memory
echo "🧠 Configurando cerebro autónomo Tenshi en ~/.wappy/tunnel..."
mkdir -p "$HOME/.wappy/tunnel" "$HOME/.wappy/memory" "$HOME/.wappy/skills" "$HOME/.wappy/logs"
cp -R "$DIR/wappy-tunnel/"* "$HOME/.wappy/tunnel/"
if [ -f "$DIR/wappy-tunnel/.env" ] && [ ! -f "$HOME/.wappy/tunnel/.env" ]; then
  cp "$DIR/wappy-tunnel/.env" "$HOME/.wappy/tunnel/.env"
fi
cp -n "$DIR/wappy-memory/"*.md "$HOME/.wappy/memory/" 2>/dev/null || true

cd "$HOME/.wappy/tunnel"
bun install

# 3. Instalar Wappy Dots.app en /Applications
if [ -d "$DIR/Wappy Dots.app" ]; then
  echo "🏝️ Instalando Wappy Dots.app en /Applications..."
  killall "Coucou" "Wappy Dots" 2>/dev/null || true
  rm -rf "/Applications/Wappy Dots.app"
  cp -R "$DIR/Wappy Dots.app" "/Applications/Wappy Dots.app"
  xattr -cr "/Applications/Wappy Dots.app" || true
  codesign --force --deep --sign - "/Applications/Wappy Dots.app" 2>/dev/null || true
fi

# 4. Configurar auto-arranque del Túnel en segundo plano (LaunchAgent)
PLIST="$HOME/Library/LaunchAgents/com.wappy.gemini-tunnel.plist"
BUN_BIN="$(command -v bun || echo "$HOME/.bun/bin/bun")"
mkdir -p "$HOME/Library/LaunchAgents"
cat <<PLIST_EOF > "$PLIST"
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key>
  <string>com.wappy.gemini-tunnel</string>
  <key>ProgramArguments</key>
  <array>
    <string>${BUN_BIN}</string>
    <string>run</string>
    <string>${HOME}/.wappy/tunnel/server/src/gemini-tunnel/standalone-server.ts</string>
  </array>
  <key>WorkingDirectory</key>
  <string>${HOME}/.wappy/tunnel</string>
  <key>RunAtLoad</key>
  <true/>
  <key>KeepAlive</key>
  <true/>
  <key>StandardOutPath</key>
  <string>${HOME}/.wappy/logs/tunnel.log</string>
  <key>StandardErrorPath</key>
  <string>${HOME}/.wappy/logs/tunnel.err.log</string>
</dict>
</plist>
PLIST_EOF

launchctl unload "$PLIST" 2>/dev/null || true
launchctl load "$PLIST" 2>/dev/null || true

echo "🚀 Abriendo Wappy Dots..."
open "/Applications/Wappy Dots.app"

echo ""
echo "✅ ¡Instalación completada! Di «Oye Tenshi» o acerca el cursor al Notch superior."
