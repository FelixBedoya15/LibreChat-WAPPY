#!/usr/bin/env bash
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"

echo "================================================================"
echo "  🟣 INSTALADOR OFICIAL WAPPY DOTS + TENSHI IA (Linux)"
echo "  Motor de Voz 24kHz · Hermes Core · Team de Agentes · Web HUD"
echo "================================================================"

if ! command -v bun >/dev/null 2>&1 && [ ! -x "$HOME/.bun/bin/bun" ]; then
  echo "⚡ Instalando Bun Runtime..."
  curl -fsSL https://bun.sh/install | bash
fi
export PATH="$HOME/.bun/bin:/usr/local/bin:$PATH"

mkdir -p "$HOME/.wappy/tunnel" "$HOME/.wappy/memory" "$HOME/.wappy/skills" "$HOME/.wappy/logs"
cp -R "$DIR/wappy-tunnel/"* "$HOME/.wappy/tunnel/"
if [ -f "$DIR/wappy-tunnel/.env" ] && [ ! -f "$HOME/.wappy/tunnel/.env" ]; then
  cp "$DIR/wappy-tunnel/.env" "$HOME/.wappy/tunnel/.env"
fi
cp -n "$DIR/wappy-memory/"*.md "$HOME/.wappy/memory/" 2>/dev/null || true

cd "$HOME/.wappy/tunnel"
bun install

nohup bun run server/src/gemini-tunnel/standalone-server.ts > "$HOME/.wappy/logs/tunnel.log" 2>&1 &
sleep 2
if command -v xdg-open >/dev/null 2>&1; then
  xdg-open "http://localhost:3001/api/gemini-tunnel/mobile/app" || true
fi
echo "✅ ¡Wappy Dots + Tenshi activo en http://localhost:3001/api/gemini-tunnel/mobile/app !"
