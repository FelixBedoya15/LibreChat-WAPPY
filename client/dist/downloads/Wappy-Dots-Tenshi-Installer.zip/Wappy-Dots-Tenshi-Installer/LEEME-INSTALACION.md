# 🟣 Wappy Dots + Tenshi IA — Instalador Oficial Multiplataforma (v2.6.0)

Este paquete contiene la versión completa de **Wappy Dots** y **Tenshi IA** con todas las mejoras más recientes:
- **Isla Dinámica Nativa (macOS Notch HUD)** con activación por voz (`"Oye Tenshi"`, `"Hola Tenshi"`, `"Tenshi"`) y respuesta en **Voz Viva 24 kHz (Gemini Live Sol/Aoede)**.
- **Núcleo Autónomo Estilo Hermes & OpenClaw (`wappy-autonomous-core.ts`)**: Memoria persistente en dos capas (`SOUL.md`, `USER.md`, `MEMORY.md`), buscador episódico **SQLite FTS5 BM25**, auto-aprendizaje de **Skills (`SKILL.md`)**, compresión automática de contexto y Cron autónomo.
- **Team de Agentes en Paralelo (`agent-team-orchestrator.ts`)**: Especialistas simultáneos (Investigador, Ejecutor/Coder, Analista SST & ERP, Revisor QA) con consolidación ejecutiva.
- **Conectores Externos Opcionales (`external-agents-connector.ts`)**: Integración con OpenClaw Gateway, Hermes Agent y OpenMausBot usando rotación de 9 claves Gemini (`gemini-3.5-flash-lite`, `gemini-3.8-flash`, `gemini-3.6-flash`).
- **Integraciones Nativas**: Puente directo con **Antigravity IDE**, **Siigo Nube ERP**, **Google Workspace (Gmail, Calendar, Drive, Sheets, Docs)** y **Portal Móvil QR**.

---

## 🍎 Instalación en macOS (Apple Silicon M1/M2/M3/M4 & Intel)
1. Descomprime este archivo `.zip`.
2. Haz doble clic en **`Instalar-Wappy-Dots-macOS.command`**.
   *(O en Terminal ejecuta: `bash Instalar-Wappy-Dots-macOS.command`)*
3. El instalador copiará automáticamente `Wappy Dots.app` a `/Applications`, configurará el túnel en `~/.wappy/tunnel` (puerto `3001`) y abrirá la isla en tu Notch.

## 🪟 Instalación en Windows (Windows 10 / 11 x64 & ARM64)
1. Descomprime este archivo `.zip`.
2. Haz doble clic en **`Instalar-Wappy-Dots-Windows.bat`**.
3. Se instalará el túnel autónomo en `%USERPROFILE%\.wappy\tunnel` y se abrirá la interfaz interactiva de Tenshi en `http://localhost:3001/api/gemini-tunnel/mobile/app`.

## 🐧 Instalación en Linux (Ubuntu / Debian / Fedora / Arch)
1. Descomprime este archivo `.zip`.
2. Ejecuta en tu terminal:
   ```bash
   ./Instalar-Wappy-Dots-Linux.sh
   ```
