# Memoria Persistente de Trabajo (MEMORY.md)
- Ecosistema activo: Wappy Bot, Wappy Dots (macOS Notch), Antigravity IDE, Siigo ERP y Google Workspace.
- Normativa clave Colombia SST: Decreto 1072 de 2015, Resolución 0312 de 2019, Resolución 1843 de 2025 (evaluaciones médicas ocupacionales), GTC 45 y PESV.
- Capacidades nativas activas: Team de Agentes en paralelo, Memoria estructurada (USER.md / MEMORY.md), Búsqueda instantánea SQLite FTS5 BM25, Auto-aprendizaje de Skills (SKILL.md), Automatizaciones Cron y Aprobaciones en el Notch.
- La Resolución 1843 de 2025 en Colombia exige la alineación estricta de las EMO con la Matriz de Peligros (GTC 45), trazabilidad rigurosa en el examen de egreso y la vinculación operativa de restricciones médico-laborales al SG-SST.
