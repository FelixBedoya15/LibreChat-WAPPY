# Perfil del Usuario (USER.md)
- Idioma preferido: Español.
- Rol principal: Dirección de Ingeniería, Producto y Seguridad y Salud en el Trabajo (Somos SST / Wappy).
- Preferencias de interfaz: Interacción fluida desde el Notch de macOS (Wappy Dots) y portal móvil sincronizado.
- Estilo de respuesta esperado: Datos verificados, enlaces directos cuando aplica, cero suposiciones sin fundamento.
