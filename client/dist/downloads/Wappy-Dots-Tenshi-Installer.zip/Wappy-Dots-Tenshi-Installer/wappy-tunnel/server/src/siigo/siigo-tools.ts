/**
 * Declaraciones de Herramientas (Tools) y Ejecutor para la integración con Siigo Nube API V1.
 * Diseñado para ser utilizado por Tenshi (Voz y Chat en Mac y Móvil) y por Antigravity.
 */

import { getSharedSiigoClient } from './siigo-client';
import type { SiigoCustomer, SiigoInvoice, SiigoProduct } from './siigo-types';

export const SIIGO_OPENAI_TOOLS = [
  {
    type: 'function',
    function: {
      name: 'siigo_estado_conexion',
      description:
        'Consulta el estado de la conexión con Siigo Nube API V1. Muestra si las credenciales están configuradas, si el sistema opera en modo Real o Sandbox, el Partner-Id utilizado ("WappyBot") y el estado del token JWT.',
      parameters: {
        type: 'object',
        properties: {},
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'siigo_configurar_credenciales',
      description:
        'Configura o actualiza las credenciales de Siigo Nube API (username / correo y access_key) y el modo de operación (Sandbox o Real). Guarda los cambios en ~/.wappy/siigo-config.json.',
      parameters: {
        type: 'object',
        properties: {
          username: {
            type: 'string',
            description: 'El correo electrónico del usuario registrado en Siigo Nube.',
          },
          access_key: {
            type: 'string',
            description: 'La clave de acceso de la API generada en Siigo Nube (Alianzas / Credenciales API).',
          },
          partner_id: {
            type: 'string',
            description: 'Nombre del Partner ID (por defecto "WappyBot", 3-100 caracteres alfanuméricos).',
          },
          sandbox: {
            type: 'boolean',
            description: 'True para operar en modo Sandbox de pruebas; False para producción real en Siigo.',
          },
        },
        required: ['username', 'access_key'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'siigo_consultar_clientes',
      description:
        'Consulta o busca clientes y terceros en Siigo Nube por número de identificación (NIT / Cédula) o por nombre / razón social.',
      parameters: {
        type: 'object',
        properties: {
          identification: {
            type: 'string',
            description: 'Número de cédula o NIT del cliente a buscar.',
          },
          name: {
            type: 'string',
            description: 'Nombre o razón social parcial para filtrar.',
          },
          page: {
            type: 'number',
            description: 'Número de página de resultados (por defecto 1).',
          },
        },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'siigo_crear_cliente',
      description:
        'Crea un nuevo cliente o tercero en Siigo Nube (persona natural o jurídica / empresa).',
      parameters: {
        type: 'object',
        properties: {
          person_type: {
            type: 'string',
            enum: ['Person', 'Company'],
            description: '"Person" para persona natural (cédula) o "Company" para empresa (NIT).',
          },
          id_type: {
            type: 'string',
            description: 'Tipo de documento: "13" Cédula, "31" NIT, "22" Cédula extranjería.',
          },
          identification: {
            type: 'string',
            description: 'Número de documento o NIT (sin dígito de verificación ni guiones).',
          },
          check_digit: {
            type: 'string',
            description: 'Dígito de verificación (si es NIT / Company).',
          },
          name: {
            type: 'string',
            description: 'Nombre completo (ej. "Carlos Andrés Gómez" o razón social "Mi Empresa S.A.S.").',
          },
          commercial_name: {
            type: 'string',
            description: 'Nombre comercial de la empresa.',
          },
          email: {
            type: 'string',
            description: 'Correo electrónico principal para facturación y notificaciones.',
          },
          phone: {
            type: 'string',
            description: 'Teléfono o celular de contacto.',
          },
          address: {
            type: 'string',
            description: 'Dirección física del cliente.',
          },
          city_code: {
            type: 'string',
            description: 'Código DANE de la ciudad (ej. "11001" para Bogotá, "05001" para Medellín).',
          },
          vat_responsible: {
            type: 'boolean',
            description: 'Indica si es responsable de IVA.',
          },
          comments: {
            type: 'string',
            description: 'Observaciones o comentarios adicionales del cliente.',
          },
        },
        required: ['person_type', 'identification', 'name'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'siigo_consultar_facturas',
      description:
        'Consulta las facturas de venta generadas en Siigo Nube, filtrando opcionalmente por NIT del cliente o por rango de fechas.',
      parameters: {
        type: 'object',
        properties: {
          customer_identification: {
            type: 'string',
            description: 'NIT o cédula del cliente para filtrar sus facturas.',
          },
          date_start: {
            type: 'string',
            description: 'Fecha inicial en formato AAAA-MM-DD (ej. "2026-10-01").',
          },
          date_end: {
            type: 'string',
            description: 'Fecha final en formato AAAA-MM-DD (ej. "2026-10-31").',
          },
          page: {
            type: 'number',
            description: 'Número de página de resultados.',
          },
        },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'siigo_crear_factura',
      description:
        'Crea y emite una nueva factura de venta electrónica en Siigo Nube para un cliente determinado.',
      parameters: {
        type: 'object',
        properties: {
          customer_identification: {
            type: 'string',
            description: 'NIT o cédula del cliente previamente registrado en Siigo.',
          },
          date: {
            type: 'string',
            description: 'Fecha de emisión en formato AAAA-MM-DD. Si se omite, se usa la fecha actual.',
          },
          observations: {
            type: 'string',
            description: 'Observaciones o notas visibles en la factura.',
          },
          items: {
            type: 'array',
            description: 'Lista de ítems o productos a facturar.',
            items: {
              type: 'object',
              properties: {
                code: {
                  type: 'string',
                  description: 'Código del producto o servicio en Siigo (ej. "SST-001").',
                },
                description: {
                  type: 'string',
                  description: 'Descripción del ítem o servicio.',
                },
                quantity: {
                  type: 'number',
                  description: 'Cantidad de unidades.',
                },
                price: {
                  type: 'number',
                  description: 'Precio unitario sin IVA.',
                },
                tax_percentage: {
                  type: 'number',
                  description: 'Porcentaje de IVA (ej. 19 para 19%, 0 para exento).',
                },
              },
              required: ['code', 'quantity', 'price'],
            },
          },
          payment_due_days: {
            type: 'number',
            description: 'Días de crédito para el pago (ej. 0 para contado, 30 para crédito a 30 días).',
          },
        },
        required: ['customer_identification', 'items'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'siigo_consultar_productos',
      description:
        'Consulta el catálogo de productos y servicios registrados en Siigo Nube, incluyendo precios, inventario y códigos.',
      parameters: {
        type: 'object',
        properties: {
          code: {
            type: 'string',
            description: 'Código de producto o servicio para buscar.',
          },
          name: {
            type: 'string',
            description: 'Nombre o descripción para buscar en el catálogo.',
          },
          page: {
            type: 'number',
            description: 'Número de página.',
          },
        },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'siigo_consultar_recibos',
      description:
        'Consulta los recibos de caja (comprobantes de pago / vouchers) registrados en Siigo Nube.',
      parameters: {
        type: 'object',
        properties: {
          date_start: {
            type: 'string',
            description: 'Fecha inicial AAAA-MM-DD.',
          },
          date_end: {
            type: 'string',
            description: 'Fecha final AAAA-MM-DD.',
          },
        },
      },
    },
  },
];

/**
 * Ejecutor principal de las herramientas de Siigo.
 */
export async function executeSiigoToolCall(
  name: string,
  args: Record<string, any>,
): Promise<{ resultText: string; files: any[] }> {
  const client = getSharedSiigoClient();

  switch (name) {
    case 'siigo_estado_conexion': {
      const status = client.getStatus();
      const lines = [
        `📊 **Estado de la Conexión con Siigo API V1**:`,
        `- **Modo:** ${status.sandbox ? '🧪 Sandbox (Pruebas con datos simulados)' : '🚀 Producción (Siigo Nube en Vivo)'}`,
        `- **Partner-Id:** \`${status.partnerId}\` (Obligatorio en cada petición)`,
        `- **Usuario configurado:** ${status.usernameMasked || '*(No configurado)*'}`,
        `- **Clave de Acceso (Access Key):** ${status.hasAccessKey ? 'Configurada ✅' : 'Pendiente ❌'}`,
        `- **Token JWT Activo:** ${status.authenticated ? `Válido hasta ${status.tokenExpiresAt}` : 'No autenticado aún'}`,
        `- **Servidor API:** \`${status.apiUrl}\``,
        ``,
        `💡 **Mensaje:** ${status.message}`,
      ];

      if (!status.configured) {
        lines.push(
          ``,
          `📝 **¿Cómo conectar tus credenciales reales de Siigo cuando las tengas?**`,
          `1. Entra a tu cuenta en [Siigo Nube](https://siigonube.siigo.com/).`,
          `2. Ve a: *Más configuraciones > API / Integraciones > Credenciales Usuario API*.`,
          `3. Genera tu **Access Key** y copia tu correo (**username**).`,
          `4. Puedes decírmelo a mí: *"Configura Siigo con usuario mi_correo@empresa.com y clave [tu_clave]"* o ingresarlo en el archivo \`~/.wappy/siigo-config.json\`.`,
        );
      }

      return {
        resultText: lines.join('\n'),
        files: [],
      };
    }

    case 'siigo_configurar_credenciales': {
      const { username, access_key, partner_id, sandbox } = args;
      const updated = client.saveConfig({
        username: String(username).trim(),
        access_key: String(access_key).trim(),
        partner_id: partner_id ? String(partner_id).trim() : undefined,
        sandbox: sandbox !== undefined ? Boolean(sandbox) : false,
      });

      // Intento de prueba inmediata de conexión
      const test = await client.testConnection();

      const lines = [
        `⚙️ **Credenciales de Siigo guardadas exitosamente**:`,
        `- **Usuario:** \`${updated.usernameMasked}\``,
        `- **Partner-Id:** \`${updated.partnerId}\``,
        `- **Modo:** ${updated.sandbox ? 'Sandbox (Pruebas)' : 'Producción (En vivo)'}`,
        `- **Archivo de configuración:** \`~/.wappy/siigo-config.json\``,
        ``,
        `📡 **Resultado de Conexión:** ${test.message}`,
      ];

      return {
        resultText: lines.join('\n'),
        files: [],
      };
    }

    case 'siigo_consultar_clientes': {
      const resp = await client.getCustomers({
        identification: args.identification ? String(args.identification) : undefined,
        name: args.name ? String(args.name) : undefined,
        page: args.page ? Number(args.page) : 1,
      });

      if (!resp.results || resp.results.length === 0) {
        return {
          resultText: `🔍 No se encontraron clientes en Siigo con los criterios especificados.`,
          files: [],
        };
      }

      const clientCards = resp.results.map((c, idx) => {
        const nameStr = Array.isArray(c.name) ? c.name.join(' ') : c.name || 'Sin nombre';
        const docLabel = c.id_type === '31' ? 'NIT' : 'C.C.';
        const phone = c.phones?.[0]?.number || 'No registra';
        const email = c.contacts?.[0]?.email || 'No registra';
        const city = c.address?.city?.city_name || 'Colombia';
        return `${idx + 1}. **${nameStr}** ${c.commercial_name ? `(*${c.commercial_name}*)` : ''}\n   - **${docLabel}:** \`${c.identification}${c.check_digit ? `-${c.check_digit}` : ''}\` · **Tipo:** ${c.person_type === 'Company' ? 'Empresa' : 'Persona natural'}\n   - **Ciudad:** ${city} · **Tel:** ${phone}\n   - **Correo:** ${email}\n   - **ID Siigo:** \`${c.id}\``;
      });

      const header = `👥 **Clientes en Siigo (${resp.results.length}${resp.total_results ? ` de ${resp.total_results}` : ''})**:`;
      return {
        resultText: `${header}\n\n${clientCards.join('\n\n')}`,
        files: [],
      };
    }

    case 'siigo_crear_cliente': {
      const personType = args.person_type === 'Company' ? 'Company' : 'Person';
      const idType = args.id_type || (personType === 'Company' ? '31' : '13');
      const nameParts = Array.isArray(args.name)
        ? args.name
        : typeof args.name === 'string'
          ? args.name.split(' ').filter(Boolean)
          : ['Cliente'];

      const newCustomer: SiigoCustomer = {
        type: 'Customer',
        person_type: personType,
        id_type: idType,
        identification: String(args.identification).replace(/[^0-9]/g, ''),
        check_digit: args.check_digit ? String(args.check_digit) : undefined,
        name: nameParts,
        commercial_name: args.commercial_name,
        active: true,
        vat_responsible: Boolean(args.vat_responsible),
        address: args.address
          ? {
              address: String(args.address),
              city: {
                city_code: args.city_code || '11001',
                country_code: 'Co',
              },
            }
          : undefined,
        phones: args.phone ? [{ indicative: '57', number: String(args.phone) }] : [],
        contacts: args.email
          ? [
              {
                first_name: nameParts[0] || 'Contacto',
                last_name: nameParts.slice(1).join(' ') || undefined,
                email: String(args.email),
              },
            ]
          : [],
        comments: args.comments || 'Creado vía Wappy Bot / Tenshi',
      };

      const created = await client.createCustomer(newCustomer);
      const fullName = Array.isArray(created.name) ? created.name.join(' ') : created.name;

      const summary = `✅ **Cliente registrado con éxito en Siigo**:\n- **Nombre:** **${fullName}**\n- **Identificación:** \`${created.identification}${created.check_digit ? `-${created.check_digit}` : ''}\`\n- **Tipo:** ${created.person_type === 'Company' ? 'Empresa / Jurídica' : 'Persona Natural'}\n- **ID Siigo:** \`${created.id}\``;

      return {
        resultText: summary,
        files: [],
      };
    }

    case 'siigo_consultar_facturas': {
      const resp = await client.getInvoices({
        customer_identification: args.customer_identification
          ? String(args.customer_identification)
          : undefined,
        date_start: args.date_start ? String(args.date_start) : undefined,
        date_end: args.date_end ? String(args.date_end) : undefined,
        page: args.page ? Number(args.page) : 1,
      });

      if (!resp.results || resp.results.length === 0) {
        return {
          resultText: `🧾 No se encontraron facturas en Siigo para los filtros solicitados.`,
          files: [],
        };
      }

      const rows = resp.results.map((inv) => {
        const custName = Array.isArray(inv.customer?.name)
          ? inv.customer.name.join(' ')
          : inv.customer?.name || inv.customer?.commercial_name || inv.customer?.identification;
        const totalFmt = new Intl.NumberFormat('es-CO', {
          style: 'currency',
          currency: 'COP',
          maximumFractionDigits: 0,
        }).format(inv.total || 0);
        const balanceFmt = new Intl.NumberFormat('es-CO', {
          style: 'currency',
          currency: 'COP',
          maximumFractionDigits: 0,
        }).format(inv.balance || 0);

        return `| **${inv.name || `FV-${inv.number}`}** | ${inv.date} | ${custName} | ${totalFmt} | ${inv.balance === 0 ? '🟢 Pagada' : `🟠 Saldo: ${balanceFmt}`} |`;
      });

      const table = [
        `🧾 **Facturas de Venta en Siigo (${resp.results.length})**:`,
        ``,
        `| Factura | Fecha | Cliente | Total | Estado |`,
        `| :--- | :--- | :--- | :--- | :--- |`,
        ...rows,
      ].join('\n');

      return {
        resultText: table,
        files: [],
      };
    }

    case 'siigo_crear_factura': {
      const today = new Date().toISOString().slice(0, 10);
      const invDate = args.date || today;

      const items = (args.items || []).map((it: any) => {
        const linePrice = Number(it.price) || 0;
        const taxPct = Number(it.tax_percentage ?? 19);
        return {
          code: String(it.code),
          description: it.description || undefined,
          quantity: Number(it.quantity) || 1,
          price: linePrice,
          discount: 0,
          taxes: taxPct > 0 ? [{ id: 1001, name: `IVA ${taxPct}%`, percentage: taxPct }] : [],
        };
      });

      const created = await client.createInvoice({
        date: invDate,
        customer: {
          identification: String(args.customer_identification),
          branch_office: 0,
        },
        observations: args.observations || 'Factura emitida vía Tenshi & Wappy Bot',
        items,
        payments: [
          {
            id: 1,
            value: 0, // calculado por el cliente
            due_date: invDate,
          },
        ],
      });

      const totalFmt = new Intl.NumberFormat('es-CO', {
        style: 'currency',
        currency: 'COP',
        maximumFractionDigits: 0,
      }).format(created.total || 0);

      const summary = [
        `🎉 **Factura Electrónica Generada Exitosamente en Siigo**:`,
        `- **Número:** **${created.name || `FV-${created.number}`}**`,
        `- **Fecha:** ${created.date}`,
        `- **Cliente:** NIT/C.C. \`${created.customer?.identification}\``,
        `- **Total Facturado:** **${totalFmt}**`,
        `- **Estado DIAN:** ${created.stamp?.status || 'Aceptada'}`,
        `- **Ítems incluidos:** ${created.items?.length || 0}`,
        created.public_url ? `- **Ver Factura:** [Abrir Factura Siigo](${created.public_url})` : '',
      ]
        .filter(Boolean)
        .join('\n');

      return {
        resultText: summary,
        files: [],
      };
    }

    case 'siigo_consultar_productos': {
      const resp = await client.getProducts({
        code: args.code ? String(args.code) : undefined,
        name: args.name ? String(args.name) : undefined,
        page: args.page ? Number(args.page) : 1,
      });

      if (!resp.results || resp.results.length === 0) {
        return {
          resultText: `📦 No se encontraron productos o servicios en Siigo con ese criterio.`,
          files: [],
        };
      }

      const rows = resp.results.map((p) => {
        const price = p.prices?.[0]?.price_list?.[0]?.value || 0;
        const priceFmt = new Intl.NumberFormat('es-CO', {
          style: 'currency',
          currency: 'COP',
          maximumFractionDigits: 0,
        }).format(price);
        const taxName = p.taxes?.[0]?.name || (p.tax_classification === 'Taxed' ? 'IVA 19%' : 'Exento');

        return `| \`${p.code}\` | **${p.name}** | ${p.type === 'Service' ? 'Servicio' : 'Producto'} | ${priceFmt} | ${taxName} |`;
      });

      const table = [
        `📦 **Catálogo de Productos y Servicios en Siigo (${resp.results.length})**:`,
        ``,
        `| Código | Nombre | Tipo | Precio Estándar | Impuesto |`,
        `| :--- | :--- | :--- | :--- | :--- |`,
        ...rows,
      ].join('\n');

      return {
        resultText: table,
        files: [],
      };
    }

    case 'siigo_consultar_recibos': {
      const resp = await client.getVouchers({
        date_start: args.date_start ? String(args.date_start) : undefined,
        date_end: args.date_end ? String(args.date_end) : undefined,
      });

      if (!resp.results || resp.results.length === 0) {
        return {
          resultText: `💵 No se encontraron recibos de caja en Siigo para las fechas indicadas.`,
          files: [],
        };
      }

      const rows = resp.results.map((v) => {
        const valFmt = new Intl.NumberFormat('es-CO', {
          style: 'currency',
          currency: 'COP',
          maximumFractionDigits: 0,
        }).format(v.payment?.value || 0);
        return `| **${v.name || `RC-${v.number}`}** | ${v.date} | ${v.customer?.name || v.customer?.identification} | ${valFmt} | ${v.observations || 'Sin observaciones'} |`;
      });

      const table = [
        `💵 **Recibos de Caja / Comprobantes de Pago en Siigo (${resp.results.length})**:`,
        ``,
        `| Recibo | Fecha | Cliente | Valor Recibido | Observaciones |`,
        `| :--- | :--- | :--- | :--- | :--- |`,
        ...rows,
      ].join('\n');

      return {
        resultText: table,
        files: [],
      };
    }

    default:
      return {
        resultText: JSON.stringify({ error: `Herramienta de Siigo desconocida: ${name}` }),
        files: [],
      };
  }
}
