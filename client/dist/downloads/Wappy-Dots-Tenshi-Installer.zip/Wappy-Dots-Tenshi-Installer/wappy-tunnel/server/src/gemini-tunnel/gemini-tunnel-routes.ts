/**
 * gemini-tunnel-routes.ts
 *
 * Router Hono OpenAI-compatible para el Túnel de Google Gemini con balanceo
 * y rotación inteligente (GeminiPoolManager).
 *
 * Replica al 100% la infraestructura de llamada de LibreChat-WAPPY:
 *   - GoogleClient.js (rotación de claves, 429 RPM/TPM, 403 quota, 400 invalid, 503 model fallback)
 *   - sgsstGemini.js (generateWithKeyRotation, SGSST_FALLBACK_MODELS, LIVE_FALLBACK_MODELS)
 *   - voiceSession.js / geminiLive.js (Tenshi Live voice models)
 */

import { Hono } from 'hono';
import { existsSync, mkdirSync, readFileSync, writeFileSync, chmodSync } from 'node:fs';
import { homedir } from 'node:os';
import { dirname, join } from 'node:path';
import { geminiPoolManager } from './gemini-pool-manager';
import { liveChatTurn, synthesizeWithGeminiLive, LiveBridgeError } from './gemini-live-bridge';
import { processLocalAttachment, generateMultimodalCompletion } from './gemini-file-processor';
import { getTenshiMobileAppHtml } from './tenshi-mobile-app';
import { getPublicTunnelStatus } from './cloudflare-tunnel';
import { getSharedSiigoClient } from '../siigo/siigo-client';
import { getSharedGoogleWorkspaceClient } from '../google/google-workspace-client';
import { startGoogleOAuthServer } from '../google/google-oauth-server';
import {
  TEAM_AGENTS,
  runAgentTeamMission,
  callWappyTunnelGemini,
  type TeamAgentId,
} from './agent-team-orchestrator';
import {
  getWappyMemorySnapshot,
  mutateWappyMemory,
  runMemoryDreamingSweep,
  searchWappyHistoryFts,
  getFtsStats,
  listWappySkills,
  saveWappySkill,
  listCronJobs,
  createCronJob,
  deleteCronJob,
  toggleCronJob,
  runCronJobNow,
  requestNotchApproval,
} from './wappy-autonomous-core';
import {
  getExternalConnectorsStatus,
  saveExternalConnectorsConfig,
  delegateToExternalAgent,
  type ExternalAgentId,
} from './external-agents-connector';
import {
  ANTIGRAVITY_OPENAI_TOOLS,
  appendSharedChatMessage,
  executeAntigravityToolCall,
  getActiveSystemApisSync,
  getAntigravityStatus,
  getSharedFilePath,
  listAntigravityChats,
  listAntigravityProjects,
  loadAgentRoutingConfig,
  loadAntigravityConfig,
  loadSharedChat,
  openAntigravityInMac,
  readAntigravityChat,
  resolveOrderedKeysAndModelsForAgent,
  rotateAgentKeyNow,
  saveAgentRoutingConfig,
  saveAntigravityConfig,
  type SharedFileItem,
} from './antigravity-bridge';

// ---------------------------------------------------------------------------
// Configuración persistente guardada desde la interfaz (Coucou → Ajustes → Chat → Google AI).
// Igual que LibreChat-WAPPY guarda las claves del usuario en el servidor, aquí se guardan en un
// archivo local (0600) fuera del repositorio, para que sobrevivan reinicios del servidor.
// ---------------------------------------------------------------------------
type TunnelConfig = {
  textKeys: string[];
  voiceKeys: string[];
  textModel?: string;
  liveModel?: string;
  updatedAt?: string;
};

const CONFIG_PATH =
  process.env.GEMINI_TUNNEL_CONFIG_PATH || join(homedir(), '.wappy', 'gemini-tunnel.json');

function loadTunnelConfig(): TunnelConfig {
  try {
    if (existsSync(CONFIG_PATH)) {
      const parsed = JSON.parse(readFileSync(CONFIG_PATH, 'utf8'));
      return {
        textKeys: Array.isArray(parsed.textKeys) ? parsed.textKeys : [],
        voiceKeys: Array.isArray(parsed.voiceKeys) ? parsed.voiceKeys : [],
        textModel: parsed.textModel || undefined,
        liveModel: parsed.liveModel || undefined,
        updatedAt: parsed.updatedAt,
      };
    }
  } catch (e) {
    console.warn('[GeminiTunnel] No se pudo leer la configuración guardada:', e);
  }
  return { textKeys: [], voiceKeys: [] };
}

function saveTunnelConfig(cfg: TunnelConfig) {
  try {
    mkdirSync(dirname(CONFIG_PATH), { recursive: true });
    writeFileSync(CONFIG_PATH, JSON.stringify({ ...cfg, updatedAt: new Date().toISOString() }, null, 2));
    chmodSync(CONFIG_PATH, 0o600);
  } catch (e) {
    console.warn('[GeminiTunnel] No se pudo guardar la configuración:', e);
  }
}

let tunnelConfig: TunnelConfig = loadTunnelConfig();

function withPrimaryFirst(ladder: string[], primary?: string): string[] {
  // Solo se acepta como principal un modelo de la lista (los modelos retirados se ignoran).
  if (!primary || !ladder.includes(primary)) return ladder;
  return [primary, ...ladder.filter((m) => m !== primary)];
}

// Escaleras de modelos oficiales WAPPY (LibreChat-WAPPY SGSST_FALLBACK_MODELS & LIVE_FALLBACK_MODELS)
export function getTextModelLadder(): string[] {
  const fromEnv = (process.env.GEMINI_TEXT_FALLBACK_LADDER || process.env.GEMINI_TEXT_MODELS || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  const base = fromEnv.length > 0
    ? fromEnv
    : withPrimaryFirst(
        ['gemini-3.8-flash', 'gemini-3.6-flash', 'gemini-3.5-flash-lite'],
        process.env.GEMINI_TEXT_PRIMARY_MODEL,
      );
  // El modelo elegido en la interfaz manda: va primero y el resto queda como respaldo.
  return withPrimaryFirst(base, tunnelConfig.textModel);
}

export function getVoiceModelLadder(): string[] {
  const fromEnv = (process.env.GEMINI_VOICE_FALLBACK_LADDER || process.env.GEMINI_VOICE_MODELS || '')
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  const base = fromEnv.length > 0
    ? fromEnv
    : withPrimaryFirst(
        ['gemini-3.1-flash-live-preview', 'gemini-3.8-live'],
        process.env.GEMINI_VOICE_PRIMARY_MODEL,
      );
  return withPrimaryFirst(base, tunnelConfig.liveModel);
}

export const TEXT_MODEL_LADDER = [
  'gemini-3.8-flash',
  'gemini-3.6-flash',
  'gemini-3.5-flash-lite',
];

export const VOICE_MODEL_LADDER = [
  'gemini-3.1-flash-live-preview',
  'gemini-3.8-live',
];

// Mapeo para evitar que Coucou filtre modelos que contengan 'live' o 'audio' en fetchGoogleModels
export const MODEL_ALIASES: Record<string, string> = {
  'gemini-3.1-flash-voice': 'gemini-3.1-flash-live-preview',
  'gemini-3.8-voice': 'gemini-3.8-live',
};

// Almacén en memoria de claves configuradas (además de process.env)
let inMemoryTextKeys: string[] = geminiPoolManager.extractCleanApiKeys(tunnelConfig.textKeys);
let inMemoryVoiceKeys: string[] = geminiPoolManager.extractCleanApiKeys(tunnelConfig.voiceKeys);

/**
 * Obtiene las claves de texto activas (prioriza memoria, luego variables de entorno)
 */
export function getTextKeys(): string[] {
  if (inMemoryTextKeys.length > 0) return inMemoryTextKeys;

  // 1. Revisar casillas individuales GEMINI_TEXT_KEY_1 .. GEMINI_TEXT_KEY_6
  const individual = [
    process.env.GEMINI_TEXT_KEY_1,
    process.env.GEMINI_TEXT_KEY_2,
    process.env.GEMINI_TEXT_KEY_3,
    process.env.GEMINI_TEXT_KEY_4,
    process.env.GEMINI_TEXT_KEY_5,
    process.env.GEMINI_TEXT_KEY_6,
  ].filter(Boolean) as string[];

  if (individual.length > 0) {
    return geminiPoolManager.extractCleanApiKeys(individual);
  }

  // 2. Revisar lista agrupada
  const raw =
    process.env.GEMINI_TEXT_API_KEYS ||
    process.env.GEMINI_TEXT_KEYS ||
    process.env.GEMINI_API_KEYS ||
    process.env.GOOGLE_API_KEYS ||
    process.env.GOOGLE_API_KEY ||
    '';

  return geminiPoolManager.extractCleanApiKeys(raw);
}

/**
 * Obtiene las claves de voz activas (prioriza memoria, luego variables de entorno)
 */
export function getVoiceKeys(): string[] {
  if (inMemoryVoiceKeys.length > 0) return inMemoryVoiceKeys;

  // 1. Revisar casillas individuales GEMINI_VOICE_KEY_1 .. GEMINI_VOICE_KEY_3
  const individual = [
    process.env.GEMINI_VOICE_KEY_1,
    process.env.GEMINI_VOICE_KEY_2,
    process.env.GEMINI_VOICE_KEY_3,
  ].filter(Boolean) as string[];

  if (individual.length > 0) {
    return geminiPoolManager.extractCleanApiKeys(individual);
  }

  // 2. Revisar lista agrupada
  const raw =
    process.env.GEMINI_VOICE_API_KEYS ||
    process.env.GEMINI_VOICE_KEYS ||
    process.env.GEMINI_LIVE_KEYS ||
    '';

  return geminiPoolManager.extractCleanApiKeys(raw);
}

/**
 * Permite actualizar claves en memoria en tiempo de ejecución
 */
export function setTunnelKeys(textKeys?: string | string[], voiceKeys?: string | string[]) {
  if (textKeys) {
    inMemoryTextKeys = geminiPoolManager.extractCleanApiKeys(textKeys);
  }
  if (voiceKeys) {
    inMemoryVoiceKeys = geminiPoolManager.extractCleanApiKeys(voiceKeys);
  }
}

/**
 * Guarda la configuración enviada desde la interfaz (claves + modelos) y la persiste en disco.
 * Un arreglo vacío borra ese pool (vuelve a usar el .env).
 */
export function saveTunnelSettings(input: {
  textKeys?: string | string[];
  voiceKeys?: string | string[];
  textModel?: string;
  liveModel?: string;
}) {
  if (input.textKeys !== undefined) {
    inMemoryTextKeys = geminiPoolManager.extractCleanApiKeys(input.textKeys);
  }
  if (input.voiceKeys !== undefined) {
    inMemoryVoiceKeys = geminiPoolManager.extractCleanApiKeys(input.voiceKeys);
  }
  tunnelConfig = {
    textKeys: inMemoryTextKeys,
    voiceKeys: inMemoryVoiceKeys,
    textModel: input.textModel || tunnelConfig.textModel,
    liveModel: input.liveModel || tunnelConfig.liveModel,
  };
  saveTunnelConfig(tunnelConfig);
}

/**
 * Normaliza nombres de modelo
 */
function resolveRealModelName(modelName: string): string {
  const clean = (modelName || '').trim();
  if (MODEL_ALIASES[clean]) return MODEL_ALIASES[clean];
  return clean;
}

/**
 * Determina si un modelo pertenece al pool de voz
 */
function isVoiceModel(modelName: string): boolean {
  const m = modelName.toLowerCase();
  return m.includes('live') || m.includes('audio') || m.includes('voice') || m.includes('preview-12-2025');
}

/**
 * Construye la escalera ordenada de modelos a probar
 */
function buildModelLadder(requestedModel: string): string[] {
  const textLadder = getTextModelLadder();
  const voiceLadder = getVoiceModelLadder();
  const resolved = resolveRealModelName(requestedModel || textLadder[0]);
  const isVoice = isVoiceModel(resolved);
  const ladder = isVoice ? voiceLadder : textLadder;

  if (ladder.includes(resolved)) {
    return [resolved, ...ladder.filter((m) => m !== resolved)];
  }
  return [resolved, ...ladder];
}

export function createGeminiTunnelRoutes(): Hono {
  const router = new Hono();

  // Iniciar servidor local OAuth de Google en puerto 3080 (URI autorizada en Google Cloud Console)
  startGoogleOAuthServer(3080);

  // 1. Listado de modelos (OpenAI format)
  // Devuelve los modelos de texto y voz compatibles con Coucou
  const listModelsHandler = (c: any) => {
    console.log('[GeminiTunnel] Petición recibida GET /models (Coucou Google Provider)');
    const textLadder = getTextModelLadder();
    const voiceLadder = getVoiceModelLadder();
    const textModels = textLadder.map((id) => ({
      id,
      object: 'model',
      created: 1730000000,
      owned_by: 'wappy-gemini-text-pool',
    }));

    // Versiones compatibles con el filtro de Coucou (que excluye palabras 'live' y 'audio')
    const voiceModels = [
      { id: 'gemini-3.1-flash-voice', object: 'model', created: 1730000000, owned_by: 'wappy-gemini-voice-pool' },
      { id: 'gemini-3.8-voice', object: 'model', created: 1730000000, owned_by: 'wappy-gemini-voice-pool' },
      // Y los nombres oficiales directos
      ...voiceLadder.map((id) => ({
        id,
        object: 'model',
        created: 1730000000,
        owned_by: 'wappy-gemini-voice-pool',
      })),
    ];

    return c.json({
      object: 'list',
      data: [...textModels, ...voiceModels],
    });
  };

  router.get('/v1/models', listModelsHandler);
  router.get('/models', listModelsHandler);

  // 2. Estado del pool (Health check & métricas de rotación en vivo)
  router.get('/status', (c) => {
    const textKeys = getTextKeys();
    const voiceKeys = getVoiceKeys();

    const textStats = geminiPoolManager.getPoolStats(textKeys, getTextModelLadder()[0]);
    const voiceStats = geminiPoolManager.getPoolStats(voiceKeys, getVoiceModelLadder()[0]);

    return c.json({
      status: 'ok',
      service: 'Wappy Gemini Rotation Tunnel (LibreChat-WAPPY Core)',
      textPool: {
        keysConfigured: textKeys.length,
        defaultModel: getTextModelLadder()[0],
        ladder: getTextModelLadder(),
        stats: textStats,
      },
      voicePool: {
        keysConfigured: voiceKeys.length,
        defaultModel: getVoiceModelLadder()[0],
        ladder: getVoiceModelLadder(),
        stats: voiceStats,
      },
    });
  });

  // 3. Configuración dinámica de claves
  router.post('/keys', async (c) => {
    try {
      const body = await c.req.json();
      saveTunnelSettings({
        textKeys: body.textKeys,
        voiceKeys: body.voiceKeys ?? body.liveKeys,
        textModel: body.textModel,
        liveModel: body.liveModel,
      });
      return c.json({
        success: true,
        textKeysLoaded: getTextKeys().length,
        voiceKeysLoaded: getVoiceKeys().length,
        textModel: getTextModelLadder()[0],
        liveModel: getVoiceModelLadder()[0],
        textLadder: getTextModelLadder(),
        liveLadder: getVoiceModelLadder(),
      });
    } catch (e: any) {
      return c.json({ error: e.message || 'Invalid JSON' }, 400);
    }
  });

  // 3.5. Búsqueda Web en Vivo usando la escalera de modelos y conexión oficial de Wappy (`gemini-3.5-flash-lite`, `gemini-3.8-flash`, `gemini-3.6-flash` vía `geminiPoolManager`)
  router.get('/web-search', async (c) => {
    const q = (c.req.query('q') || '').trim();
    if (!q) return c.json({ ok: false, summary: '' }, 400);
    const keys = [...getTextKeys(), ...getVoiceKeys()];
    const { text: summary, modelUsed, sources } = await callWappyTunnelGemini(
      `Resume en español en 2 a 4 oraciones los hechos, normas, resoluciones, leyes, fechas o datos más recientes (incluyendo 2025 y 2026) sobre: "${q}". Si una norma reciente (como de 2025 o 2026) actualizó o derogó una anterior, menciónalo explícitamente.`,
      {
        agentRouteId: 'tenshi_chat',
        useWebSearch: true,
        webQuery: q,
        extraKeys: keys,
      },
    );
    if (summary) {
      console.log(`[GeminiTunnel] WebSearch OK con ${modelUsed} para "${q}": ${summary.slice(0, 140)}...`);
      return c.json({ ok: true, query: q, model: modelUsed, summary, sources });
    }
    return c.json({ ok: false, query: q, summary: '' });
  });

  // 4. Chat Completions (OpenAI Compatible)
  const chatCompletionsHandler = async (c: any) => {
    console.log('[GeminiTunnel] Petición recibida POST /chat/completions (Coucou Google Provider)');
    let body: any;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: { message: 'Invalid JSON body', type: 'invalid_request_error' } }, 400);
    }

    // Si el cliente envía claves en Authorization: Bearer k1,k2,k3...
    const authHeader = c.req.header('authorization') || '';
    const incomingKeys = geminiPoolManager
      .extractCleanApiKeys(authHeader)
      .filter((k) => k.startsWith('AIza'));
    if (incomingKeys.length > 0) {
      if (incomingKeys.length >= 4) {
        // Si vienen 9 o varias claves, asignar las primeras 6 a texto y el resto a voz
        const textSlice = incomingKeys.slice(0, Math.min(incomingKeys.length, 6));
        const voiceSlice = incomingKeys.slice(6);
        setTunnelKeys(textSlice, voiceSlice.length > 0 ? voiceSlice : undefined);
      } else if (inMemoryTextKeys.length === 0) {
        setTunnelKeys(incomingKeys);
      }
    }

    const requestedModel = resolveRealModelName(body.model || getTextModelLadder()[0]);
    const isStream = Boolean(body.stream);
    const isVoice = isVoiceModel(requestedModel);
    const agentRouteId = body.agent_id || (isVoice ? 'tenshi_voice' : 'tenshi_chat');
    const resolvedRoute = resolveOrderedKeysAndModelsForAgent(agentRouteId);

    const modelLadder =
      resolvedRoute.route.apiSelection !== 'auto_pool' && resolvedRoute.route.apiSelection !== 'auto_voice_pool'
        ? resolvedRoute.models
        : buildModelLadder(resolvedRoute.route.model || requestedModel);

    // Obtener claves candidatas respetando la selección de API por agente/conexión
    let poolKeys =
      resolvedRoute.keys.length > 0
        ? resolvedRoute.keys
        : isVoice
          ? getVoiceKeys()
          : getTextKeys();

    // En modo voz, concatenar las claves del pool de texto como respaldo automático si las 3 de voz se saturan
    if (isVoice) {
      poolKeys = Array.from(new Set([...poolKeys, ...getVoiceKeys(), ...getTextKeys()]));
    }

    if (poolKeys.length === 0) {
      return c.json(
        {
          error: {
            message: `No se encontraron claves API de Gemini configuradas para el pool de ${
              isVoice ? 'voz' : 'texto'
            }. Ingresa tus claves en Ajustes de Wappy Dots (Google AI) o en el archivo .env (GEMINI_TEXT_API_KEYS).`,
            type: 'authentication_error',
          },
        },
        401
      );
    }

    const clientIdentifier = c.req.header('x-forwarded-for') || c.req.header('user-agent') || 'global';
    let lastError: any = null;

    // Procesar archivo adjunto local (PDF, Excel, Word, Imágenes, Audio, Video) si fue enviado por Wappy Dots
    let processedAttachment = null;
    if (body.wappy_file?.path) {
      try {
        processedAttachment = await processLocalAttachment(body.wappy_file.path, body.wappy_file.name);
        if (processedAttachment) {
          console.log(
            `[GeminiTunnel] Archivo adjunto procesado: "${processedAttachment.fileName}" (${processedAttachment.mimeType}, ${processedAttachment.kind}, ${processedAttachment.byteSize} bytes)`,
          );
        }
      } catch (fileErr: any) {
        console.warn(`[GeminiTunnel] Error procesando archivo adjunto:`, fileErr?.message);
      }
    }

    // Modelos Live (3.1-flash-live-preview → 3.8-live): solo funcionan por WebSocket (Live API).
    // Se atienden con el puente Live usando el pool de 3 claves Live y su escalera de modelos.
    if (isVoice) {
      // Si hay un archivo adjunto y el usuario pregunta por voz:
      // 1) Si es Excel o Word (extracted_text), inyectar el texto en el turno del usuario.
      // 2) Si es PDF, Imagen, Audio o Video (inline_media), analizarlo con el modelo multimodal y pasar el análisis a Live.
      if (processedAttachment) {
        const msgs = Array.isArray(body.messages) ? [...body.messages] : [];
        if (processedAttachment.kind === 'extracted_text' && processedAttachment.extractedText) {
          const lastIdx = msgs.length - 1;
          if (lastIdx >= 0 && msgs[lastIdx].role === 'user') {
            msgs[lastIdx] = {
              ...msgs[lastIdx],
              content: `[ARCHIVO ADJUNTO EN EL NOTCH: "${processedAttachment.fileName}"]\nCONTENIDO:\n${processedAttachment.extractedText.slice(0, 30000)}\n\nPREGUNTA DEL USUARIO: ${msgs[lastIdx].content}`,
            };
            body = { ...body, messages: msgs };
          }
        } else if (processedAttachment.kind === 'inline_media') {
          const textPoolKeys = getTextKeys().length > 0 ? getTextKeys() : poolKeys;
          const textLadder = getTextModelLadder();
          for (const tm of textLadder) {
            const pKeys = geminiPoolManager.getPrioritizedKeys(textPoolKeys, tm, clientIdentifier);
            let analyzed = false;
            for (const tk of pKeys) {
              try {
                const mmRes = await generateMultimodalCompletion({
                  model: tm,
                  apiKey: tk,
                  messages: msgs,
                  attachment: processedAttachment,
                  maxTokens: 2048,
                });
                const analysisText = mmRes?.choices?.[0]?.message?.content;
                if (analysisText) {
                  const lastIdx = msgs.length - 1;
                  if (lastIdx >= 0 && msgs[lastIdx].role === 'user') {
                    msgs[lastIdx] = {
                      ...msgs[lastIdx],
                      content: `[ANÁLISIS MULTIMODAL DEL ARCHIVO ADJUNTO "${processedAttachment.fileName}":\n${analysisText}]\n\nResponde verbalmente al usuario en español sobre este archivo para atender su consulta: "${msgs[lastIdx].content}"`,
                    };
                    body = { ...body, messages: msgs };
                    analyzed = true;
                    break;
                  }
                }
              } catch {}
            }
            if (analyzed) break;
          }
        }
      }

      // Registrar la instrucción hablada del usuario en el portal móvil ANTES de que Tenshi/Antigravity ejecute herramientas
      const voiceMsgs = Array.isArray(body.messages) ? body.messages : [];
      const lastVoiceMsg = voiceMsgs[voiceMsgs.length - 1];
      if (
        lastVoiceMsg &&
        lastVoiceMsg.role === 'user' &&
        typeof lastVoiceMsg.content === 'string' &&
        lastVoiceMsg.content.trim()
      ) {
        appendSharedChatMessage({
          role: 'user',
          content: `🎙️ ${lastVoiceMsg.content.trim()}`,
          source: 'notch-voice',
        });
      }

      for (const currentModel of modelLadder) {
        const prioritizedKeys = geminiPoolManager.getPrioritizedKeys(poolKeys, currentModel, clientIdentifier);
        for (const key of prioritizedKeys) {
          try {
            const result = await liveChatTurn(body, currentModel, key, body.voice || 'Sol');
            geminiPoolManager.reportKeySuccess(key);
            console.log(`[GeminiTunnel] Live AUDIO OK con ${currentModel} (${geminiPoolManager.maskKey(key)})`);
            const spokenReply = result?.choices?.[0]?.message?.content;
            if (typeof spokenReply === 'string' && spokenReply.trim()) {
              appendSharedChatMessage({
                role: 'assistant',
                content: `🔊 **Respuesta por voz de Tenshi:**\n${spokenReply.trim()}`,
                source: 'notch-voice',
              });
            }
            return c.json(result);
          } catch (e: any) {
            lastError = e;
            const status = e instanceof LiveBridgeError ? e.status : 503;
            console.warn(`[GeminiTunnel] Live falló con ${currentModel} (${geminiPoolManager.maskKey(key)}): ${e?.message}`);
            if (status === 404) {
              break; // Modelo no soportado en Live WS -> pasar al siguiente modelo de la escalera
            }
            geminiPoolManager.reportKeyStatus(key, currentModel, {
              status: status === 403 ? 403 : 429,
              message: e?.message,
            });
            continue; // Probar siguiente clave del pool (incluyendo respaldo)
          }
        }
      }
      return c.json(
        { error: { message: `Gemini Live no respondió: ${lastError?.message ?? 'sin detalle'}`, type: 'live_error' } },
        503,
      );
    }

    // Escalera externa: Modelos (rotación en 503 o cuando se agotan todas las claves)
    for (let modelIdx = 0; modelIdx < modelLadder.length; modelIdx++) {
      const currentModel = modelLadder[modelIdx];
      const prioritizedKeys = geminiPoolManager.getPrioritizedKeys(poolKeys, currentModel, clientIdentifier);

      // Escalera interna: Claves API en rotación
      for (let keyIdx = 0; keyIdx < prioritizedKeys.length; keyIdx++) {
        const key = prioritizedKeys[keyIdx];
        const maskedKey = geminiPoolManager.maskKey(key);

        try {
          // Si hay un archivo adjunto (PDF, Excel, Word, Imagen, Audio, Video), usar el motor multimodal nativo de Gemini
          if (processedAttachment) {
            const mmData = await generateMultimodalCompletion({
              model: currentModel,
              apiKey: key,
              messages: body.messages ?? [],
              attachment: processedAttachment,
              maxTokens: body.max_tokens || 8192,
            });
            geminiPoolManager.reportKeySuccess(key);
            console.log(
              `[GeminiTunnel] Lectura multimodal OK ("${processedAttachment.fileName}") con ${currentModel} (${maskedKey})`,
            );
            return c.json(mmData);
          }

          // Endpoint oficial OpenAI-compatible de Google AI Studio (solo texto sin adjuntos)
          const googleUrl = 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions';
          const agyEnabled = loadAntigravityConfig().enabled;
          const callerHasTools = Array.isArray(body.tools) && body.tools.length > 0;
          const autoRunAgyTools = !isStream && agyEnabled && !callerHasTools;

          const requestPayload: any = {
            ...body,
            model: currentModel,
          };
          delete requestPayload.wappy_file;
          if (autoRunAgyTools) {
            requestPayload.tools = ANTIGRAVITY_OPENAI_TOOLS;
          }

          const res = await fetch(googleUrl, {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${key}`,
            },
            body: JSON.stringify(requestPayload),
          });

          // ÉXITO (HTTP 200)
          if (res.ok) {
            geminiPoolManager.reportKeySuccess(key);

            if (isStream && res.body) {
              return new Response(res.body, {
                status: 200,
                headers: {
                  'Content-Type': 'text/event-stream',
                  'Cache-Control': 'no-cache',
                  Connection: 'keep-alive',
                  'X-Wappy-Model-Used': currentModel,
                  'X-Wappy-Key-Used': maskedKey,
                },
              });
            }

            let data: any = await res.json();

            // Registrar la pregunta del usuario ANTES de ejecutar herramientas Antigravity para mantener orden cronológico exacto en el celular
            if (!callerHasTools) {
              const lastUserMsg = Array.isArray(body.messages)
                ? [...body.messages].reverse().find((m: any) => m?.role === 'user')
                : null;
              if (lastUserMsg && typeof lastUserMsg.content === 'string' && lastUserMsg.content.trim()) {
                appendSharedChatMessage({
                  role: 'user',
                  content: lastUserMsg.content.trim(),
                  source: 'notch-chat',
                });
              }
            }

            // Si estamos en modo chat con herramientas automáticas de Antigravity y Gemini invocó una herramienta:
            if (autoRunAgyTools && data?.choices?.[0]?.message?.tool_calls?.length) {
              const workingMessages = Array.isArray(requestPayload.messages)
                ? [...requestPayload.messages]
                : [];
              const collectedFiles: SharedFileItem[] = [];

              for (let round = 0; round < 4; round++) {
                const assistantMsg = data?.choices?.[0]?.message;
                const toolCalls = assistantMsg?.tool_calls;
                if (!Array.isArray(toolCalls) || toolCalls.length === 0) break;

                workingMessages.push(assistantMsg);
                for (const tc of toolCalls) {
                  const fnName = tc?.function?.name || '';
                  let fnArgs: Record<string, any> = {};
                  try {
                    fnArgs =
                      typeof tc?.function?.arguments === 'string'
                        ? JSON.parse(tc.function.arguments || '{}')
                        : tc?.function?.arguments || {};
                  } catch {}
                  console.log(`[GeminiTunnel] Ejecutando herramienta Antigravity "${fnName}"`, fnArgs);
                  const execRes = await executeAntigravityToolCall(fnName, fnArgs);
                  if (execRes.files.length > 0) {
                    collectedFiles.push(...execRes.files);
                  }
                  workingMessages.push({
                    role: 'tool',
                    tool_call_id: tc.id || `call_${Date.now()}`,
                    name: fnName,
                    content: execRes.resultText,
                  });
                }

                const followRes = await fetch(googleUrl, {
                  method: 'POST',
                  headers: {
                    'Content-Type': 'application/json',
                    Authorization: `Bearer ${key}`,
                  },
                  body: JSON.stringify({
                    model: currentModel,
                    messages: workingMessages,
                    tools: ANTIGRAVITY_OPENAI_TOOLS,
                    max_tokens: body.max_tokens || 8192,
                  }),
                });
                if (!followRes.ok) break;
                data = await followRes.json();
              }

              // Garantizar que cualquier archivo generado tenga su enlace clicable en el mensaje final
              if (collectedFiles.length > 0 && data?.choices?.[0]?.message) {
                let finalContent = String(data.choices[0].message.content || '').trim();
                for (const f of collectedFiles) {
                  if (!finalContent.includes(f.localUrl)) {
                    finalContent += `\n\n📎 **Archivo listo (${f.format.toUpperCase()})**: [📄 Abrir ${f.fileName}](${f.localUrl})\n🌐 **Celular / Red Local**: [📱 Abrir en Celular](${f.lanUrl})`;
                  }
                }
                data.choices[0].message.content = finalContent;
              }
            }

            // Sincronizar la respuesta final del chat del Notch con el historial compartido móvil
            if (!callerHasTools && data?.choices?.[0]?.message?.content) {
              appendSharedChatMessage({
                role: 'assistant',
                content: String(data.choices[0].message.content),
                source: 'notch-chat',
              });
            }

            return c.json(data);
          }

          // ERROR DE GOOGLE (Exactamente como GoogleClient.js líneas 855-895)
          const errText = await res.text();
          let errJson: any = null;
          try {
            errJson = JSON.parse(errText);
          } catch {}

          const status = res.status;
          const msg = (errJson?.error?.message || errText || `HTTP ${status}`).toLowerCase();

          // 1. Detección de Rate Limit (429) o Quota Exceeded (403)
          const isRateLimit = status === 429 || msg.includes('429') || msg.includes('quota') || msg.includes('too many requests') || msg.includes('resource_exhausted');
          const isQuotaExceeded = status === 403 || msg.includes('403') || msg.includes('quota exceeded');

          // 2. Detección de Clave Inválida (400)
          const isInvalidKey = status === 400 && (msg.includes('api_key_invalid') || msg.includes('api key not valid') || msg.includes('invalid api key'));

          // 3. Detección de Sobrecarga del Servidor (503 Service Unavailable)
          const is503 = status === 503 || msg.includes('503') || msg.includes('overloaded') || msg.includes('service unavailable') || msg.includes('high demand');

          // 4. Detección de Límite Diario Agotado (RPD)
          const isDailyLimit = msg.includes('generaterequestsperday') || msg.includes('daily request') || (msg.includes('limit: 20') && !msg.includes('minute'));

          console.warn(
            `[GeminiTunnel] Fallo en modelo "${currentModel}" con clave ${maskedKey} (Status ${status}): ${msg.slice(0, 100)}`
          );

          // Reportar estado a GeminiPoolManager para activar el Circuit Breaker correspondiente
          geminiPoolManager.reportKeyStatus(key, currentModel, {
            status,
            message: msg,
            isDailyLimit,
          });

          lastError = { status, message: msg, model: currentModel };

          // Si es 503 (Servicio Sobrecargado), rotar inmediatamente al siguiente MODELO en la escalera
          // sin penalizar las claves API (igual que GoogleClient.js línea 897)
          if (is503) {
            console.warn(
              `[GeminiTunnel] 503 detectado en modelo "${currentModel}". Saltando al siguiente modelo en la escalera...`
            );
            break; // Rompe bucle de claves para avanzar de modelo
          }

          // Para 429, 403 o 400, continuar a la siguiente clave API en el pool
          continue;
        } catch (fetchErr: any) {
          const st = fetchErr?.status || 500;
          const m = String(fetchErr?.message || '').toLowerCase();
          console.error(`[GeminiTunnel] Error en modelo "${currentModel}" con clave ${maskedKey} (${st}): ${m.slice(0, 140)}`);
          lastError = { status: st, message: fetchErr.message, model: currentModel };
          if (st === 429 || st === 403 || m.includes('quota') || m.includes('resource_exhausted')) {
            geminiPoolManager.reportKeyStatus(key, currentModel, { status: st === 500 ? 429 : st, message: m });
            continue;
          }
          if (st === 503 || st === 404 || m.includes('overloaded') || m.includes('not found')) {
            break;
          }
          continue;
        }
      }
    }

    // Si todas las claves y todos los modelos de la escalera fallaron
    return c.json(
      {
        error: {
          message: `Todos los modelos y claves de Gemini del pool están saturados o con cuota agotada. Último error (${lastError?.model}): ${lastError?.message}`,
          type: 'service_unavailable',
          details: lastError,
        },
      },
      503
    );
  };

  // 5. Audio Speech TTS (Gemini Live Native Voice: Sol/Aoede, Kore, Ember, Orbit/Puck, Spruce/Fenrir)
  const audioSpeechHandler = async (c: any) => {
    let body: any;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: { message: 'Invalid JSON body' } }, 400);
    }
    const text = String(body.input || body.text || '').trim();
    const voice = String(body.voice || 'Sol').trim();
    if (!text) {
      return c.json({ error: { message: 'Missing text/input' } }, 400);
    }

    const voiceLadder = getVoiceModelLadder();
    const poolKeys = Array.from(new Set([...getVoiceKeys(), ...getTextKeys()]));
    if (poolKeys.length === 0) {
      return c.json({ error: { message: 'No Gemini Live keys configured' } }, 401);
    }

    const clientIdentifier = c.req.header('x-forwarded-for') || 'wappy-dots-tts';
    let lastError: any = null;

    for (const currentModel of voiceLadder) {
      const prioritizedKeys = geminiPoolManager.getPrioritizedKeys(poolKeys, currentModel, clientIdentifier);
      for (const key of prioritizedKeys) {
        try {
          const wavBuffer = await synthesizeWithGeminiLive(text, currentModel, key, voice);
          geminiPoolManager.reportKeySuccess(key);
          return new Response(wavBuffer, {
            status: 200,
            headers: {
              'Content-Type': 'audio/wav',
              'Content-Length': String(wavBuffer.length),
              'X-Wappy-Voice-Used': voice,
            },
          });
        } catch (e: any) {
          lastError = e;
          const status = e instanceof LiveBridgeError ? e.status : 503;
          if (status === 404) {
            break;
          }
          geminiPoolManager.reportKeyStatus(key, currentModel, {
            status: status === 403 ? 403 : 429,
            message: e?.message,
          });
          continue;
        }
      }
    }

    return c.json({ error: { message: lastError?.message || 'Gemini Live TTS failed' } }, 503);
  };

  // 6. Endpoints de Orquestación Bidireccional de Antigravity + Enrutador de APIs/Modelos + Archivos Compartidos + Portal Móvil
  router.get('/ai-routing', (c) => {
    return c.json(getActiveSystemApisSync());
  });

  router.post('/ai-routing', async (c) => {
    try {
      const body = await c.req.json();
      const updated = saveAgentRoutingConfig(body);
      return c.json({
        ok: true,
        routes: updated,
        activeApis: getActiveSystemApisSync(),
      });
    } catch (e: any) {
      return c.json({ ok: false, error: e?.message || 'Invalid JSON' }, 400);
    }
  });

  router.post('/ai-routing/rotate', async (c) => {
    try {
      const body = await c.req.json().catch(() => ({}));
      const agentId = String(body.agentId || 'antigravity');
      const rotated = rotateAgentKeyNow(agentId);
      return c.json({
        ok: true,
        ...rotated,
        activeApis: getActiveSystemApisSync(),
      });
    } catch (e: any) {
      return c.json({ ok: false, error: e?.message || 'Rotation failed' }, 400);
    }
  });

  router.get('/antigravity/status', (c) => {
    return c.json(getAntigravityStatus());
  });

  router.post('/antigravity/config', async (c) => {
    try {
      const body = await c.req.json();
      const updated = saveAntigravityConfig(body);
      return c.json({ ok: true, config: updated, status: getAntigravityStatus() });
    } catch (e: any) {
      return c.json({ error: e?.message || 'Invalid JSON' }, 400);
    }
  });

  router.get('/antigravity/projects', async (c) => {
    const projects = await listAntigravityProjects();
    return c.json({ projects });
  });

  router.get('/antigravity/chats', async (c) => {
    const project = c.req.query('project') || undefined;
    const query = c.req.query('query') || undefined;
    const limit = Number(c.req.query('limit') || 20);
    const chats = await listAntigravityChats({ project, query, limit });
    return c.json({ chats });
  });

  router.get('/antigravity/chats/:id', async (c) => {
    const id = c.req.param('id');
    const detail = await readAntigravityChat(id);
    return c.json(detail);
  });

  router.get('/antigravity/shared-chat', (c) => {
    return c.json({
      ...loadSharedChat(),
      status: getAntigravityStatus(),
    });
  });

  router.post('/antigravity/execute', async (c) => {
    try {
      const body = await c.req.json();
      const toolName = String(body.tool || body.action || 'antigravity_run_task');
      const args = body.args || body;
      if (toolName === 'open_window') {
        const res = await openAntigravityInMac({
          project: args.project,
          conversationId: args.conversationId,
        });
        return c.json(res);
      }
      const res = await executeAntigravityToolCall(toolName, args);
      let parsed: any = res.resultText;
      try {
        parsed = JSON.parse(res.resultText);
      } catch {}
      return c.json({
        ok: true,
        result: parsed,
        resultText: res.resultText,
        files: res.files,
      });
    } catch (e: any) {
      return c.json({ ok: false, error: e?.message || 'Error ejecutando Antigravity' }, 500);
    }
  });

  // -------------------------------------------------------------------------
  // Endpoints del Team de Agentes de Wappy Dots (Orquestación estilo OpenClaw)
  // -------------------------------------------------------------------------
  router.get('/agent-team/agents', (c) => {
    return c.json({
      ok: true,
      agents: Object.values(TEAM_AGENTS),
    });
  });

  router.post('/agent-team/run', async (c) => {
    try {
      const body = await c.req.json();
      const goal = String(body.goal || body.prompt || '').trim();
      if (!goal) {
        return c.json({ ok: false, error: 'Se requiere un objetivo (goal) para el Team de Agentes.' }, 400);
      }
      const apiKeys = Array.from(new Set([...getTextKeys(), ...getVoiceKeys()]));
      const result = await runAgentTeamMission({
        goal,
        agents: Array.isArray(body.agents) ? (body.agents as TeamAgentId[]) : undefined,
        dynamicSubagents: Array.isArray(body.dynamicSubagents || body.dynamic_subagents)
          ? (body.dynamicSubagents || body.dynamic_subagents)
          : undefined,
        project: body.project ? String(body.project) : undefined,
        openBrowser: Boolean(body.openBrowser ?? body.open_browser ?? false),
        outputFormat: body.outputFormat || body.output_format || 'none',
        outputTitle: body.outputTitle || body.output_title || undefined,
        apiKeys,
      });
      return c.json(result);
    } catch (e: any) {
      return c.json({ ok: false, error: e?.message || 'Error ejecutando el Team de Agentes' }, 500);
    }
  });

  // -------------------------------------------------------------------------
  // Endpoints REST de Siigo API V1 (Estado, Configuración, Clientes, Facturas)
  // -------------------------------------------------------------------------
  router.get('/siigo/status', (c) => {
    return c.json(getSharedSiigoClient().getStatus());
  });

  router.post('/siigo/config', async (c) => {
    try {
      const body = await c.req.json();
      const status = getSharedSiigoClient().saveConfig(body);
      return c.json({ ok: true, status });
    } catch (e: any) {
      return c.json({ ok: false, error: e?.message || 'Error guardando configuración de Siigo' }, 400);
    }
  });

  router.post('/siigo/test', async (c) => {
    try {
      const res = await getSharedSiigoClient().testConnection();
      return c.json(res);
    } catch (e: any) {
      return c.json({ success: false, message: e?.message || 'Error probando conexión a Siigo' }, 500);
    }
  });

  router.get('/siigo/customers', async (c) => {
    try {
      const q = c.req.query();
      const res = await getSharedSiigoClient().getCustomers({
        identification: q.identification,
        name: q.name,
        page: q.page ? Number(q.page) : undefined,
        page_size: q.page_size ? Number(q.page_size) : undefined,
      });
      return c.json(res);
    } catch (e: any) {
      return c.json({ error: e?.message }, 500);
    }
  });

  router.post('/siigo/customers', async (c) => {
    try {
      const body = await c.req.json();
      const res = await getSharedSiigoClient().createCustomer(body);
      return c.json(res, 201);
    } catch (e: any) {
      return c.json({ error: e?.message }, 400);
    }
  });

  router.get('/siigo/invoices', async (c) => {
    try {
      const q = c.req.query();
      const res = await getSharedSiigoClient().getInvoices({
        date_start: q.date_start,
        date_end: q.date_end,
        customer_identification: q.customer_identification,
        page: q.page ? Number(q.page) : undefined,
        page_size: q.page_size ? Number(q.page_size) : undefined,
      });
      return c.json(res);
    } catch (e: any) {
      return c.json({ error: e?.message }, 500);
    }
  });

  router.post('/siigo/invoices', async (c) => {
    try {
      const body = await c.req.json();
      const res = await getSharedSiigoClient().createInvoice(body);
      return c.json(res, 201);
    } catch (e: any) {
      return c.json({ error: e?.message }, 400);
    }
  });

  router.get('/siigo/products', async (c) => {
    try {
      const q = c.req.query();
      const res = await getSharedSiigoClient().getProducts({
        code: q.code,
        name: q.name,
        page: q.page ? Number(q.page) : undefined,
      });
      return c.json(res);
    } catch (e: any) {
      return c.json({ error: e?.message }, 500);
    }
  });

  router.get('/siigo/vouchers', async (c) => {
    try {
      const q = c.req.query();
      const res = await getSharedSiigoClient().getVouchers({
        date_start: q.date_start,
        date_end: q.date_end,
      });
      return c.json(res);
    } catch (e: any) {
      return c.json({ error: e?.message }, 500);
    }
  });

  // -------------------------------------------------------------------------
  // Endpoints REST de Google Workspace (Gmail, Calendar, Drive, Sheets, Docs)
  // -------------------------------------------------------------------------
  router.get('/google/status', (c) => {
    return c.json(getSharedGoogleWorkspaceClient().getStatus());
  });

  router.get('/google/auth-url', (c) => {
    return c.json({ url: getSharedGoogleWorkspaceClient().getAuthUrl() });
  });

  router.post('/google/disconnect', (c) => {
    getSharedGoogleWorkspaceClient().disconnect();
    return c.json({ ok: true, message: 'Google Workspace desconectado.' });
  });

  const handleGoogleCallback = async (c: any) => {
    const code = c.req.query('code');
    const error = c.req.query('error');

    if (error) {
      return c.html(`<!DOCTYPE html><html><body style="font-family:system-ui;background:#0f172a;color:#fff;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;"><div style="background:#1e293b;padding:32px;border-radius:16px;text-align:center;"><h2>❌ Error al autorizar Google Workspace</h2><p>${error}</p></div></body></html>`, 400);
    }

    if (!code) {
      return c.html(`<!DOCTYPE html><html><body style="font-family:system-ui;background:#0f172a;color:#fff;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;"><div style="background:#1e293b;padding:32px;border-radius:16px;text-align:center;"><h2>❌ Código no proporcionado</h2></div></body></html>`, 400);
    }

    try {
      const { profile } = await getSharedGoogleWorkspaceClient().handleAuthCallback(code);
      return c.html(`<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Google Workspace Conectado</title>
</head>
<body style="font-family:-apple-system,BlinkMacSystemFont,sans-serif;background:#0f172a;color:#f8fafc;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;">
  <div style="background:#1e293b;padding:40px;border-radius:20px;text-align:center;max-width:440px;box-shadow:0 20px 25px -5px rgba(0,0,0,0.5);border:1px solid #334155;">
    <div style="font-size:48px;margin-bottom:12px;">✅</div>
    <h1 style="color:#22c55e;font-size:22px;margin:0 0 10px;">¡Google Workspace Conectado!</h1>
    <p style="font-weight:600;font-size:16px;color:#38bdf8;margin:0 0 12px;">${profile.email}</p>
    <p style="color:#94a3b8;font-size:14px;line-height:1.5;">Tu cuenta ha sido vinculada exitosamente con Wappy Dots y Tenshi.<br><br>Ya puedes cerrar esta ventana y regresar a Wappy Dots.</p>
  </div>
</body>
</html>`);
    } catch (err: any) {
      return c.html(`<!DOCTYPE html><html><body style="font-family:system-ui;background:#0f172a;color:#fff;display:flex;align-items:center;justify-content:center;height:100vh;margin:0;"><div style="background:#1e293b;padding:32px;border-radius:16px;text-align:center;"><h2>❌ Error canjeando tokens</h2><p>${err.message}</p></div></body></html>`, 500);
    }
  };

  router.get('/google/callback', handleGoogleCallback);
  router.get('/oauth/google/callback', handleGoogleCallback);

  // -------------------------------------------------------------------------
  // Endpoints del Núcleo Autónomo de Wappy Dots (Hermes + OpenClaw + OpenMausBot nativos)
  // y Conectores Opcionales Externos
  // -------------------------------------------------------------------------
  router.get('/autonomous/status', async (c) => {
    const memory = getWappyMemorySnapshot();
    const fts = getFtsStats();
    const skills = listWappySkills();
    const cronJobs = listCronJobs();
    const external = await getExternalConnectorsStatus();
    return c.json({
      ok: true,
      engine: 'Wappy Dots Autonomous Core (Hermes + OpenClaw + OpenMausBot Native)',
      memoryUpdatedAt: memory.updatedAt,
      fts,
      skillsCount: skills.length,
      skills: skills.map((s) => ({
        slug: s.slug,
        title: s.title,
        description: s.description,
        tags: s.tags,
        updatedAt: s.updatedAt,
      })),
      cronJobsCount: cronJobs.length,
      cronJobs,
      external,
    });
  });

  router.get('/memory', (c) => {
    return c.json({ ok: true, ...getWappyMemorySnapshot() });
  });

  router.post('/memory', async (c) => {
    try {
      const body = await c.req.json();
      const res = mutateWappyMemory({
        target: body.target === 'user' || body.target === 'soul' ? body.target : 'memory',
        action: body.action === 'replace' || body.action === 'remove' ? body.action : 'add',
        content: String(body.content || ''),
        oldContent: body.oldContent ? String(body.oldContent) : undefined,
      });
      return c.json(res);
    } catch (e: any) {
      return c.json({ ok: false, error: e?.message }, 400);
    }
  });

  router.post('/memory/dream', async (c) => {
    try {
      const res = await runMemoryDreamingSweep();
      return c.json(res);
    } catch (e: any) {
      return c.json({ ok: false, error: e?.message }, 500);
    }
  });

  router.get('/history/search', (c) => {
    const q = c.req.query('q') || '';
    const limit = Number(c.req.query('limit') || 8);
    const t0 = performance.now();
    const results = searchWappyHistoryFts(q, limit);
    return c.json({
      ok: true,
      query: q,
      latencyMs: Number((performance.now() - t0).toFixed(2)),
      count: results.length,
      results,
      stats: getFtsStats(),
    });
  });

  router.get('/skills', (c) => {
    const skills = listWappySkills();
    return c.json({ ok: true, count: skills.length, skills });
  });

  router.post('/skills', async (c) => {
    try {
      const body = await c.req.json();
      const saved = saveWappySkill({
        slug: String(body.slug || body.title || 'skill'),
        title: String(body.title || 'Skill Wappy Dots'),
        description: String(body.description || ''),
        tags: Array.isArray(body.tags) ? body.tags : [],
        content: String(body.content || ''),
      });
      return c.json({ ok: true, skill: saved });
    } catch (e: any) {
      return c.json({ ok: false, error: e?.message }, 400);
    }
  });

  router.get('/cron', (c) => {
    const jobs = listCronJobs();
    return c.json({ ok: true, count: jobs.length, jobs });
  });

  router.post('/cron', async (c) => {
    try {
      const body = await c.req.json();
      const job = createCronJob({
        name: String(body.name || 'Automatización Wappy Dots'),
        goal: String(body.goal || ''),
        scheduleType: body.scheduleType,
        everyMinutes: body.everyMinutes ? Number(body.everyMinutes) : undefined,
        dailyAt: body.dailyAt ? String(body.dailyAt) : undefined,
        cronExpr: body.cronExpr ? String(body.cronExpr) : undefined,
        agents: Array.isArray(body.agents) ? body.agents : undefined,
        outputFormat: body.outputFormat,
      });
      return c.json({ ok: true, job });
    } catch (e: any) {
      return c.json({ ok: false, error: e?.message }, 400);
    }
  });

  router.post('/cron/:id/run', async (c) => {
    const id = c.req.param('id');
    const res = await runCronJobNow(id);
    return c.json(res);
  });

  router.post('/cron/:id/toggle', async (c) => {
    const id = c.req.param('id');
    const body = await c.req.json().catch(() => ({}));
    const updated = toggleCronJob(id, Boolean(body.enabled));
    return c.json({ ok: Boolean(updated), job: updated });
  });

  router.delete('/cron/:id', (c) => {
    const id = c.req.param('id');
    const deleted = deleteCronJob(id);
    return c.json({ ok: deleted, id });
  });

  router.post('/approvals/request', async (c) => {
    try {
      const body = await c.req.json();
      const res = await requestNotchApproval({
        toolName: String(body.toolName || 'Acción Sensible'),
        description: String(body.description || 'Confirmar ejecución en Wappy Dots'),
        input: body.input,
        agent: body.agent,
        timeoutMs: body.timeoutMs ? Number(body.timeoutMs) : undefined,
      });
      return c.json({ ok: true, ...res });
    } catch (e: any) {
      return c.json({ ok: false, error: e?.message }, 500);
    }
  });

  router.get('/connectors', async (c) => {
    const status = await getExternalConnectorsStatus();
    return c.json({ ok: true, ...status });
  });

  router.post('/connectors/config', async (c) => {
    try {
      const body = await c.req.json();
      const saved = saveExternalConnectorsConfig(body);
      const status = await getExternalConnectorsStatus();
      return c.json({ ok: true, config: saved, ...status });
    } catch (e: any) {
      return c.json({ ok: false, error: e?.message }, 400);
    }
  });

  router.post('/connectors/delegate', async (c) => {
    try {
      const body = await c.req.json();
      const target = (body.target || 'openclaw') as ExternalAgentId;
      const goal = String(body.goal || '');
      const res = await delegateToExternalAgent({ target, goal });
      return c.json(res);
    } catch (e: any) {
      return c.json({ ok: false, error: e?.message }, 500);
    }
  });

  // Descarga / visualización directa de archivos generados (PDF, Word .docx, Excel .xlsx, HTML, Imágenes)
  router.get('/files/:fileName', (c) => {
    const fileName = c.req.param('fileName');
    const filePath = getSharedFilePath(fileName);
    if (!filePath || !existsSync(filePath)) {
      return c.json({ error: 'Archivo no encontrado' }, 404);
    }
    const ext = filePath.split('.').pop()?.toLowerCase() || '';
    const mimeMap: Record<string, string> = {
      pdf: 'application/pdf',
      html: 'text/html; charset=utf-8',
      htm: 'text/html; charset=utf-8',
      docx: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      doc: 'application/msword',
      xlsx: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      xls: 'application/vnd.ms-excel',
      csv: 'text/csv; charset=utf-8',
      png: 'image/png',
      jpg: 'image/jpeg',
      jpeg: 'image/jpeg',
      svg: 'image/svg+xml',
      webp: 'image/webp',
      gif: 'image/gif',
    };
    const contentType = mimeMap[ext] || 'application/octet-stream';
    const data = readFileSync(filePath);
    const isInline = ['html', 'htm', 'pdf', 'png', 'jpg', 'jpeg', 'svg', 'webp', 'gif'].includes(ext);
    return new Response(data, {
      status: 200,
      headers: {
        'Content-Type': contentType,
        'Content-Length': String(data.length),
        'Content-Disposition': `${isInline ? 'inline' : 'attachment'}; filename="${encodeURIComponent(fileName)}"`,
      },
    });
  });

  // Assets del Avatar Tenshi para el aplicativo móvil
  router.get('/assets/tenshi.png', (c) => {
    const candidates = [
      join(dirname(new URL(import.meta.url).pathname), 'tenshi.png'),
      join(homedir(), '.wappy', 'shared-files', 'tenshi.png'),
      '/Users/venta/Documents/GitHub/LibreChat-WAPPY/client/public/assets/tenshi.png',
      join(homedir(), '.wappy', 'coucou', 'tenshi_app_icon_1024.png'),
    ];
    for (const cand of candidates) {
      if (existsSync(cand)) {
        return new Response(readFileSync(cand), {
          headers: { 'Content-Type': 'image/png', 'Cache-Control': 'public, max-age=86400' },
        });
      }
    }
    return c.text('Not found', 404);
  });

  router.get('/icon.png', (c) => {
    const candidates = [
      join(homedir(), '.wappy', 'coucou', 'tenshi_app_icon_1024.png'),
      join(dirname(new URL(import.meta.url).pathname), 'tenshi.png'),
      join(homedir(), '.wappy', 'shared-files', 'tenshi.png'),
    ];
    for (const cand of candidates) {
      if (existsSync(cand)) {
        return new Response(readFileSync(cand), {
          headers: { 'Content-Type': 'image/png', 'Cache-Control': 'public, max-age=86400' },
        });
      }
    }
    return c.text('Not found', 404);
  });

  // Diagnóstico rápido de conectividad desde el celular (texto plano, sin JS ni imágenes)
  router.get('/ping', (c) => c.text(`Tenshi OK · servidor alcanzable · ${new Date().toISOString()}`));

  // Estado del túnel público gratuito de Cloudflare
  router.get('/public-tunnel', (c) => c.json(getPublicTunnelStatus()));

  // Portal Web Móvil sincronizado (Tenshi 3D Avatar, Voz, Chat e Informes de Antigravity)
  router.get('/mobile', (c) => {
    return c.html(getTenshiMobileAppHtml());
  });

  router.get('/models', listModelsHandler);
  router.get('/v1/models', listModelsHandler);
  router.post('/chat/completions', chatCompletionsHandler);
  router.post('/v1/chat/completions', chatCompletionsHandler);
  router.post('/audio/speech', audioSpeechHandler);
  router.post('/v1/audio/speech', audioSpeechHandler);

  return router;
}
