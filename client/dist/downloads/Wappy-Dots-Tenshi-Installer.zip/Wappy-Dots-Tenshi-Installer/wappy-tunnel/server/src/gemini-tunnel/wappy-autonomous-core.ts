import { Database } from 'bun:sqlite';
import * as fs from 'fs';
import * as net from 'net';
import * as os from 'os';
import * as path from 'path';
import { callWappyTunnelGemini } from './agent-team-orchestrator';
import { appendSharedChatMessage, loadSharedChat } from './antigravity-bridge';

const WAPPY_DIR = path.join(os.homedir(), '.wappy');
const MEMORY_DIR = path.join(WAPPY_DIR, 'memory');
const SKILLS_DIR = path.join(WAPPY_DIR, 'skills');
const CRON_FILE = path.join(WAPPY_DIR, 'cron-jobs.json');
const APPROVALS_LOG_FILE = path.join(WAPPY_DIR, 'approvals-log.json');
const STATE_DB_PATH = path.join(MEMORY_DIR, 'wappy-state.db');
const NOTCH_SOCKET_PATH = path.join(
  os.homedir(),
  'Library/Application Support/NotchBuddy/nb.sock',
);

const USER_MD_PATH = path.join(MEMORY_DIR, 'USER.md');
const MEMORY_MD_PATH = path.join(MEMORY_DIR, 'MEMORY.md');
const SOUL_MD_PATH = path.join(MEMORY_DIR, 'SOUL.md');

export interface WappyMemorySnapshot {
  userMd: string;
  memoryMd: string;
  soulMd: string;
  systemPromptBlock: string;
  updatedAt: string;
}

export interface WappySkillEntry {
  slug: string;
  title: string;
  description: string;
  tags: string[];
  updatedAt: string;
  content: string;
  filePath: string;
}

export interface FtsSearchResult {
  id: string;
  sessionId: string;
  role: string;
  source: string;
  project: string;
  snippet: string;
  content: string;
  createdAt: string;
  rank: number;
}

export interface WappyCronJob {
  id: string;
  name: string;
  goal: string;
  scheduleType: 'interval' | 'daily' | 'cron';
  everyMinutes?: number;
  dailyAt?: string; // "HH:MM"
  cronExpr?: string;
  enabled: boolean;
  agents?: string[];
  outputFormat?: 'pdf' | 'xlsx' | 'docx' | 'md' | 'none';
  createdAt: string;
  lastRunAt?: string;
  nextRunAt: string;
  lastStatus?: 'ok' | 'error' | 'running';
  lastResultSummary?: string;
}

export interface NotchApprovalRequest {
  toolName: string;
  description: string;
  input?: Record<string, any>;
  agent?: 'openclaw' | 'antigravity' | 'claude';
  timeoutMs?: number;
}

export interface NotchApprovalResult {
  approved: boolean;
  decision: 'allow' | 'deny' | 'timeout' | 'auto_allow';
  reason?: string;
  decidedAt: string;
}

function ensureDirectories(): void {
  for (const dir of [WAPPY_DIR, MEMORY_DIR, SKILLS_DIR]) {
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
  }
}

// ============================================================================
// 1. DUAL STRUCTURED MEMORY (USER.md, MEMORY.md, SOUL.md) — Inspirado en Hermes & OpenClaw
// ============================================================================

const DEFAULT_SOUL_MD = `# Identidad de Tenshi · Wappy Dots
- Nombre: Tenshi (asistente ejecutiva, ingeniera y especialista SST de Wappy Dots).
- Tono: Cálido, ejecutivo, directo, en español natural colombiano/latinoamericano.
- Regla de modelos: Utiliza siempre el Wappy Gemini Rotation Tunnel oficial (gemini-3.5-flash-lite, gemini-3.8-flash, gemini-3.6-flash para texto/agentes y gemini-3.1-flash-live-preview / gemini-3.8-live para voz).
`;

const DEFAULT_USER_MD = `# Perfil del Usuario (USER.md)
- Idioma preferido: Español.
- Rol principal: Dirección de Ingeniería, Producto y Seguridad y Salud en el Trabajo (Somos SST / Wappy).
- Preferencias de interfaz: Interacción fluida desde el Notch de macOS (Wappy Dots) y portal móvil sincronizado.
- Estilo de respuesta esperado: Datos verificados, enlaces directos cuando aplica, cero suposiciones sin fundamento.
`;

const DEFAULT_MEMORY_MD = `# Memoria Persistente de Trabajo (MEMORY.md)
- Ecosistema activo: Wappy Bot, Wappy Dots (macOS Notch), Antigravity IDE, Siigo ERP y Google Workspace.
- Normativa clave Colombia SST: Decreto 1072 de 2015, Resolución 0312 de 2019, Resolución 1843 de 2025 (evaluaciones médicas ocupacionales), GTC 45 y PESV.
- Capacidades nativas activas: Team de Agentes en paralelo, Memoria estructurada (USER.md / MEMORY.md), Búsqueda instantánea SQLite FTS5 BM25, Auto-aprendizaje de Skills (SKILL.md), Automatizaciones Cron y Aprobaciones en el Notch.
`;

function ensureMemoryFiles(): void {
  ensureDirectories();
  if (!fs.existsSync(SOUL_MD_PATH)) {
    fs.writeFileSync(SOUL_MD_PATH, DEFAULT_SOUL_MD, 'utf8');
  }
  if (!fs.existsSync(USER_MD_PATH)) {
    fs.writeFileSync(USER_MD_PATH, DEFAULT_USER_MD, 'utf8');
  }
  if (!fs.existsSync(MEMORY_MD_PATH)) {
    fs.writeFileSync(MEMORY_MD_PATH, DEFAULT_MEMORY_MD, 'utf8');
  }
}

export function getWappyMemorySnapshot(): WappyMemorySnapshot {
  ensureMemoryFiles();
  const userMd = fs.readFileSync(USER_MD_PATH, 'utf8').trim();
  const memoryMd = fs.readFileSync(MEMORY_MD_PATH, 'utf8').trim();
  const soulMd = fs.readFileSync(SOUL_MD_PATH, 'utf8').trim();

  const systemPromptBlock = [
    '══════════════════════════════════════════════',
    'MEMORIA PERSISTENTE DE WAPPY DOTS (FROZEN SNAPSHOT)',
    '══════════════════════════════════════════════',
    soulMd,
    '',
    userMd,
    '',
    memoryMd,
    '══════════════════════════════════════════════',
  ].join('\n');

  let updatedAt = new Date().toISOString();
  try {
    const stat = fs.statSync(MEMORY_MD_PATH);
    updatedAt = stat.mtime.toISOString();
  } catch {}

  return {
    userMd,
    memoryMd,
    soulMd,
    systemPromptBlock,
    updatedAt,
  };
}

export function mutateWappyMemory(params: {
  target: 'user' | 'memory' | 'soul';
  action: 'add' | 'replace' | 'remove';
  content: string;
  oldContent?: string;
}): { ok: boolean; target: string; message: string; snapshot: WappyMemorySnapshot } {
  ensureMemoryFiles();
  const filePath =
    params.target === 'user'
      ? USER_MD_PATH
      : params.target === 'soul'
        ? SOUL_MD_PATH
        : MEMORY_MD_PATH;

  let current = fs.readFileSync(filePath, 'utf8');
  const cleanEntry = params.content.trim().replace(/^[-*•]\s*/, '');

  if (params.action === 'add') {
    if (!cleanEntry) {
      return {
        ok: false,
        target: params.target,
        message: 'El contenido a guardar está vacío.',
        snapshot: getWappyMemorySnapshot(),
      };
    }
    const bullet = `- ${cleanEntry}`;
    if (!current.toLowerCase().includes(cleanEntry.toLowerCase())) {
      current = `${current.trim()}\n${bullet}\n`;
      fs.writeFileSync(filePath, current, 'utf8');
    }
    indexSessionMessageFts({
      sessionId: `memory_${params.target}`,
      role: 'system',
      source: 'memory',
      project: 'Wappy Memory',
      content: cleanEntry,
    });
    return {
      ok: true,
      target: params.target,
      message: `Hecho guardado en ${params.target.toUpperCase()}.md`,
      snapshot: getWappyMemorySnapshot(),
    };
  }

  if (params.action === 'replace' && params.oldContent) {
    const lines = current.split('\n');
    const needle = params.oldContent.trim().toLowerCase();
    let replaced = false;
    const updatedLines = lines.map((line) => {
      if (!replaced && line.toLowerCase().includes(needle)) {
        replaced = true;
        return `- ${cleanEntry}`;
      }
      return line;
    });
    if (!replaced) {
      updatedLines.push(`- ${cleanEntry}`);
    }
    fs.writeFileSync(filePath, `${updatedLines.join('\n').trim()}\n`, 'utf8');
    return {
      ok: true,
      target: params.target,
      message: `Entrada actualizada en ${params.target.toUpperCase()}.md`,
      snapshot: getWappyMemorySnapshot(),
    };
  }

  if (params.action === 'remove') {
    const needle = (params.oldContent || params.content).trim().toLowerCase();
    const lines = current.split('\n');
    const filtered = lines.filter((line) => !line.toLowerCase().includes(needle));
    fs.writeFileSync(filePath, `${filtered.join('\n').trim()}\n`, 'utf8');
    return {
      ok: true,
      target: params.target,
      message: `Entrada eliminada de ${params.target.toUpperCase()}.md`,
      snapshot: getWappyMemorySnapshot(),
    };
  }

  return {
    ok: false,
    target: params.target,
    message: 'Acción no reconocida.',
    snapshot: getWappyMemorySnapshot(),
  };
}

/**
 * Consolidación inteligente de memoria ("Memory Dreaming" inspirado en OpenClaw memory-core).
 * Analiza las conversaciones recientes y compacta/enriquece USER.md y MEMORY.md usando el túnel oficial Wappy.
 */
export async function runMemoryDreamingSweep(): Promise<{
  ok: boolean;
  addedFacts: string[];
  modelUsed: string;
}> {
  const snap = getWappyMemorySnapshot();
  const recentMessages = (loadSharedChat().messages || []).slice(-25);
  const recentTranscript = recentMessages
    .map((m) => `[${m.role.toUpperCase()} · ${m.source}]: ${m.content.slice(0, 350)}`)
    .join('\n');

  if (!recentTranscript.trim()) {
    return { ok: true, addedFacts: [], modelUsed: 'none' };
  }

  const prompt = `Eres el motor de consolidación de memoria ("Dreaming") de Wappy Dots.
Revisa la memoria actual y la transcripción reciente de sesiones para extraer ÚNICAMENTE hechos duraderos nuevos sobre el usuario, sus empresas, proyectos o configuraciones que aún no estén en MEMORY.md o USER.md.

[USER.md ACTUAL]
${snap.userMd}

[MEMORY.md ACTUAL]
${snap.memoryMd}

[CONVERSACIONES RECIENTES]
${recentTranscript}

Responde EXCLUSIVAMENTE en formato JSON válido sin bloques markdown adicionales:
{
  "userFacts": ["hecho nuevo sobre preferencias del usuario (máximo 2)"],
  "memoryFacts": ["hecho duradero nuevo sobre proyectos, normas, empresas o flujos (máximo 4)"]
}`;

  const { text, modelUsed } = await callWappyTunnelGemini(prompt, {
    agentRouteId: 'agent_team',
    useWebSearch: false,
  });

  const addedFacts: string[] = [];
  try {
    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (jsonMatch) {
      const parsed = JSON.parse(jsonMatch[0]);
      if (Array.isArray(parsed.userFacts)) {
        for (const f of parsed.userFacts) {
          if (typeof f === 'string' && f.trim().length > 8) {
            mutateWappyMemory({ target: 'user', action: 'add', content: f.trim() });
            addedFacts.push(`[USER] ${f.trim()}`);
          }
        }
      }
      if (Array.isArray(parsed.memoryFacts)) {
        for (const f of parsed.memoryFacts) {
          if (typeof f === 'string' && f.trim().length > 8) {
            mutateWappyMemory({ target: 'memory', action: 'add', content: f.trim() });
            addedFacts.push(`[MEMORY] ${f.trim()}`);
          }
        }
      }
    }
  } catch {}

  return { ok: true, addedFacts, modelUsed };
}

// ============================================================================
// 2. DETERMINISTIC SESSION & SKILL RECALL VIA SQLite FTS5 (BM25) — Inspirado en Hermes state.db
// ============================================================================

let sqliteDb: Database | null = null;
let backfilledSharedChat = false;

function getStateDb(): Database {
  ensureDirectories();
  if (!sqliteDb) {
    sqliteDb = new Database(STATE_DB_PATH, { create: true });
    sqliteDb.exec('PRAGMA journal_mode = WAL;');
    sqliteDb.exec('PRAGMA synchronous = NORMAL;');
    sqliteDb.exec(`
      CREATE TABLE IF NOT EXISTS sessions_log (
        id TEXT PRIMARY KEY,
        session_id TEXT NOT NULL,
        role TEXT NOT NULL,
        source TEXT NOT NULL,
        project TEXT NOT NULL,
        content TEXT NOT NULL,
        created_at TEXT NOT NULL
      );
      CREATE VIRTUAL TABLE IF NOT EXISTS sessions_fts USING fts5(
        id UNINDEXED,
        session_id UNINDEXED,
        role UNINDEXED,
        source,
        project,
        content,
        created_at UNINDEXED,
        tokenize = 'porter unicode61'
      );
    `);
  }
  if (!backfilledSharedChat) {
    backfilledSharedChat = true;
    try {
      const existing = (loadSharedChat().messages || []).slice(-120);
      for (const msg of existing) {
        indexSessionMessageFts({
          id: msg.id,
          sessionId: msg.id,
          role: msg.role,
          source: msg.source,
          project: msg.project || 'General',
          content: msg.content,
          createdAt: msg.createdAt,
        });
      }
    } catch {}
  }
  return sqliteDb;
}

export function indexSessionMessageFts(entry: {
  id?: string;
  sessionId: string;
  role: string;
  source: string;
  project?: string;
  content: string;
  createdAt?: string;
}): void {
  if (!entry.content || !entry.content.trim()) return;
  try {
    const db = getStateDb();
    const id = entry.id || `fts_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
    const createdAt = entry.createdAt || new Date().toISOString();
    const project = entry.project || 'Wappy Dots';

    const exists = db.query('SELECT id FROM sessions_log WHERE id = ?').get(id);
    if (exists) return;

    db.query(
      'INSERT INTO sessions_log (id, session_id, role, source, project, content, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
    ).run(id, entry.sessionId, entry.role, entry.source, project, entry.content, createdAt);

    db.query(
      'INSERT INTO sessions_fts (id, session_id, role, source, project, content, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
    ).run(id, entry.sessionId, entry.role, entry.source, project, entry.content, createdAt);
  } catch {}
}

export function searchWappyHistoryFts(query: string, limit = 8): FtsSearchResult[] {
  const db = getStateDb();
  const raw = query.trim();
  if (!raw) return [];

  // Sanitizar tokens para FTS5 BM25
  const cleanTokens = raw
    .replace(/[^\p{L}\p{N}\s]/gu, ' ')
    .split(/\s+/)
    .filter((t) => t.length >= 2)
    .slice(0, 8);

  if (cleanTokens.length === 0) return [];

  const ftsQuery = cleanTokens.map((t) => `"${t}"*`).join(' OR ');

  try {
    const rows = db
      .query(
        `
        SELECT
          id,
          session_id as sessionId,
          role,
          source,
          project,
          snippet(sessions_fts, 5, '[', ']', ' … ', 28) as snippet,
          content,
          created_at as createdAt,
          bm25(sessions_fts) as rank
        FROM sessions_fts
        WHERE sessions_fts MATCH ?
        ORDER BY rank
        LIMIT ?
      `,
      )
      .all(ftsQuery, limit) as FtsSearchResult[];

    return rows;
  } catch {
    // Fallback determinista con LIKE si la consulta tiene caracteres especiales
    const likePattern = `%${cleanTokens[0]}%`;
    const rows = db
      .query(
        `
        SELECT
          id,
          session_id as sessionId,
          role,
          source,
          project,
          substr(content, 1, 240) as snippet,
          content,
          created_at as createdAt,
          0 as rank
        FROM sessions_log
        WHERE content LIKE ?
        ORDER BY created_at DESC
        LIMIT ?
      `,
      )
      .all(likePattern, limit) as FtsSearchResult[];
    return rows;
  }
}

export function getFtsStats(): { totalIndexedMessages: number; dbPath: string } {
  try {
    const db = getStateDb();
    const row = db.query('SELECT COUNT(*) as count FROM sessions_log').get() as { count: number };
    return { totalIndexedMessages: row?.count || 0, dbPath: STATE_DB_PATH };
  } catch {
    return { totalIndexedMessages: 0, dbPath: STATE_DB_PATH };
  }
}

// ============================================================================
// 3. PROCEDURAL SKILLS SYSTEM (SKILL.md) & AUTO-SYNTHESIS LEARNING LOOP — Inspirado en Hermes
// ============================================================================

const BUILTIN_SKILLS: Array<{
  slug: string;
  title: string;
  description: string;
  tags: string[];
  content: string;
}> = [
  {
    slug: 'sgsst-auditoria-colombia',
    title: 'Auditoría SG-SST Colombia (Res. 0312 de 2019 & Res. 1843 de 2025)',
    description:
      'Procedimiento estándar para auditar estándares mínimos SG-SST, matriz GTC 45 y evaluaciones médicas ocupacionales vigentes en Colombia.',
    tags: ['sst', 'colombia', '0312', '1843', 'gtc45', 'auditoria'],
    content: `## Objetivo
Ejecutar una revisión técnica del SG-SST en Colombia asegurando vigencia normativa 2025-2026.

## Pasos Obligatorios
1. Verificar clasificación de empresa (número de trabajadores y nivel de riesgo I a V según Resolución 0312 de 2019).
2. Validar evaluaciones médicas ocupacionales conforme a la **Resolución 1843 de 2025** (que derogó la Resolución 2346 de 2007 y 1918 de 2009).
3. Revisar matriz de peligros bajo metodología **GTC 45** y controles jerárquicos (eliminación, sustitución, controles de ingeniería, administrativos y EPP).
4. Entregar tabla ejecutiva de hallazgos con artículo normativo exacto y plan de acción.`,
  },
  {
    slug: 'siigo-facturacion-cartera',
    title: 'Diagnóstico Ejecutivo de Facturación y Cartera en Siigo ERP',
    description:
      'Flujo para consultar clientes, facturas pendientes, notas crédito y saldos vencidos desde el conector Siigo ERP de Wappy Dots.',
    tags: ['siigo', 'erp', 'facturas', 'cartera', 'clientes', 'contabilidad'],
    content: `## Objetivo
Consultar el estado comercial y contable en tiempo real desde Siigo Nube.

## Pasos Obligatorios
1. Verificar estado de conexión del cliente Siigo (\`getSharedSiigoClient().getConnectionStatus()\`).
2. Consultar clientes recientes y facturas emitidas para identificar saldos pendientes o vencimientos.
3. Si el usuario solicita emitir factura o modificar registros contables, solicitar aprobación en el Notch (\`requestNotchApproval\`) antes de ejecutar la escritura.`,
  },
  {
    slug: 'antigravity-deploy-pipeline',
    title: 'Inspección y Despliegue Asistido con Antigravity IDE',
    description:
      'Procedimiento para coordinar tareas de código, revisar conversaciones activas de Antigravity y validar compilación limpia.',
    tags: ['antigravity', 'codigo', 'deploy', 'build', 'ingenieria'],
    content: `## Objetivo
Coordinar diagnósticos o mejoras de código entre Wappy Dots y Antigravity IDE.

## Pasos Obligatorios
1. Consultar proyectos locales y sesiones recientes de Antigravity (\`listAntigravityProjects\`, \`listAntigravityChats\`).
2. Sintetizar los archivos tocados y decisiones arquitectónicas antes de proponer cambios.
3. Ofrecer abrir directamente la ventana de Antigravity o generar el informe técnico en PDF/Markdown.`,
  },
];

function ensureBuiltinSkills(): void {
  ensureDirectories();
  for (const skill of BUILTIN_SKILLS) {
    const dir = path.join(SKILLS_DIR, skill.slug);
    const filePath = path.join(dir, 'SKILL.md');
    if (!fs.existsSync(filePath)) {
      fs.mkdirSync(dir, { recursive: true });
      const fileContent = formatSkillMarkdown({
        slug: skill.slug,
        title: skill.title,
        description: skill.description,
        tags: skill.tags,
        updatedAt: new Date().toISOString(),
        content: skill.content,
      });
      fs.writeFileSync(filePath, fileContent, 'utf8');
    }
  }
}

function formatSkillMarkdown(skill: Omit<WappySkillEntry, 'filePath'>): string {
  return [
    '---',
    `name: ${skill.slug}`,
    `title: ${skill.title.replace(/:/g, ' -')}`,
    `description: ${skill.description.replace(/\n/g, ' ')}`,
    `tags: [${skill.tags.join(', ')}]`,
    `updatedAt: ${skill.updatedAt}`,
    '---',
    '',
    skill.content.trim(),
    '',
  ].join('\n');
}

function parseSkillFile(slug: string, filePath: string): WappySkillEntry | null {
  try {
    const raw = fs.readFileSync(filePath, 'utf8');
    const fmMatch = raw.match(/^---\n([\s\S]*?)\n---\n([\s\S]*)$/);
    let title = slug;
    let description = '';
    let tags: string[] = [];
    let updatedAt = new Date().toISOString();
    let content = raw;

    if (fmMatch) {
      const fm = fmMatch[1];
      content = fmMatch[2].trim();
      const titleMatch = fm.match(/^title:\s*(.+)$/m);
      const descMatch = fm.match(/^description:\s*(.+)$/m);
      const tagsMatch = fm.match(/^tags:\s*\[([^\]]*)\]$/m);
      const updatedMatch = fm.match(/^updatedAt:\s*(.+)$/m);
      if (titleMatch) title = titleMatch[1].trim();
      if (descMatch) description = descMatch[1].trim();
      if (tagsMatch) {
        tags = tagsMatch[1]
          .split(',')
          .map((t) => t.trim())
          .filter(Boolean);
      }
      if (updatedMatch) updatedAt = updatedMatch[1].trim();
    }

    return {
      slug,
      title,
      description,
      tags,
      updatedAt,
      content,
      filePath,
    };
  } catch {
    return null;
  }
}

export function listWappySkills(): WappySkillEntry[] {
  ensureBuiltinSkills();
  const entries: WappySkillEntry[] = [];
  try {
    const dirs = fs.readdirSync(SKILLS_DIR, { withFileTypes: true });
    for (const d of dirs) {
      if (!d.isDirectory()) continue;
      const skillFile = path.join(SKILLS_DIR, d.name, 'SKILL.md');
      if (fs.existsSync(skillFile)) {
        const parsed = parseSkillFile(d.name, skillFile);
        if (parsed) entries.push(parsed);
      }
    }
  } catch {}
  return entries.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt));
}

export function saveWappySkill(input: {
  slug: string;
  title: string;
  description: string;
  tags?: string[];
  content: string;
}): WappySkillEntry {
  ensureBuiltinSkills();
  const cleanSlug =
    input.slug
      .toLowerCase()
      .replace(/[^a-z0-9-_]+/g, '-')
      .replace(/^-+|-+$/g, '') || `skill-${Date.now().toString(36)}`;

  const dir = path.join(SKILLS_DIR, cleanSlug);
  fs.mkdirSync(dir, { recursive: true });
  const filePath = path.join(dir, 'SKILL.md');
  const updatedAt = new Date().toISOString();
  const tags = input.tags || [];

  const md = formatSkillMarkdown({
    slug: cleanSlug,
    title: input.title,
    description: input.description,
    tags,
    updatedAt,
    content: input.content,
  });
  fs.writeFileSync(filePath, md, 'utf8');

  indexSessionMessageFts({
    id: `skill_${cleanSlug}`,
    sessionId: `skill_${cleanSlug}`,
    role: 'system',
    source: 'skill',
    project: 'Wappy Skills',
    content: `${input.title} - ${input.description}\n${input.content}`,
    createdAt: updatedAt,
  });

  return {
    slug: cleanSlug,
    title: input.title,
    description: input.description,
    tags,
    updatedAt,
    content: input.content,
    filePath,
  };
}

export function findRelevantSkillsForGoal(goal: string, maxResults = 2): WappySkillEntry[] {
  const all = listWappySkills();
  const lower = goal.toLowerCase();
  const scored = all.map((skill) => {
    let score = 0;
    for (const tag of skill.tags) {
      if (lower.includes(tag.toLowerCase())) score += 3;
    }
    const words = skill.title
      .toLowerCase()
      .split(/\s+/)
      .filter((w) => w.length > 3);
    for (const w of words) {
      if (lower.includes(w)) score += 1;
    }
    return { skill, score };
  });

  return scored
    .filter((s) => s.score > 0)
    .sort((a, b) => b.score - a.score)
    .slice(0, maxResults)
    .map((s) => s.skill);
}

/**
 * Self-Improving Background Learning Review (inspirado en Hermes `agent/background_review.py`).
 * Se ejecuta en segundo plano tras finalizar una misión del Team de Agentes sin bloquear al usuario.
 */
export async function runBackgroundLearningReview(params: {
  missionId: string;
  goal: string;
  synthesis: string;
  stepsCount: number;
}): Promise<void> {
  try {
    if (!params.synthesis || params.synthesis.length < 180) return;

    const existingSkills = listWappySkills()
      .map((s) => `- ${s.slug}: ${s.title}`)
      .join('\n');

    const reviewPrompt = `Eres el evaluador de auto-aprendizaje en segundo plano de Wappy Dots (estilo Hermes Background Review).
Acaba de completarse la siguiente misión ejecutada por el Team de Agentes:

[MISIÓN]
${params.goal}

[SÍNTESIS RESULTANTE]
${params.synthesis.slice(0, 2200)}

[SKILLS YA EXISTENTES]
${existingSkills}

Evalúa si esta misión reveló:
1. Un hecho clave y permanente que valga la pena guardar en MEMORY.md (por ejemplo: una norma específica, un dato clave del negocio o un hallazgo verificado).
2. Un procedimiento técnico reutilizable nuevo que deba guardarse como Skill (solo si la misión fue compleja y no está cubierta por las skills existentes).

Responde EXCLUSIVAMENTE en JSON válido sin bloques markdown:
{
  "memoryFact": "string opcional con un hecho concreto de 1 línea para MEMORY.md, o vacío",
  "newSkill": null o {
    "slug": "identificador-kebab-case",
    "title": "Título del procedimiento",
    "description": " Cuándo usar este procedimiento",
    "tags": ["tag1", "tag2"],
    "content": "## Objetivo\\n...\\n## Pasos Clave\\n1. ..."
  }
}`;

    const { text } = await callWappyTunnelGemini(reviewPrompt, {
      agentRouteId: 'agent_team',
      useWebSearch: false,
    });

    const jsonMatch = text.match(/\{[\s\S]*\}/);
    if (!jsonMatch) return;
    const parsed = JSON.parse(jsonMatch[0]);

    if (typeof parsed.memoryFact === 'string' && parsed.memoryFact.trim().length > 12) {
      mutateWappyMemory({
        target: 'memory',
        action: 'add',
        content: parsed.memoryFact.trim(),
      });
    }

    if (
      parsed.newSkill &&
      typeof parsed.newSkill.slug === 'string' &&
      typeof parsed.newSkill.title === 'string' &&
      typeof parsed.newSkill.content === 'string' &&
      parsed.newSkill.content.length > 40
    ) {
      saveWappySkill({
        slug: parsed.newSkill.slug,
        title: parsed.newSkill.title,
        description: parsed.newSkill.description || parsed.newSkill.title,
        tags: Array.isArray(parsed.newSkill.tags) ? parsed.newSkill.tags : ['auto-learned'],
        content: parsed.newSkill.content,
      });
    }
  } catch {}
}

// ============================================================================
// 4. HUMAN-IN-THE-LOOP ACTION APPROVALS IN THE NOTCH — Inspirado en OpenClaw & OpenMausBot
// ============================================================================

const SENSITIVE_TOOL_PATTERNS = [
  /delete|eliminar|borrar|drop|destroy/i,
  /create_invoice|emitir_factura|send_email|enviar_correo/i,
  /rm\s+-rf|git\s+push\s+--force/i,
];

export function requiresHumanApproval(toolName: string, description = ''): boolean {
  const combined = `${toolName} ${description}`;
  return SENSITIVE_TOOL_PATTERNS.some((re) => re.test(combined));
}

function logApprovalEvent(entry: Record<string, any>): void {
  try {
    ensureDirectories();
    let list: any[] = [];
    if (fs.existsSync(APPROVALS_LOG_FILE)) {
      list = JSON.parse(fs.readFileSync(APPROVALS_LOG_FILE, 'utf8'));
    }
    list.unshift(entry);
    fs.writeFileSync(APPROVALS_LOG_FILE, JSON.stringify(list.slice(0, 60), null, 2), 'utf8');
  } catch {}
}

/**
 * Envía una solicitud interactiva `PermissionRequest` al socket `nb.sock` del Notch de macOS
 * y espera la decisión en vivo del usuario (Approve / Deny).
 */
export async function requestNotchApproval(
  req: NotchApprovalRequest,
): Promise<NotchApprovalResult> {
  const timeoutMs = req.timeoutMs || 45000;
  const sessionId = `approval_${Date.now().toString(36)}`;
  const agent = req.agent || 'openclaw';

  if (!fs.existsSync(NOTCH_SOCKET_PATH)) {
    const fallback: NotchApprovalResult = {
      approved: true,
      decision: 'auto_allow',
      reason: 'Socket del Notch no disponible en este instante; permitido por política local.',
      decidedAt: new Date().toISOString(),
    };
    logApprovalEvent({ ...req, ...fallback });
    return fallback;
  }

  return new Promise<NotchApprovalResult>((resolve) => {
    let settled = false;
    let buffer = '';

    const socket = net.createConnection(NOTCH_SOCKET_PATH);
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      try {
        socket.destroy();
      } catch {}
      const res: NotchApprovalResult = {
        approved: false,
        decision: 'timeout',
        reason: 'Tiempo de espera agotado esperando aprobación en el Notch.',
        decidedAt: new Date().toISOString(),
      };
      logApprovalEvent({ ...req, ...res });
      resolve(res);
    }, timeoutMs);

    socket.on('connect', () => {
      const payload = {
        hook_event_name: 'PermissionRequest',
        coucou_agent: agent,
        session_id: sessionId,
        cwd: 'Aprobación · Wappy Dots',
        tool_name: req.toolName,
        tool_use_id: `tu_${Date.now()}`,
        tool_input: {
          command: req.description,
          ...(req.input || {}),
        },
      };
      socket.write(`${JSON.stringify(payload)}\n`);
    });

    socket.on('data', (chunk) => {
      buffer += chunk.toString('utf8');
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';
      for (const line of lines) {
        if (!line.trim()) continue;
        try {
          const parsed = JSON.parse(line);
          if (!settled) {
            settled = true;
            clearTimeout(timer);
            try {
              socket.end();
            } catch {}
            const isAllow = parsed.decision === 'allow';
            const res: NotchApprovalResult = {
              approved: isAllow,
              decision: isAllow ? 'allow' : 'deny',
              reason: parsed.reason,
              decidedAt: new Date().toISOString(),
            };
            logApprovalEvent({ ...req, ...res });
            resolve(res);
          }
        } catch {}
      }
    });

    socket.on('error', () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      const res: NotchApprovalResult = {
        approved: true,
        decision: 'auto_allow',
        reason: 'Notch sin respuesta activa; auto-aprobado.',
        decidedAt: new Date().toISOString(),
      };
      logApprovalEvent({ ...req, ...res });
      resolve(res);
    });
  });
}

// ============================================================================
// 5. SCHEDULED CRON AUTOMATION ENGINE — Inspirado en OpenClaw Cron & Hermes Scheduler
// ============================================================================

function computeNextRunAt(job: {
  scheduleType: 'interval' | 'daily' | 'cron';
  everyMinutes?: number;
  dailyAt?: string;
}): string {
  const now = new Date();
  if (job.scheduleType === 'daily' && job.dailyAt) {
    const [hh, mm] = job.dailyAt.split(':').map((n) => parseInt(n, 10));
    const candidate = new Date(now);
    candidate.setHours(Number.isFinite(hh) ? hh : 8, Number.isFinite(mm) ? mm : 0, 0, 0);
    if (candidate.getTime() <= now.getTime()) {
      candidate.setDate(candidate.getDate() + 1);
    }
    return candidate.toISOString();
  }
  const minutes = Math.max(5, job.everyMinutes || 60);
  return new Date(now.getTime() + minutes * 60 * 1000).toISOString();
}

export function listCronJobs(): WappyCronJob[] {
  ensureDirectories();
  if (!fs.existsSync(CRON_FILE)) {
    return [];
  }
  try {
    const raw = JSON.parse(fs.readFileSync(CRON_FILE, 'utf8'));
    return Array.isArray(raw) ? raw : [];
  } catch {
    return [];
  }
}

function saveCronJobs(jobs: WappyCronJob[]): void {
  ensureDirectories();
  fs.writeFileSync(CRON_FILE, JSON.stringify(jobs, null, 2), 'utf8');
}

export function createCronJob(input: {
  name: string;
  goal: string;
  scheduleType?: 'interval' | 'daily' | 'cron';
  everyMinutes?: number;
  dailyAt?: string;
  cronExpr?: string;
  agents?: string[];
  outputFormat?: 'pdf' | 'xlsx' | 'docx' | 'md' | 'none';
}): WappyCronJob {
  const jobs = listCronJobs();
  const scheduleType = input.scheduleType || (input.dailyAt ? 'daily' : 'interval');
  const newJob: WappyCronJob = {
    id: `cron_${Date.now().toString(36)}`,
    name: input.name.trim() || `Automatización ${jobs.length + 1}`,
    goal: input.goal.trim(),
    scheduleType,
    everyMinutes: input.everyMinutes || 60,
    dailyAt: input.dailyAt,
    cronExpr: input.cronExpr,
    enabled: true,
    agents: input.agents,
    outputFormat: input.outputFormat || 'none',
    createdAt: new Date().toISOString(),
    nextRunAt: computeNextRunAt({
      scheduleType,
      everyMinutes: input.everyMinutes,
      dailyAt: input.dailyAt,
    }),
  };
  jobs.unshift(newJob);
  saveCronJobs(jobs);
  return newJob;
}

export function deleteCronJob(id: string): boolean {
  const jobs = listCronJobs();
  const filtered = jobs.filter((j) => j.id !== id);
  if (filtered.length === jobs.length) return false;
  saveCronJobs(filtered);
  return true;
}

export function toggleCronJob(id: string, enabled: boolean): WappyCronJob | null {
  const jobs = listCronJobs();
  const target = jobs.find((j) => j.id === id);
  if (!target) return null;
  target.enabled = enabled;
  if (enabled) {
    target.nextRunAt = computeNextRunAt(target);
  }
  saveCronJobs(jobs);
  return target;
}

let cronRunnerCallback: ((job: WappyCronJob) => Promise<string>) | null = null;
let cronIntervalHandle: ReturnType<typeof setInterval> | null = null;

export function registerCronRunner(runner: (job: WappyCronJob) => Promise<string>): void {
  cronRunnerCallback = runner;
  if (!cronIntervalHandle) {
    cronIntervalHandle = setInterval(() => {
      void tickCronScheduler();
    }, 30000);
  }
}

export async function runCronJobNow(id: string): Promise<{
  ok: boolean;
  job?: WappyCronJob;
  summary?: string;
  error?: string;
}> {
  const jobs = listCronJobs();
  const job = jobs.find((j) => j.id === id);
  if (!job) {
    return { ok: false, error: `No existe el job ${id}` };
  }
  if (!cronRunnerCallback) {
    return { ok: false, error: 'El motor de ejecución Cron aún no está registrado.' };
  }

  job.lastStatus = 'running';
  job.lastRunAt = new Date().toISOString();
  saveCronJobs(jobs);

  try {
    const summary = await cronRunnerCallback(job);
    const updatedJobs = listCronJobs();
    const target = updatedJobs.find((j) => j.id === id);
    if (target) {
      target.lastStatus = 'ok';
      target.lastRunAt = new Date().toISOString();
      target.lastResultSummary = summary.slice(0, 400);
      target.nextRunAt = computeNextRunAt(target);
      saveCronJobs(updatedJobs);
    }
    return { ok: true, job: target || job, summary };
  } catch (err: any) {
    const updatedJobs = listCronJobs();
    const target = updatedJobs.find((j) => j.id === id);
    if (target) {
      target.lastStatus = 'error';
      target.lastResultSummary = err?.message || 'Error ejecutando tarea programada';
      target.nextRunAt = computeNextRunAt(target);
      saveCronJobs(updatedJobs);
    }
    return { ok: false, job: target || job, error: err?.message };
  }
}

async function tickCronScheduler(): Promise<void> {
  if (!cronRunnerCallback) return;
  const jobs = listCronJobs();
  const nowMs = Date.now();
  for (const job of jobs) {
    if (!job.enabled || job.lastStatus === 'running') continue;
    const nextMs = Date.parse(job.nextRunAt);
    if (Number.isFinite(nextMs) && nextMs <= nowMs) {
      await runCronJobNow(job.id);
    }
  }
}

// ============================================================================
// 6. INBOUND MESSAGE DEBOUNCING & BURST COALESCING — Inspirado en OpenClaw Inbound Debounce
// ============================================================================

interface PendingBurst {
  messages: string[];
  timer: ReturnType<typeof setTimeout>;
  resolvers: Array<(coalescedText: string | null) => void>;
}

const activeBursts = new Map<string, PendingBurst>();

/**
 * Agrupa ráfagas rápidas de mensajes del mismo canal/remitente (ventana de 1.8s por defecto)
 * para que Tenshi procese el contexto completo en una sola respuesta coherente.
 */
export function coalesceInboundMessageBurst(
  senderKey: string,
  messageText: string,
  windowMs = 1800,
): Promise<string | null> {
  if (windowMs <= 0) {
    return Promise.resolve(messageText);
  }

  return new Promise((resolve) => {
    const existing = activeBursts.get(senderKey);
    if (existing) {
      clearTimeout(existing.timer);
      existing.messages.push(messageText.trim());
      // Los mensajes intermedios resuelven null para indicar que fueron fusionados en el último turno
      const prevResolvers = existing.resolvers.splice(0, existing.resolvers.length);
      for (const r of prevResolvers) {
        r(null);
      }
      existing.resolvers.push(resolve);
      existing.timer = setTimeout(() => {
        const finalBurst = activeBursts.get(senderKey);
        activeBursts.delete(senderKey);
        if (finalBurst) {
          const joined = finalBurst.messages.filter(Boolean).join('\n');
          for (const r of finalBurst.resolvers) {
            r(joined);
          }
        }
      }, windowMs);
    } else {
      const burst: PendingBurst = {
        messages: [messageText.trim()],
        resolvers: [resolve],
        timer: setTimeout(() => {
          const finalBurst = activeBursts.get(senderKey);
          activeBursts.delete(senderKey);
          if (finalBurst) {
            const joined = finalBurst.messages.filter(Boolean).join('\n');
            for (const r of finalBurst.resolvers) {
              r(joined);
            }
          }
        }, windowMs),
      };
      activeBursts.set(senderKey, burst);
    }
  });
}
