/**
 * Definiciones de tipos e interfaces para la integración oficial de Siigo API V1.
 * Especificación: https://siigoapi.docs.apiary.io/
 */

export interface SiigoAuthConfig {
  username?: string;
  access_key?: string;
  partner_id?: string;
  sandbox?: boolean;
  base_url?: string;
  auth_url?: string;
}

export interface SiigoAuthResponse {
  access_token: string;
  expires_in: number;
  token_type: string;
  scope?: string;
}

export interface SiigoAddress {
  address: string;
  city?: {
    country_code?: string; // ej. "Co"
    country_name?: string;
    state_code?: string;   // ej. "11"
    state_name?: string;
    city_code?: string;    // ej. "11001"
    city_name?: string;
  };
  postal_code?: string;
}

export interface SiigoPhone {
  indicative?: string;
  number: string;
  extension?: string;
}

export interface SiigoContact {
  first_name: string;
  last_name?: string;
  email?: string;
  phone?: SiigoPhone;
}

export interface SiigoFiscalResponsibility {
  code: string; // ej. "O-13", "R-99-PN"
  name?: string;
}

export interface SiigoCustomer {
  id?: string; // UUID asignado por Siigo
  type?: 'Customer' | 'Supplier' | 'Other';
  person_type?: 'Person' | 'Company';
  id_type?: string; // "13" Cédula de ciudadanía, "31" NIT, "22" Cédula de extranjería, "41" Pasaporte
  identification: string;
  check_digit?: string;
  name: string[]; // ['Juan', 'Perez'] para persona natural, ['Mi Empresa SAS'] para persona jurídica
  commercial_name?: string;
  branch_office?: number;
  active?: boolean;
  vat_responsible?: boolean;
  fiscal_responsibilities?: SiigoFiscalResponsibility[];
  address?: SiigoAddress;
  phones?: SiigoPhone[];
  contacts?: SiigoContact[];
  comments?: string;
  created_at?: string;
  metadata?: Record<string, any>;
}

export interface SiigoInvoiceTax {
  id: number;
  name?: string;
  percentage?: number;
  value?: number;
}

export interface SiigoInvoiceItem {
  code: string;
  description?: string;
  quantity: number;
  price: number;
  discount?: number;
  taxes?: SiigoInvoiceTax[];
  total?: number;
}

export interface SiigoInvoicePayment {
  id: number;
  value: number;
  due_date?: string;
  name?: string;
}

export interface SiigoInvoice {
  id?: string;
  document?: {
    id: number;
  };
  prefix?: string;
  number?: number;
  name?: string;
  date: string;
  customer: {
    id?: string;
    identification: string;
    branch_office?: number;
    name?: string | string[];
    commercial_name?: string;
  };
  cost_center?: number;
  currency?: {
    code: string;
    exchange_rate?: number;
  };
  seller?: number;
  stamp?: {
    status?: string;
  };
  mail?: {
    status?: string;
  };
  observations?: string;
  items: SiigoInvoiceItem[];
  payments: SiigoInvoicePayment[];
  total?: number;
  balance?: number;
  metadata?: {
    created?: string;
    [key: string]: any;
  };
  public_url?: string;
}

export interface SiigoProductPrice {
  currency_code?: string;
  price_list?: Array<{
    position: number;
    value: number;
    name?: string;
  }>;
}

export interface SiigoProductTax {
  id: number;
  name?: string;
  percentage?: number;
  type?: string;
}

export interface SiigoProduct {
  id?: string;
  code: string;
  name: string;
  account_group?: number;
  type?: 'Product' | 'Service' | 'ConsumerGood';
  stock_control?: boolean;
  active?: boolean;
  tax_classification?: 'Taxed' | 'Exempt' | 'Excluded';
  tax_included?: boolean;
  tax_consumption_value?: number;
  taxes?: SiigoProductTax[];
  prices?: SiigoProductPrice[];
  unit?: string;
  unit_label?: string;
  reference?: string;
  description?: string;
  available_quantity?: number;
  metadata?: Record<string, any>;
}

export interface SiigoVoucherItem {
  account?: string;
  customer?: {
    identification: string;
    branch_office?: number;
  };
  description?: string;
  value: number;
  due_date?: string;
}

export interface SiigoVoucher {
  id?: string;
  document?: {
    id: number;
  };
  number?: number;
  name?: string;
  date: string;
  type?: 'Advance' | 'CustomerPayment' | 'SupplierPayment';
  customer?: {
    id?: string;
    identification: string;
    name?: string;
  };
  cost_center?: number;
  currency?: {
    code: string;
  };
  items?: SiigoVoucherItem[];
  payment?: {
    id: number;
    value: number;
  };
  observations?: string;
  metadata?: Record<string, any>;
}

export interface SiigoDocumentType {
  id: number;
  code: string;
  name: string;
  description?: string;
  type: string; // ej. 'FV' para Factura de Venta, 'NC' para Nota Crédito, 'RC' para Recibo de Caja
  active: boolean;
  seller_by_item?: boolean;
}

export interface SiigoPaymentType {
  id: number;
  name: string;
  type: string;
  active: boolean;
  due_date?: boolean;
}

export interface SiigoTax {
  id: number;
  name: string;
  type: string;
  percentage: number;
  active: boolean;
}

export interface SiigoUser {
  id: number;
  username: string;
  first_name: string;
  last_name: string;
  email: string;
  active: boolean;
}

export interface SiigoApiError {
  Status?: number;
  Errors?: Array<{
    Code?: string;
    Message?: string;
    Detail?: string;
    Params?: string[];
  }>;
  message?: string;
  error?: string;
}

export interface SiigoStatusResponse {
  configured: boolean;
  sandbox: boolean;
  partnerId: string;
  usernameMasked: string | null;
  hasAccessKey: boolean;
  authenticated: boolean;
  tokenExpiresAt: string | null;
  apiUrl: string;
  mode: 'live' | 'sandbox';
  message: string;
}
