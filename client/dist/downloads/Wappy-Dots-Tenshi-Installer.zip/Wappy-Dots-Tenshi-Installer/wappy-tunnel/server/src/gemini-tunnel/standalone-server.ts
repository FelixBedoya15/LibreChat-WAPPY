/**
 * standalone-server.ts
 *
 * Servidor dedicado de arranque instantáneo para el Túnel de Google Gemini + Tenshi Live Voice
 * + Orquestador Antigravity + Integraciones (Google Workspace & Siigo) en el puerto 3001.
 *
 * No depende de PostgreSQL ni Docker, por lo que garantiza que Wappy Dots (Tenshi Voz y Chat)
 * tenga siempre disponible el motor Gemini Live (24 kHz con voces de LibreChat-WAPPY:
 * Sol/Aoede, Orbit/Puck, Kore, Ember, Spruce/Fenrir).
 */

import { Hono } from 'hono';
import { cors } from 'hono/cors';
import { createGeminiTunnelRoutes } from './gemini-tunnel-routes';
import { getTenshiMobileAppHtml } from './tenshi-mobile-app';
import { startOllamaBridge } from './ollama-bridge';
import { startPublicTunnel, stopPublicTunnel } from './cloudflare-tunnel';

const port = Number(process.env.GEMINI_TUNNEL_PORT || process.env.PORT || 3001);

const app = new Hono();
app.use('*', cors());

const geminiTunnel = createGeminiTunnelRoutes();
app.route('/api/gemini-tunnel', geminiTunnel);
app.route('/v1', geminiTunnel);
app.route('/api/wappy-gemini-ai/v1beta/openai', geminiTunnel);

app.get('/mobile', (c) => c.html(getTenshiMobileAppHtml()));
app.get('/app', (c) => c.html(getTenshiMobileAppHtml()));
app.get('/tenshi', (c) => c.html(getTenshiMobileAppHtml()));
app.get('/ping', (c) => c.text(`Tenshi OK · servidor alcanzable · ${new Date().toISOString()}`));
app.get('/health', (c) =>
  c.json({
    ok: true,
    service: 'wappy-gemini-tunnel',
    port,
    timestamp: new Date().toISOString(),
  }),
);

let server: ReturnType<typeof Bun.serve>;
try {
  server = Bun.serve({
    port,
    hostname: '0.0.0.0',
    idleTimeout: 240,
    fetch: app.fetch,
  });
} catch (err: any) {
  if (err?.code === 'EADDRINUSE') {
    // Another supervisor (LaunchAgent or WappyTunnelProcess) is already serving port 3001; stay alive quietly so launchd KeepAlive doesn't loop.
    setInterval(() => {}, 3600_000);
    await new Promise(() => {});
  }
  throw err;
}

const ollamaBridge = startOllamaBridge(11434);
void startPublicTunnel(port);

console.info(`[WappyGeminiTunnel] Servidor activo en http://127.0.0.1:${server.port} (Tenshi Live Voice 24kHz listo)`);

for (const sig of ['SIGINT', 'SIGTERM'] as const) {
  process.on(sig, () => {
    stopPublicTunnel();
    ollamaBridge?.stop();
    server.stop(true);
    process.exit(0);
  });
}
