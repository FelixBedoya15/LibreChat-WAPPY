/**
 * Tipos e interfaces para la integración unificada de Google Workspace.
 * Abarca Gmail, Google Calendar, Google Drive, Google Sheets y Google Docs.
 */

export interface GoogleOAuthConfig {
  client_id: string;
  client_secret: string;
  redirect_uri: string;
  scopes: string[];
}

export interface GoogleTokens {
  access_token: string;
  refresh_token?: string;
  expiry_date?: number; // milisegundos timestamp
  token_type?: string;
  scope?: string;
}

export interface GoogleUserProfile {
  id?: string;
  email: string;
  verified_email?: boolean;
  name?: string;
  given_name?: string;
  family_name?: string;
  picture?: string;
}

export interface GoogleConnectionStatus {
  connected: boolean;
  email: string | null;
  name: string | null;
  picture: string | null;
  scopes: string[];
  tokenExpiresAt: string | null;
  authUrl?: string;
  message: string;
}

// Gmail
export interface GmailMessageSummary {
  id: string;
  threadId: string;
  from: string;
  to: string;
  subject: string;
  date: string;
  snippet: string;
}

export interface GmailFullMessage extends GmailMessageSummary {
  bodyText: string;
  bodyHtml?: string;
  labels: string[];
}

// Calendar
export interface CalendarEventItem {
  id: string;
  summary: string;
  description?: string;
  start: string; // ISO datetime o date
  end: string;   // ISO datetime o date
  location?: string;
  meetLink?: string;
  htmlLink?: string;
  attendees?: string[];
  status?: string;
}

// Drive
export interface DriveFileItem {
  id: string;
  name: string;
  mimeType: string;
  size?: number;
  modifiedTime: string;
  webViewLink?: string;
  iconLink?: string;
  owners?: string[];
}

// Sheets
export interface SheetValuesResult {
  spreadsheetId: string;
  range: string;
  values: any[][];
}

// Docs
export interface GoogleDocContent {
  documentId: string;
  title: string;
  text: string;
}
