/**
 * Datos simulados y fixtures para el entorno Sandbox / Pre-configuración de Siigo API.
 * Permiten probar toda la arquitectura, endpoints y herramientas de Tenshi
 * antes de que el usuario ingrese sus credenciales reales de Siigo Nube.
 */

import type {
  SiigoCustomer,
  SiigoInvoice,
  SiigoProduct,
  SiigoVoucher,
  SiigoDocumentType,
  SiigoPaymentType,
  SiigoTax,
  SiigoUser,
} from './siigo-types';

export const MOCK_CUSTOMERS: SiigoCustomer[] = [
  {
    id: 'c1a2b3c4-0001-4000-8000-000000000001',
    type: 'Customer',
    person_type: 'Company',
    id_type: '31',
    identification: '901234567',
    check_digit: '3',
    name: ['Soluciones Industriales Andinas S.A.S.'],
    commercial_name: 'Soluciones Andinas',
    branch_office: 0,
    active: true,
    vat_responsible: true,
    fiscal_responsibilities: [{ code: 'O-13', name: 'Gran Contribuyente' }],
    address: {
      address: 'Calle 100 # 19-61, Of. 502',
      city: {
        country_code: 'Co',
        country_name: 'Colombia',
        state_code: '11',
        state_name: 'Bogotá D.C.',
        city_code: '11001',
        city_name: 'Bogotá',
      },
      postal_code: '110111',
    },
    phones: [{ indicative: '57', number: '6017458920' }],
    contacts: [
      {
        first_name: 'Carolina',
        last_name: 'Mendoza',
        email: 'cmendoza@solucionesandinas.com.co',
        phone: { indicative: '57', number: '3104567890' },
      },
    ],
    comments: 'Cliente corporativo de consultoría SST y planes de emergencia.',
    created_at: '2026-01-15T09:00:00Z',
  },
  {
    id: 'c1a2b3c4-0002-4000-8000-000000000002',
    type: 'Customer',
    person_type: 'Company',
    id_type: '31',
    identification: '900888999',
    check_digit: '1',
    name: ['Logística y Distribución del Caribe S.A.'],
    commercial_name: 'Logicaribe',
    branch_office: 0,
    active: true,
    vat_responsible: true,
    fiscal_responsibilities: [{ code: 'O-23', name: 'Agente de Retención en el Impuesto sobre las Ventas' }],
    address: {
      address: 'Vía 40 # 73-290',
      city: {
        country_code: 'Co',
        country_name: 'Colombia',
        state_code: '08',
        state_name: 'Atlántico',
        city_code: '08001',
        city_name: 'Barranquilla',
      },
      postal_code: '080001',
    },
    phones: [{ indicative: '57', number: '6053851234' }],
    contacts: [
      {
        first_name: 'Andrés',
        last_name: 'Gómez',
        email: 'agomez@logicaribe.co',
        phone: { indicative: '57', number: '3009876543' },
      },
    ],
    comments: 'Implementación PESV (Plan Estratégico de Seguridad Vial) Fase 2.',
    created_at: '2026-02-10T14:30:00Z',
  },
  {
    id: 'c1a2b3c4-0003-4000-8000-000000000003',
    type: 'Customer',
    person_type: 'Person',
    id_type: '13',
    identification: '1020304050',
    name: ['Javier', 'Hernández Robledo'],
    commercial_name: 'Ingeniería Hernández',
    branch_office: 0,
    active: true,
    vat_responsible: false,
    fiscal_responsibilities: [{ code: 'R-99-PN', name: 'No responsable de IVA' }],
    address: {
      address: 'Carrera 43A # 1Sur-29',
      city: {
        country_code: 'Co',
        country_name: 'Colombia',
        state_code: '05',
        state_name: 'Antioquia',
        city_code: '05001',
        city_name: 'Medellín',
      },
      postal_code: '050021',
    },
    phones: [{ indicative: '57', number: '3157891234' }],
    contacts: [
      {
        first_name: 'Javier',
        last_name: 'Hernández',
        email: 'jhernandez@ingenieriahernandez.com',
      },
    ],
    comments: 'Contratista independiente de obras civiles y mediciones ambientales.',
    created_at: '2026-03-01T11:20:00Z',
  },
];

export const MOCK_PRODUCTS: SiigoProduct[] = [
  {
    id: 'p1a2b3c4-0001-4000-8000-000000000001',
    code: 'SST-001',
    name: 'Consultoría SG-SST Mensual (Resolución 0312)',
    account_group: 10,
    type: 'Service',
    stock_control: false,
    active: true,
    tax_classification: 'Taxed',
    tax_included: false,
    taxes: [{ id: 1001, name: 'IVA 19%', percentage: 19, type: 'IVA' }],
    prices: [
      {
        currency_code: 'COP',
        price_list: [{ position: 1, value: 1850000, name: 'Precio Estándar' }],
      },
    ],
    unit: '94',
    unit_label: 'Unidad de servicio',
    reference: 'SST-STD-2026',
    description: 'Acompañamiento integral en Seguridad y Salud en el Trabajo con Tenshi y Wappy Bot.',
    available_quantity: 999,
  },
  {
    id: 'p1a2b3c4-0002-4000-8000-000000000002',
    code: 'SST-002',
    name: 'Diseño e Implementación de Matriz GTC-45',
    account_group: 10,
    type: 'Service',
    stock_control: false,
    active: true,
    tax_classification: 'Taxed',
    tax_included: false,
    taxes: [{ id: 1001, name: 'IVA 19%', percentage: 19, type: 'IVA' }],
    prices: [
      {
        currency_code: 'COP',
        price_list: [{ position: 1, value: 950000, name: 'Precio Estándar' }],
      },
    ],
    unit: '94',
    unit_label: 'Unidad de servicio',
    reference: 'GTC45-AUTO',
    description: 'Diagnóstico de peligros, valoración de riesgos y planes de intervención automatizados.',
    available_quantity: 999,
  },
  {
    id: 'p1a2b3c4-0003-4000-8000-000000000003',
    code: 'PESV-001',
    name: 'Auditoría y Validación PESV (Res. 40595 de 2022)',
    account_group: 10,
    type: 'Service',
    stock_control: false,
    active: true,
    tax_classification: 'Taxed',
    tax_included: false,
    taxes: [{ id: 1001, name: 'IVA 19%', percentage: 19, type: 'IVA' }],
    prices: [
      {
        currency_code: 'COP',
        price_list: [{ position: 1, value: 2400000, name: 'Precio Estándar' }],
      },
    ],
    unit: '94',
    unit_label: 'Unidad de servicio',
    reference: 'PESV-AUDIT',
    description: 'Evaluación y seguimiento de los 24 pasos del Plan Estratégico de Seguridad Vial.',
    available_quantity: 999,
  },
  {
    id: 'p1a2b3c4-0004-4000-8000-000000000004',
    code: 'LIC-WAPPY-01',
    name: 'Suscripción Wappy Bot Enterprise (Mensual)',
    account_group: 20,
    type: 'Service',
    stock_control: false,
    active: true,
    tax_classification: 'Taxed',
    tax_included: false,
    taxes: [{ id: 1001, name: 'IVA 19%', percentage: 19, type: 'IVA' }],
    prices: [
      {
        currency_code: 'COP',
        price_list: [{ position: 1, value: 490000, name: 'Suscripción Wappy' }],
      },
    ],
    unit: '94',
    unit_label: 'Suscripción',
    reference: 'WAPPY-ENT-M',
    description: 'Agentes de IA autónomos, Tenshi en Notch / Móvil y Automatización Empresarial.',
    available_quantity: 9999,
  },
];

export const MOCK_INVOICES: SiigoInvoice[] = [
  {
    id: 'f1a2b3c4-0001-4000-8000-000000000001',
    document: { id: 24 },
    prefix: 'FV',
    number: 1042,
    name: 'FV-1042',
    date: '2026-10-15',
    customer: {
      id: 'c1a2b3c4-0001-4000-8000-000000000001',
      identification: '901234567',
      branch_office: 0,
      name: ['Soluciones Industriales Andinas S.A.S.'],
      commercial_name: 'Soluciones Andinas',
    },
    cost_center: 1,
    currency: { code: 'COP', exchange_rate: 1 },
    seller: 1,
    stamp: { status: 'Accepted' },
    mail: { status: 'Sent' },
    observations: 'Servicio de auditoría y acompañamiento SG-SST mensual.',
    items: [
      {
        code: 'SST-001',
        description: 'Consultoría SG-SST Mensual (Resolución 0312)',
        quantity: 1,
        price: 1850000,
        discount: 0,
        taxes: [{ id: 1001, name: 'IVA 19%', percentage: 19, value: 351500 }],
        total: 2201500,
      },
    ],
    payments: [
      {
        id: 1,
        name: 'Crédito 30 días',
        value: 2201500,
        due_date: '2026-11-14',
      },
    ],
    total: 2201500,
    balance: 0,
    metadata: {
      created: '2026-10-15T10:15:30Z',
      dian_cufe: 'a7b8c9d0e1f234567890abcdef1234567890abcdef1234567890abcdef123456',
    },
    public_url: 'https://factura.siigo.com/view/fv-1042-demo',
  },
  {
    id: 'f1a2b3c4-0002-4000-8000-000000000002',
    document: { id: 24 },
    prefix: 'FV',
    number: 1043,
    name: 'FV-1043',
    date: '2026-10-20',
    customer: {
      id: 'c1a2b3c4-0002-4000-8000-000000000002',
      identification: '900888999',
      branch_office: 0,
      name: ['Logística y Distribución del Caribe S.A.'],
      commercial_name: 'Logicaribe',
    },
    cost_center: 1,
    currency: { code: 'COP', exchange_rate: 1 },
    seller: 1,
    stamp: { status: 'Accepted' },
    mail: { status: 'Sent' },
    observations: 'Implementación del PESV Fase 2 con integración Wappy.',
    items: [
      {
        code: 'PESV-001',
        description: 'Auditoría y Validación PESV (Res. 40595 de 2022)',
        quantity: 1,
        price: 2400000,
        discount: 0,
        taxes: [{ id: 1001, name: 'IVA 19%', percentage: 19, value: 456000 }],
        total: 2856000,
      },
      {
        code: 'LIC-WAPPY-01',
        description: 'Suscripción Wappy Bot Enterprise (Mensual)',
        quantity: 1,
        price: 490000,
        discount: 0,
        taxes: [{ id: 1001, name: 'IVA 19%', percentage: 19, value: 93100 }],
        total: 583100,
      },
    ],
    payments: [
      {
        id: 1,
        name: 'Crédito 15 días',
        value: 3439100,
        due_date: '2026-11-04',
      },
    ],
    total: 3439100,
    balance: 3439100,
    metadata: {
      created: '2026-10-20T16:02:11Z',
      dian_cufe: 'b8c9d0e1f234567890abcdef1234567890abcdef1234567890abcdef1234567a',
    },
    public_url: 'https://factura.siigo.com/view/fv-1043-demo',
  },
];

export const MOCK_VOUCHERS: SiigoVoucher[] = [
  {
    id: 'v1a2b3c4-0001-4000-8000-000000000001',
    document: { id: 15 },
    number: 501,
    name: 'RC-501',
    date: '2026-10-18',
    type: 'CustomerPayment',
    customer: {
      id: 'c1a2b3c4-0001-4000-8000-000000000001',
      identification: '901234567',
      name: 'Soluciones Industriales Andinas S.A.S.',
    },
    cost_center: 1,
    currency: { code: 'COP' },
    items: [
      {
        account: '130505',
        description: 'Pago factura electrónica FV-1042',
        value: 2201500,
      },
    ],
    payment: {
      id: 5,
      value: 2201500,
    },
    observations: 'Transferencia Bancolombia Ref. TR-894102',
  },
];

export const MOCK_DOCUMENT_TYPES: SiigoDocumentType[] = [
  { id: 24, code: 'FV-1', name: 'Factura Electrónica de Venta', type: 'FV', active: true },
  { id: 25, code: 'NC-1', name: 'Nota Crédito Electrónica', type: 'NC', active: true },
  { id: 15, code: 'RC-1', name: 'Recibo de Caja', type: 'RC', active: true },
];

export const MOCK_PAYMENT_TYPES: SiigoPaymentType[] = [
  { id: 1, name: 'Efectivo', type: 'Cash', active: true },
  { id: 2, name: 'Crédito', type: 'Credit', active: true, due_date: true },
  { id: 5, name: 'Transferencia Bancaria', type: 'BankTransfer', active: true },
];

export const MOCK_TAXES: SiigoTax[] = [
  { id: 1001, name: 'IVA 19%', type: 'IVA', percentage: 19, active: true },
  { id: 1002, name: 'IVA 5%', type: 'IVA', percentage: 5, active: true },
  { id: 1003, name: 'Retefuente 4%', type: 'Retefuente', percentage: 4, active: true },
];

export const MOCK_USERS: SiigoUser[] = [
  {
    id: 1,
    username: 'admin@empresa.com',
    first_name: 'Administrador',
    last_name: 'Wappy',
    email: 'admin@empresa.com',
    active: true,
  },
];
