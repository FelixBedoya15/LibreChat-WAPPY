/**
 * gemini-live-bridge.ts
 *
 * Puente para los modelos Gemini Live (gemini-3.1-flash-live-preview, gemini-3.8-live…).
 * Replica al 100% la voz nativa fluida de LibreChat-WAPPY (api/server/routes/voice/geminiLive.js):
 *   - Modalidad AUDIO nativa (24 kHz, 16-bit PCM mono) con las 5 voces de Tenshi:
 *     Sol (Aoede), Kore (Kore), Ember (Kore), Orbit (Puck), Spruce (Fenrir)
 *   - Directiva estricta de idioma español (SPANISH_AUDIO_LOCK)
 *   - Empaquetado directo PCM 24kHz → RIFF/WAV base64 (audio_wav_base64) + transcripción (content)
 *     para que Wappy Dots reproduzca la voz real de Gemini Live sin pasar por el robot del sistema.
 */

const LIVE_WS_URL =
  'wss://generativelanguage.googleapis.com/ws/google.ai.generativelanguage.v1beta.GenerativeService.BidiGenerateContent';

export class LiveBridgeError extends Error {
  status: number;
  constructor(message: string, status = 500) {
    super(message);
    this.status = status;
  }
}

/**
 * Mapeo oficial de voces de Tenshi (idéntico a LibreChat-WAPPY/api/server/routes/voice/geminiLive.js líneas 31-57)
 */
export function mapVoiceToGeminiLive(voiceId?: string): string {
  if (!voiceId) return 'Aoede';
  const clean = voiceId.toLowerCase().trim();
  switch (clean) {
    case 'sol':
    case 'aoede':
    case 'female':
      return 'Aoede';
    case 'spruce':
    case 'fenrir':
      return 'Fenrir';
    case 'ember':
    case 'kore':
      return 'Kore';
    case 'orbit':
    case 'puck':
    case 'male':
      return 'Puck';
    case 'charon':
      return 'Charon';
    default:
      return voiceId.charAt(0).toUpperCase() + voiceId.slice(1);
  }
}

/**
 * Candado de idioma español idéntico a LibreChat-WAPPY/api/server/routes/voice/geminiLive.js líneas 263-268
 */
const SPANISH_AUDIO_LOCK = `[DIRECTIVA CRÍTICA DE IDIOMA Y AUDICIÓN]:
- IDIOMA EXCLUSIVO Y OBLIGATORIO: ESPAÑOL (Colombia / Latinoamérica).
- El usuario habla ÚNICA Y EXCLUSIVAMENTE en ESPAÑOL.
- ESTÁ ESTRICTAMENTE PROHIBIDO transcribir, interpretar o responder en inglés, hindi, devanagari, urdu, árabe o cualquier otro idioma.
- PROHIBICIÓN ABSOLUTA DE FRASES O CIERRES EN INGLÉS: Nunca digas "all set", "that's all set", "done", "okay", "sure thing", "I've conveyed", "as an AI" ni ninguna coletilla en inglés. CADA PALABRA que emitas por audio debe ser 100% en español natural y fluido.`;

/**
 * Convierte buffers PCM 16-bit signed little-endian mono a 24000 Hz en un archivo WAV (RIFF) válido.
 */
export function pcm24kToWavBuffer(pcmChunks: Buffer[], sampleRate = 24000): Buffer {
  const pcmData = Buffer.concat(pcmChunks);
  const numChannels = 1;
  const bitsPerSample = 16;
  const byteRate = (sampleRate * numChannels * bitsPerSample) / 8;
  const blockAlign = (numChannels * bitsPerSample) / 8;
  const dataSize = pcmData.length;
  const header = Buffer.alloc(44);

  header.write('RIFF', 0);
  header.writeUInt32LE(36 + dataSize, 4);
  header.write('WAVE', 8);
  header.write('fmt ', 12);
  header.writeUInt32LE(16, 16); // Subchunk1Size (16 for PCM)
  header.writeUInt16LE(1, 20);  // AudioFormat (1 = PCM)
  header.writeUInt16LE(numChannels, 22);
  header.writeUInt32LE(sampleRate, 24);
  header.writeUInt32LE(byteRate, 28);
  header.writeUInt16LE(blockAlign, 32);
  header.writeUInt16LE(bitsPerSample, 34);
  header.write('data', 36);
  header.writeUInt32LE(dataSize, 40);

  return Buffer.concat([header, pcmData]);
}

type OpenAIMessage = {
  role: string;
  content?: unknown;
  tool_calls?: Array<{ id?: string; function?: { name?: string; arguments?: string } }>;
  tool_call_id?: string;
  name?: string;
};

function textOf(content: unknown): string {
  if (typeof content === 'string') return content;
  if (Array.isArray(content)) {
    return content
      .map((p: any) => (typeof p === 'string' ? p : p?.text ?? ''))
      .filter(Boolean)
      .join('\n');
  }
  return '';
}

/** OpenAI messages → system instruction + turnos Live. */
function toLiveTurns(messages: OpenAIMessage[]) {
  const system: string[] = [SPANISH_AUDIO_LOCK];
  const turns: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }> = [];
  let endsWithToolResult = false;

  const push = (role: 'user' | 'model', text: string) => {
    if (!text.trim()) return;
    const last = turns[turns.length - 1];
    if (last && last.role === role) last.parts[0].text += `\n${text}`;
    else turns.push({ role, parts: [{ text }] });
  };

  for (const m of messages) {
    if (m.role === 'system') {
      system.push(textOf(m.content));
    } else if (m.role === 'user') {
      endsWithToolResult = false;
      push('user', textOf(m.content));
    } else if (m.role === 'assistant') {
      endsWithToolResult = false;
      const calls = (m.tool_calls ?? [])
        .map((c) => `Ejecutando acción ${c.function?.name}.`)
        .join(' ');
      push('model', [textOf(m.content), calls].filter(Boolean).join(' '));
    } else if (m.role === 'tool') {
      endsWithToolResult = true;
      const rawToolText = textOf(m.content);
      const cleanForSpeech = rawToolText
        .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+|file:\/\/[^\s)]+)\)/g, '$1')
        .replace(/https?:\/\/\S+/g, '')
        .replace(/file:\/\/\S+/g, '')
        .slice(0, 2800);
      push(
        'user',
        `[Resultado de la herramienta (${m.name ?? 'herramienta'}):\n${cleanForSpeech}]\n\nResponde verbalmente al usuario en español de forma clara, completa, cálida y natural explicándole la respuesta o el resultado obtenido (si se generó un documento o informe, infórmale que ya se lo dejaste en el chat de Tenshi). No leas enlaces web ni rutas técnicas y no vuelvas a invocar herramientas.`,
      );
    }
  }
  if (turns.length === 0 || turns[turns.length - 1].role !== 'user') {
    push('user', 'Continúa en español.');
  }
  return { systemInstruction: system.join('\n\n'), turns, endsWithToolResult };
}

function toFunctionDeclarations(tools: any[] | undefined) {
  const decls = (tools ?? [])
    .map((t) => t?.function ?? t)
    .filter((f) => f?.name)
    .map((f) => ({ name: f.name, description: f.description ?? '', parameters: f.parameters }));
  return decls.length ? [{ functionDeclarations: decls }] : undefined;
}

/**
 * Detecta si la consulta del usuario requiere datos actualizados de búsqueda web (normas, leyes,
 * resoluciones, noticias, precios, clima, fechas 2024/2025/2026 o cuando pide buscar en la web)
 * y la resuelve mediante el endpoint `/api/gemini-tunnel/web-search` usando la escalera de modelos
 * y el pool de conexión oficial de Wappy (`gemini-3.5-flash-lite` -> `gemini-3.8-flash` -> `gemini-3.6-flash`).
 */
function shouldRunGoogleSearchGrounding(turns: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }>): string | null {
  if (turns.length === 0) return null;
  const lastTurn = turns[turns.length - 1];
  if (lastTurn.role !== 'user') return null;
  const text = (lastTurn?.parts?.[0]?.text || '').trim();
  if (!text || text.startsWith('[Resultado de la herramienta')) return null;

  const groundingPattern =
    /\b(norma|normativa|resolucion|resolución|decreto|ley|circular|ministerio|examenes|exámenes|medico|médico|medicos|médicos|laboral|laborales|ocupacional|ocupacionales|sst|seguridad y salud|actual|reciente|ultima|última|ultimo|último| Vigente|vigente|derog|2024|2025|2026|noticias|noticia|precio|precios|dolar|dólar|clima|tiempo|quien es|quién es|presidente|alcalde|busca en la web|buscar en la web|buscalo|búscalo|buscaste|internet|google|averigua|verifica|verificar|consulta en la web)\b/i;

  if (groundingPattern.test(text)) {
    return text;
  }
  return null;
}

async function fetchGoogleSearchGrounding(query: string, _apiKey: string): Promise<string | null> {
  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 14000);
    const resp = await fetch(
      `http://127.0.0.1:3001/api/gemini-tunnel/web-search?q=${encodeURIComponent(query)}`,
      {
        method: 'GET',
        signal: controller.signal,
      },
    );
    clearTimeout(timeout);
    if (!resp.ok) return null;
    const data: any = await resp.json();
    const summary = (data?.summary || '').trim();
    if (summary) {
      console.log(`[GeminiLive] Grounding Web 2025/2026 inyectado: "${summary.slice(0, 140)}..."`);
      return summary;
    }
  } catch (err: any) {
    console.warn(`[GeminiLive] Grounding Web timeout/error:`, err?.message || err);
  }
  return null;
}

/**
 * Determina si el último mensaje del usuario requiere evaluar las herramientas de sistema/acciones.
 * En saludos o charla conversacional pura ("Hola, ¿cómo estás el día de hoy?"), omitir los 8 esquemas
 * JSON pesados de herramientas reduce la latencia de síntesis de Gemini Live en ~1.5–2.2 segundos.
 */
function shouldIncludeToolsForTurns(turns: Array<{ role: 'user' | 'model'; parts: Array<{ text: string }> }>): boolean {
  if (turns.length === 0) return false;
  const lastTurn = turns[turns.length - 1];
  const text = (lastTurn?.parts?.[0]?.text || '').toLowerCase();
  if (!text) return false;
  const actionPattern =
    /\b(abre|abrir|busca|buscar|google|youtube|web|pagina|página|pestaña|url|link|enlace|app|aplicacion|aplicación|safari|chrome|spotify|finder|code|excel|word|pdf|html|informe|reporte|documento|archivo|genera|generar|crea|crear|haz|hacer|antigravity|proyecto|proyectos|chat|chats|musica|música|cancion|canción|reproduce|reproducir|pausa|pausar|siguiente|anterior|volumen|sube|baja|pildora|píldora|pill|notch|stripe|github|vercel|resend|n8n|notion|cal|siigo|factura|cotizacion|cotización|correo|mail|email|enviar|envia|envía|redacta|escribe|escribir|calendario|agenda|drive|hoja|calculo|cálculo|equipo|team|agentes|subagentes|openclaw|coordina|coordinar|delega|delegar|investiga)\b/i;
  return actionPattern.test(text);
}

async function decode(data: unknown): Promise<any> {
  let text: string;
  if (typeof data === 'string') text = data;
  else if (data instanceof ArrayBuffer) text = new TextDecoder().decode(data);
  else if (ArrayBuffer.isView(data)) text = new TextDecoder().decode(data as Uint8Array);
  else if (data && typeof (data as Blob).text === 'function') text = await (data as Blob).text();
  else text = String(data);
  try {
    return JSON.parse(text);
  } catch {
    return {};
  }
}

function classify(reason: string): number {
  const r = reason.toLowerCase();
  if (r.includes('quota') || r.includes('resource_exhausted') || r.includes('rate')) return 429;
  if (r.includes('api key') || r.includes('permission') || r.includes('unauthenticated')) return 403;
  if (r.includes('not found') || r.includes('not supported') || r.includes('unsupported')) return 404;
  return 503;
}

/**
 * Un turno completo con un modelo Live y una clave en modalidad AUDIO nativa (igual que LibreChat-WAPPY).
 * Devuelve el objeto chat.completion OpenAI incluyendo `audio_wav_base64` con la voz fluida de Gemini Live.
 */
export async function liveChatTurn(
  body: any,
  model: string,
  apiKey: string,
  voiceId = 'Sol',
  timeoutMs = 180000,
): Promise<any> {
  const { systemInstruction, turns, endsWithToolResult } = toLiveTurns(body.messages ?? []);
  const groundingQuery = !endsWithToolResult ? shouldRunGoogleSearchGrounding(turns) : null;
  if (groundingQuery) {
    const webFacts = await fetchGoogleSearchGrounding(groundingQuery, apiKey);
    if (webFacts && turns.length > 0) {
      const last = turns[turns.length - 1];
      last.parts[0].text += `\n\n[INFORMACIÓN OFICIAL VERIFICADA EN GOOGLE SEARCH EN TIEMPO REAL (2025-2026):\n${webFacts}\nINSTRUCCIÓN OBLIGATORIA: Basa tu respuesta en esta información actualizada de Google Search y corrige cualquier dato antiguo de tu memoria.]`;
    }
  }
  const tools =
    endsWithToolResult || !shouldIncludeToolsForTurns(turns)
      ? undefined
      : toFunctionDeclarations(body.tools);
  const resolvedVoice = mapVoiceToGeminiLive(body.voice || voiceId);

  const setup: any = {
    model: model.startsWith('models/') ? model : `models/${model}`,
    generationConfig: {
      responseModalities: ['AUDIO'],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: {
            voiceName: resolvedVoice,
          },
        },
      },
    },
    outputAudioTranscription: {},
  };
  if (systemInstruction) setup.systemInstruction = { parts: [{ text: systemInstruction }] };
  if (tools) setup.tools = tools;

  return await new Promise((resolve, reject) => {
    const ws = new WebSocket(`${LIVE_WS_URL}?key=${encodeURIComponent(apiKey)}`);
    let text = '';
    let transcript = '';
    const pcmChunks: Buffer[] = [];
    let setupDone = false;
    let finished = false;

    const finish = (fn: () => void) => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      try {
        ws.close();
      } catch {}
      fn();
    };
    const timer = setTimeout(
      () => finish(() => reject(new LiveBridgeError(`Tiempo agotado esperando a ${model}`, 504))),
      timeoutMs,
    );
    const reply = (message: any, finishReason: string) => ({
      id: `live-${Date.now()}`,
      object: 'chat.completion',
      created: Math.floor(Date.now() / 1000),
      model,
      choices: [{ index: 0, message, finish_reason: finishReason }],
    });

    ws.onopen = () => ws.send(JSON.stringify({ setup }));

    ws.onmessage = async (event) => {
      const msg = await decode(event.data);
      if (msg.setupComplete !== undefined && !setupDone) {
        setupDone = true;
        ws.send(JSON.stringify({ clientContent: { turns, turnComplete: true } }));
        return;
      }
      if (msg.toolCall?.functionCalls?.length) {
        const toolCalls = msg.toolCall.functionCalls.map((fc: any, i: number) => ({
          id: fc.id || `call_${Date.now()}_${i}`,
          type: 'function',
          function: { name: fc.name, arguments: JSON.stringify(fc.args ?? {}) },
        }));
        console.log(
          `[GeminiLive] ToolCall invocada por voz:`,
          toolCalls.map((tc: any) => `${tc.function.name}(${tc.function.arguments})`).join(', '),
        );
        finish(() =>
          resolve(reply({ role: 'assistant', content: text || null, tool_calls: toolCalls }, 'tool_calls')),
        );
        return;
      }
      const sc = msg.serverContent;
      if (sc) {
        for (const part of sc.modelTurn?.parts ?? []) {
          if (part.thought) continue;
          if (typeof part.text === 'string') text += part.text;
          if (part.inlineData?.data && part.inlineData?.mimeType?.startsWith('audio/')) {
            pcmChunks.push(Buffer.from(part.inlineData.data, 'base64'));
          }
        }
        if (sc.outputTranscription?.text) transcript += sc.outputTranscription.text;
        if (sc.turnComplete) {
          const content = (transcript || text).trim();
          if (!content && pcmChunks.length === 0) {
            finish(() => reject(new LiveBridgeError('Gemini Live devolvió turno vacío sin audio ni texto', 502)));
            return;
          }
          const audioWavBase64 =
            pcmChunks.length > 0 ? pcm24kToWavBuffer(pcmChunks, 24000).toString('base64') : undefined;
          console.log(
            `[GeminiLive] Respuesta hablada (${resolvedVoice}, audio=${pcmChunks.length} chunks): "${content.slice(0, 140)}"`,
          );
          finish(() =>
            resolve(
              reply(
                {
                  role: 'assistant',
                  content,
                  ...(audioWavBase64 ? { audio_wav_base64: audioWavBase64, voice_used: resolvedVoice } : {}),
                },
                'stop',
              ),
            ),
          );
        }
      }
      if (msg.error) {
        const reason = msg.error.message ?? JSON.stringify(msg.error);
        finish(() => reject(new LiveBridgeError(reason, classify(reason))));
      }
    };

    ws.onerror = () => {};
    ws.onclose = (event) => {
      if (finished) return;
      const reason = event.reason || `WebSocket cerrado (código ${event.code})`;
      finish(() => reject(new LiveBridgeError(reason, classify(reason))));
    };
  });
}

/**
 * Síntesis directa de voz fluida con Gemini Live para frases sueltas (p. ej. botón "Probar voz" o confirmaciones).
 */
export async function synthesizeWithGeminiLive(
  textToSpeak: string,
  model: string,
  apiKey: string,
  voiceId = 'Sol',
  timeoutMs = 120000,
): Promise<Buffer> {
  const resolvedVoice = mapVoiceToGeminiLive(voiceId);
  const setup = {
    model: model.startsWith('models/') ? model : `models/${model}`,
    generationConfig: {
      responseModalities: ['AUDIO'],
      speechConfig: {
        voiceConfig: {
          prebuiltVoiceConfig: {
            voiceName: resolvedVoice,
          },
        },
      },
    },
    systemInstruction: {
      parts: [
        {
          text: `${SPANISH_AUDIO_LOCK}\nEres el sintetizador de voz natural de Tenshi (WAPPY IA). Lee exactamente el texto que te envíe el usuario con entonación humana, cálida, fluida y natural, sin agregar ni quitar palabras.`,
        },
      ],
    },
  };

  return await new Promise<Buffer>((resolve, reject) => {
    const ws = new WebSocket(`${LIVE_WS_URL}?key=${encodeURIComponent(apiKey)}`);
    const pcmChunks: Buffer[] = [];
    let setupDone = false;
    let finished = false;

    const finish = (fn: () => void) => {
      if (finished) return;
      finished = true;
      clearTimeout(timer);
      try {
        ws.close();
      } catch {}
      fn();
    };
    const timer = setTimeout(
      () => finish(() => reject(new LiveBridgeError(`Tiempo agotado en TTS Live (${model})`, 504))),
      timeoutMs,
    );

    ws.onopen = () => ws.send(JSON.stringify({ setup }));

    ws.onmessage = async (event) => {
      const msg = await decode(event.data);
      if (msg.setupComplete !== undefined && !setupDone) {
        setupDone = true;
        ws.send(
          JSON.stringify({
            clientContent: {
              turns: [{ role: 'user', parts: [{ text: `Di exactamente esto: "${textToSpeak}"` }] }],
              turnComplete: true,
            },
          }),
        );
        return;
      }
      const sc = msg.serverContent;
      if (sc) {
        for (const part of sc.modelTurn?.parts ?? []) {
          if (part.inlineData?.data) {
            pcmChunks.push(Buffer.from(part.inlineData.data, 'base64'));
          }
        }
        if (sc.turnComplete || sc.generationComplete) {
          if (pcmChunks.length === 0) {
            finish(() => reject(new LiveBridgeError('Gemini Live no devolvió audio', 502)));
          } else {
            finish(() => resolve(pcm24kToWavBuffer(pcmChunks, 24000)));
          }
        }
      }
      if (msg.error) {
        const reason = msg.error.message ?? JSON.stringify(msg.error);
        finish(() => reject(new LiveBridgeError(reason, classify(reason))));
      }
    };

    ws.onerror = () => {};
    ws.onclose = (event) => {
      if (finished) return;
      const reason = event.reason || `WebSocket cerrado (${event.code})`;
      finish(() => reject(new LiveBridgeError(reason, classify(reason))));
    };
  });
}
