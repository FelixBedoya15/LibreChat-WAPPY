/**
 * google-tools.ts
 *
 * Herramientas de Google Workspace para Tenshi, Antigravity y OpenBot.
 * Abarca Gmail, Google Calendar, Google Drive, Google Sheets y Google Docs.
 */

import { getSharedGoogleWorkspaceClient } from './google-workspace-client';

export const GOOGLE_WORKSPACE_OPENAI_TOOLS: any[] = [
  {
    type: 'function',
    function: {
      name: 'google_workspace_estado',
      description: 'Consulta si Google Workspace (Gmail, Drive, Calendar, Sheets, Docs) está conectado y el correo de la cuenta vinculada.',
      parameters: {
        type: 'object',
        properties: {},
        required: [],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'google_workspace_autorizar_link',
      description: 'Genera el enlace de autorización OAuth 2.0 para que el usuario conecte su cuenta de Google Workspace con Wappy y Tenshi.',
      parameters: {
        type: 'object',
        properties: {},
        required: [],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'gmail_buscar_correos',
      description: 'Busca correos en Gmail usando sintaxis de búsqueda estándar (ej: "is:unread", "from:cliente@empresa.com", "factura").',
      parameters: {
        type: 'object',
        properties: {
          query: {
            type: 'string',
            description: 'Términos o filtros de búsqueda en Gmail.',
          },
          maxResults: {
            type: 'number',
            description: 'Cantidad máxima de correos a retornar (por defecto 10, máx 50).',
          },
        },
        required: ['query'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'gmail_leer_correo',
      description: 'Obtiene el contenido completo, remitente, destinatario, asunto y texto de un correo específico de Gmail por su ID.',
      parameters: {
        type: 'object',
        properties: {
          messageId: {
            type: 'string',
            description: 'ID único del mensaje de Gmail.',
          },
        },
        required: ['messageId'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'gmail_enviar_correo',
      description: 'Envía un correo electrónico desde la cuenta conectada de Gmail.',
      parameters: {
        type: 'object',
        properties: {
          to: {
            type: 'string',
            description: 'Dirección de correo electrónico del destinatario.',
          },
          subject: {
            type: 'string',
            description: 'Asunto del correo electrónico.',
          },
          body: {
            type: 'string',
            description: 'Contenido del correo en texto plano o HTML.',
          },
          isHtml: {
            type: 'boolean',
            description: 'Indica si el cuerpo del correo incluye formato HTML (opcional).',
          },
        },
        required: ['to', 'subject', 'body'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'google_calendar_listar_eventos',
      description: 'Consulta los eventos de la agenda en Google Calendar para los próximos días o en un rango específico.',
      parameters: {
        type: 'object',
        properties: {
          timeMin: {
            type: 'string',
            description: 'Fecha/hora mínima en formato ISO (ej: 2026-10-25T00:00:00Z). Opcional, por defecto ahora.',
          },
          timeMax: {
            type: 'string',
            description: 'Fecha/hora máxima en formato ISO. Opcional.',
          },
          maxResults: {
            type: 'number',
            description: 'Número máximo de eventos a listar (por defecto 15).',
          },
        },
        required: [],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'google_calendar_crear_evento',
      description: 'Crea una nueva reunión o evento en Google Calendar.',
      parameters: {
        type: 'object',
        properties: {
          summary: {
            type: 'string',
            description: 'Título o resumen del evento/reunión.',
          },
          startDateTime: {
            type: 'string',
            description: 'Fecha y hora de inicio en formato ISO (ej: "2026-10-26T10:00:00-05:00").',
          },
          endDateTime: {
            type: 'string',
            description: 'Fecha y hora de fin en formato ISO (ej: "2026-10-26T11:00:00-05:00").',
          },
          description: {
            type: 'string',
            description: 'Descripción detallada o notas de la reunión.',
          },
          attendees: {
            type: 'array',
            items: { type: 'string' },
            description: 'Lista de correos electrónicos de los invitados.',
          },
          location: {
            type: 'string',
            description: 'Lugar o ubicación del evento.',
          },
        },
        required: ['summary', 'startDateTime', 'endDateTime'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'google_drive_buscar_archivos',
      description: 'Busca archivos y carpetas en Google Drive por nombre o tipo MIME.',
      parameters: {
        type: 'object',
        properties: {
          query: {
            type: 'string',
            description: 'Nombre o parte del nombre del archivo a buscar, o consulta Drive API.',
          },
          pageSize: {
            type: 'number',
            description: 'Cantidad de archivos a listar (por defecto 10).',
          },
        },
        required: ['query'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'google_drive_subir_archivo',
      description: 'Crea o sube un archivo de texto o JSON directamente a Google Drive.',
      parameters: {
        type: 'object',
        properties: {
          name: {
            type: 'string',
            description: 'Nombre del archivo con su extensión (ej: "informe.txt", "datos.json").',
          },
          content: {
            type: 'string',
            description: 'Contenido del archivo en formato de texto.',
          },
          mimeType: {
            type: 'string',
            description: 'MIME type del archivo (ej: "text/plain", "application/json"). Opcional.',
          },
        },
        required: ['name', 'content'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'google_sheets_leer_tabla',
      description: 'Lee los valores de una tabla o rango en Google Sheets.',
      parameters: {
        type: 'object',
        properties: {
          spreadsheetId: {
            type: 'string',
            description: 'El ID de la hoja de cálculo de Google (extraído de su URL).',
          },
          range: {
            type: 'string',
            description: 'El rango a leer en formato A1 (ej: "Hoja 1!A1:D20" o "A1:Z100").',
          },
        },
        required: ['spreadsheetId', 'range'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'google_sheets_agregar_filas',
      description: 'Agrega una o más filas de datos al final de una tabla en Google Sheets.',
      parameters: {
        type: 'object',
        properties: {
          spreadsheetId: {
            type: 'string',
            description: 'El ID de la hoja de cálculo de Google.',
          },
          range: {
            type: 'string',
            description: 'El rango o nombre de la pestaña donde se agregarán las filas (ej: "Hoja 1!A1").',
          },
          rows: {
            type: 'array',
            items: {
              type: 'array',
              items: { type: 'string' },
            },
            description: 'Matriz bidimensional con los valores de las filas a insertar.',
          },
        },
        required: ['spreadsheetId', 'range', 'rows'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'google_sheets_crear_hoja',
      description: 'Crea una nueva hoja de cálculo en blanco en Google Sheets.',
      parameters: {
        type: 'object',
        properties: {
          title: {
            type: 'string',
            description: 'Título de la nueva hoja de cálculo.',
          },
          headers: {
            type: 'array',
            items: { type: 'string' },
            description: 'Fila de encabezados iniciales opcional (ej: ["Fecha", "Cliente", "Total"]).',
          },
        },
        required: ['title'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'google_docs_leer_documento',
      description: 'Extrae y lee todo el texto plano de un documento de Google Docs por su ID.',
      parameters: {
        type: 'object',
        properties: {
          documentId: {
            type: 'string',
            description: 'El ID del documento de Google Docs (extraído de su URL).',
          },
        },
        required: ['documentId'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'google_docs_crear_documento',
      description: 'Crea un nuevo documento de Google Docs con título y texto inicial.',
      parameters: {
        type: 'object',
        properties: {
          title: {
            type: 'string',
            description: 'Título del documento.',
          },
          text: {
            type: 'string',
            description: 'Contenido de texto inicial del documento.',
          },
        },
        required: ['title'],
      },
    },
  },
];

export async function executeGoogleToolCall(toolName: string, args: Record<string, any>): Promise<any> {
  const client = getSharedGoogleWorkspaceClient();

  switch (toolName) {
    case 'google_workspace_estado': {
      return client.getStatus();
    }

    case 'google_workspace_autorizar_link': {
      return {
        url: client.getAuthUrl(),
        message: 'Abre este enlace en tu navegador para conectar Google Workspace con Wappy.',
      };
    }

    case 'gmail_buscar_correos': {
      return await client.searchGmailMessages(args.query, args.maxResults);
    }

    case 'gmail_leer_correo': {
      return await client.getGmailMessage(args.messageId);
    }

    case 'gmail_enviar_correo': {
      return await client.sendGmailMessage(args.to, args.subject, args.body, args.isHtml);
    }

    case 'google_calendar_listar_eventos': {
      return await client.listCalendarEvents(args.timeMin, args.timeMax, args.maxResults);
    }

    case 'google_calendar_crear_evento': {
      return await client.createCalendarEvent({
        summary: args.summary,
        startDateTime: args.startDateTime,
        endDateTime: args.endDateTime,
        description: args.description,
        attendees: args.attendees,
        location: args.location,
      });
    }

    case 'google_drive_buscar_archivos': {
      return await client.searchDriveFiles(args.query, args.pageSize);
    }

    case 'google_drive_subir_archivo': {
      return await client.uploadDriveFile(args.name, args.content, args.mimeType);
    }

    case 'google_sheets_leer_tabla': {
      return await client.readSheetValues(args.spreadsheetId, args.range);
    }

    case 'google_sheets_agregar_filas': {
      return await client.appendSheetValues(args.spreadsheetId, args.range, args.rows);
    }

    case 'google_sheets_crear_hoja': {
      return await client.createSpreadsheet(args.title, args.headers);
    }

    case 'google_docs_leer_documento': {
      return await client.readDocContent(args.documentId);
    }

    case 'google_docs_crear_documento': {
      return await client.createDoc(args.title, args.text);
    }

    default:
      throw new Error(`Herramienta de Google Workspace desconocida: "${toolName}"`);
  }
}
