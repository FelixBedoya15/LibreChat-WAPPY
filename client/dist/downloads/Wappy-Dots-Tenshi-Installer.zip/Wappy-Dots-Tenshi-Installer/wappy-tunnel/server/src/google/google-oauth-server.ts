/**
 * google-oauth-server.ts
 *
 * Servidor HTTP ligero en el puerto 3080 para recibir el callback OAuth 2.0 de Google.
 * Port 3080 coincide con la URI autorizada en Google Cloud Console:
 *   http://localhost:3080/oauth/google/callback
 */

import { serve, type Server } from 'bun';
import { getSharedGoogleWorkspaceClient } from './google-workspace-client';

let serverInstance: Server | null = null;

export function startGoogleOAuthServer(port = 3080): { stop: () => void; port: number } | null {
  if (serverInstance) {
    return {
      port: serverInstance.port,
      stop: () => {
        serverInstance?.stop(true);
        serverInstance = null;
      },
    };
  }

  try {
    const client = getSharedGoogleWorkspaceClient();

    serverInstance = serve({
      port,
      async fetch(req) {
        const url = new URL(req.url);

        // 1. Endpoint Callback OAuth de Google
        if (url.pathname === '/oauth/google/callback' || url.pathname === '/api/google-drive/callback') {
          const code = url.searchParams.get('code');
          const error = url.searchParams.get('error');

          if (error) {
            return new Response(
              renderHtmlPage({
                success: false,
                title: 'Error de Autorización',
                message: `Google devolvió un error: ${error}`,
              }),
              { headers: { 'Content-Type': 'text/html; charset=utf-8' }, status: 400 },
            );
          }

          if (!code) {
            return new Response(
              renderHtmlPage({
                success: false,
                title: 'Código no encontrado',
                message: 'No se recibió el código de autorización desde Google.',
              }),
              { headers: { 'Content-Type': 'text/html; charset=utf-8' }, status: 400 },
            );
          }

          try {
            const { profile } = await client.handleAuthCallback(code);
            return new Response(
              renderHtmlPage({
                success: true,
                title: '¡Google Workspace Conectado!',
                email: profile?.email || 'Cuenta autorizada',
                message: 'Tu cuenta ha sido vinculada exitosamente con Wappy Dots y Tenshi.',
              }),
              { headers: { 'Content-Type': 'text/html; charset=utf-8' }, status: 200 },
            );
          } catch (err: any) {
            return new Response(
              renderHtmlPage({
                success: false,
                title: 'Error al procesar tokens',
                message: err.message || 'No se pudieron intercambiar los tokens con Google.',
              }),
              { headers: { 'Content-Type': 'text/html; charset=utf-8' }, status: 500 },
            );
          }
        }

        // 2. Consulta de Estado
        if (url.pathname === '/oauth/google/status' || url.pathname === '/google/status') {
          const status = client.getStatus();
          return Response.json(status);
        }

        // 3. Obtener URL de autenticación
        if (url.pathname === '/oauth/google/auth-url' || url.pathname === '/google/auth-url') {
          return Response.json({ url: client.getAuthUrl() });
        }

        return new Response('Wappy Google OAuth Server Activo', { status: 200 });
      },
    });

    console.info(`[GoogleOAuth] Servidor de autenticación escuchando en http://localhost:${port}/oauth/google/callback`);

    return {
      port,
      stop: () => {
        serverInstance?.stop(true);
        serverInstance = null;
      },
    };
  } catch (err: any) {
    console.warn(`[GoogleOAuth] No se pudo iniciar en puerto ${port} (puede que ya esté ocupado): ${err.message}`);
    return null;
  }
}

function renderHtmlPage(opts: { success: boolean; title: string; email?: string; message: string }): string {
  const icon = opts.success ? '✅' : '❌';
  const color = opts.success ? '#22c55e' : '#ef4444';
  const emailHtml = opts.email ? `<p style="font-size:16px;color:#f8fafc;font-weight:600;margin:12px 0;">${opts.email}</p>` : '';

  return `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>${opts.title}</title>
  <style>
    * { box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      background: radial-gradient(circle at top, #1e293b, #0f172a);
      color: #f8fafc;
      display: flex;
      align-items: center;
      justify-content: center;
      min-height: 100vh;
      margin: 0;
      padding: 20px;
    }
    .card {
      background: rgba(30, 41, 59, 0.85);
      backdrop-filter: blur(12px);
      border: 1px solid rgba(255, 255, 255, 0.1);
      border-radius: 20px;
      padding: 40px;
      max-width: 480px;
      width: 100%;
      text-align: center;
      box-shadow: 0 25px 50px -12px rgba(0, 0, 0, 0.5);
    }
    .icon { font-size: 54px; margin-bottom: 16px; }
    h1 { font-size: 24px; font-weight: 700; margin: 0 0 10px; color: ${color}; }
    p { color: #94a3b8; font-size: 14px; line-height: 1.6; margin: 0 0 20px; }
    .badge-grid {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 8px;
      margin: 20px 0;
    }
    .badge {
      background: rgba(255, 255, 255, 0.08);
      border: 1px solid rgba(255, 255, 255, 0.15);
      border-radius: 9999px;
      padding: 6px 14px;
      font-size: 12px;
      font-weight: 600;
      color: #e2e8f0;
    }
    .hint {
      font-size: 12px;
      color: #64748b;
      margin-top: 24px;
    }
  </style>
</head>
<body>
  <div class="card">
    <div class="icon">${icon}</div>
    <h1>${opts.title}</h1>
    ${emailHtml}
    <p>${opts.message}</p>
    ${
      opts.success
        ? `<div class="badge-grid">
        <span class="badge">📨 Gmail</span>
        <span class="badge">📁 Google Drive</span>
        <span class="badge">📅 Google Calendar</span>
        <span class="badge">📊 Google Sheets</span>
        <span class="badge">📝 Google Docs</span>
      </div>
      <p class="hint">Ya puedes cerrar esta ventana y regresar a Wappy Dots en tu Mac.</p>`
        : `<p class="hint">Por favor intenta reconectar nuevamente desde la ventana de Ajustes en Wappy Dots.</p>`
    }
  </div>
</body>
</html>`;
}
