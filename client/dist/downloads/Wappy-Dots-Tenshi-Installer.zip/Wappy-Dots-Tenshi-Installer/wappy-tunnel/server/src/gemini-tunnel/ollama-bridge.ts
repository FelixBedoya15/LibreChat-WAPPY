/**
 * ollama-bridge.ts
 *
 * Micro-listener opcional en el puerto 11434 (puerto estándar de Ollama).
 * Permite que Coucou se conecte con un solo clic en Ajustes → Chat → Local (Ollama)
 * sin requerir modificar ninguna URL ni recompilar la app.
 */

import { serve } from 'bun';
import { createGeminiTunnelRoutes } from './gemini-tunnel-routes';

export function startOllamaBridge(port = 11434): { stop: () => void } | null {
  try {
    const app = createGeminiTunnelRoutes();

    const server = serve({
      port,
      fetch(request) {
        // Normalizar peticiones /v1 y directas
        return app.fetch(request);
      },
    });

    console.info(`[WappyGeminiTunnel] Bridge local Ollama-compatible escuchando en http://127.0.0.1:${port}`);

    return {
      stop: () => {
        server.stop(true);
      },
    };
  } catch (err: any) {
    console.warn(`[WappyGeminiTunnel] No se pudo iniciar el bridge en puerto ${port} (quizás ya está en uso): ${err.message}`);
    return null;
  }
}
