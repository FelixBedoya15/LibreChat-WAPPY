/**
 * gemini-pool-manager.ts
 *
 * Despachador Inteligente de Tráfico y Balanceo de Carga para Google Gemini.
 * Portado y adaptado de LibreChat-WAPPY (GeminiPoolManager.js).
 * Gestiona pools dinámicos de claves API con rotación Round-Robin inter-turnos,
 * Circuit Breaker (cooldowns de RPM/TPM de 25s) y aislamiento de cuota diaria por modelo (RPD).
 */

export interface KeyStatusReport {
  status?: number;
  message?: string;
  retryDelayMs?: number;
  isDailyLimit?: boolean;
}

export interface PoolStats {
  totalKeys: number;
  readyKeys: number;
  coolingKeys: number;
  dailyExhaustedKeys: number;
  invalidKeys: number;
  details: {
    key: string;
    status: 'ready' | 'cooling' | 'exhausted' | 'invalid';
    cooldownRemainingMs?: number;
  }[];
}

export class GeminiPoolManager {
  /** userId/sessionId -> nextIndex para Round-Robin */
  private userRoundRobinIndex = new Map<string, number>();

  /** apiKey -> timestampExpiresAt (RPM/TPM 429 cooldowns) */
  private keyCooldowns = new Map<string, number>();

  /** `${apiKey}_${model}` -> timestampExpiresAt (medianoche Pacífico) */
  private dailyExhausted = new Map<string, number>();

  /** apiKey -> timestampExpiresAt para claves con error 400 temporal (5 min) */
  private invalidKeys = new Map<string, number>();

  /**
   * Calcula el timestamp en milisegundos correspondiente a la próxima medianoche
   * en hora del Pacífico (Google AI Studio reset time: America/Los_Angeles).
   */
  getMidnightPacificTimestamp(): number {
    const now = new Date();
    const formatter = new Intl.DateTimeFormat('en-US', {
      timeZone: 'America/Los_Angeles',
      year: 'numeric',
      month: 'numeric',
      day: 'numeric',
      hour: 'numeric',
      minute: 'numeric',
      second: 'numeric',
      hour12: false,
    });

    const parts = formatter.formatToParts(now);
    const dateObj: Record<string, string> = {};
    for (const p of parts) {
      dateObj[p.type] = p.value;
    }

    const pacificYear = parseInt(dateObj.year, 10);
    const pacificMonth = parseInt(dateObj.month, 10) - 1;
    const pacificDay = parseInt(dateObj.day, 10);

    // Próxima medianoche en hora del Pacífico (+7h para UTC aproximadamente)
    const nextMidnightPacific = new Date(Date.UTC(pacificYear, pacificMonth, pacificDay + 1, 7, 0, 5));
    return nextMidnightPacific.getTime();
  }

  /**
   * Extrae un arreglo limpio de claves API a partir de cualquier formato:
   * String único, lista separada por comas, objeto JSON, string JSON serializado o fragmentos.
   */
  extractCleanApiKeys(input: unknown): string[] {
    if (!input) return [];
    const results: string[] = [];

    const processItem = (item: unknown) => {
      if (!item) return;

      if (Array.isArray(item)) {
        for (const sub of item) {
          processItem(sub);
        }
        return;
      }

      if (typeof item === 'object' && item !== null) {
        const obj = item as Record<string, unknown>;
        const val =
          obj.apiKey ||
          obj.GOOGLE_API_KEY ||
          obj.GOOGLE_KEY ||
          obj.GEMINI_API_KEY ||
          obj.googleKey ||
          obj.key;

        if (val) {
          processItem(val);
        } else {
          for (const v of Object.values(obj)) {
            processItem(v);
          }
        }
        return;
      }

      if (typeof item !== 'string') return;
      let str = item.trim();
      if (!str || str === 'user_provided') return;

      // Desempaquetar comillas exteriores
      if ((str.startsWith('"') && str.endsWith('"')) || (str.startsWith("'") && str.endsWith("'"))) {
        str = str.slice(1, -1).trim();
      }

      // Si parece JSON, parsear primero ANTES de dividir por comas
      if (str.startsWith('{') || str.startsWith('[')) {
        try {
          const parsed = JSON.parse(str);
          processItem(parsed);
          return;
        } catch (_) {
          // Si el JSON estaba truncado, continuar a regex
        }
      }

      // Si contiene comas (lista de llaves), procesar cada una
      if (str.includes(',')) {
        for (const part of str.split(',')) {
          processItem(part);
        }
        return;
      }

      // Detectar clave Google directa AIza...
      const aizaMatch = str.match(/AIza[0-9A-Za-z_-]{30,}/);
      if (aizaMatch) {
        const k = aizaMatch[0].trim();
        if (k && !results.includes(k)) {
          results.push(k);
        }
        return;
      }

      // Limpieza profunda de prefijos y sufijos JSON residuales
      str = str
        .replace(/^[{\[\s]*"(?:apiKey|GOOGLE_API_KEY|GOOGLE_KEY|GEMINI_API_KEY|googleKey|key)"\s*:\s*["']?/i, '')
        .replace(/["'}\]\s]+$/g, '')
        .replace(/^["'{\[\s]+/, '')
        .trim();

      if (str && str !== 'user_provided' && !results.includes(str)) {
        results.push(str);
      }
    };

    processItem(input);
    return results;
  }

  /**
   * Extrae la primera clave limpia en caso de venir embebida en JSON o con comillas
   */
  extractCleanApiKey(rawKey: unknown): string {
    const keys = this.extractCleanApiKeys(rawKey);
    return keys[0] || '';
  }

  /**
   * Enmascara una clave API para logs seguros (ej. "AIza...4b1f")
   */
  maskKey(key: string): string {
    if (!key || typeof key !== 'string') return 'null';
    const clean = this.extractCleanApiKey(key);
    if (!clean || clean.length <= 8) return '****';
    return `${clean.slice(0, 4)}...${clean.slice(-4)}`;
  }

  /**
   * Retorna una lista priorizada y balanceada de claves API para el modelo y usuario actual.
   *
   * 1. Elimina llaves cuyos cooldowns ya hayan expirado.
   * 2. Clasifica las llaves en:
   *    - READY: listas, sin cooldown y sin agotamiento diario para este modelo.
   *    - COOLING: en pausa temporal de tokens/minuto (RPM/TPM).
   *    - EXHAUSTED: con cuota diaria agotada para este modelo.
   * 3. Aplica Round-Robin cíclico a las llaves READY para no saturar nunca la Llave 0.
   * 4. Retorna `[...readyRotadas, ...cooling, ...exhausted]`.
   */
  getPrioritizedKeys(keys: string[], model = '', userId = 'global'): string[] {
    if (!Array.isArray(keys) || keys.length === 0) {
      return [];
    }

    const now = Date.now();

    // 1. Limpieza de expirados
    for (const [key, expiresAt] of this.invalidKeys.entries()) {
      if (expiresAt <= now) {
        this.invalidKeys.delete(key);
      }
    }
    for (const [key, expiresAt] of this.keyCooldowns.entries()) {
      if (expiresAt <= now) {
        this.keyCooldowns.delete(key);
      }
    }
    for (const [keyModel, expiresAt] of this.dailyExhausted.entries()) {
      if (expiresAt <= now) {
        this.dailyExhausted.delete(keyModel);
      }
    }

    const cleanKeys = this.extractCleanApiKeys(keys);

    // Filtrar llaves que hayan arrojado 400 Bad Request recientemente, salvo que todas lo sean
    const validKeys = cleanKeys.filter(
      (k) => !this.invalidKeys.has(k) || (this.invalidKeys.get(k) || 0) <= now
    );
    const candidateKeys = validKeys.length > 0 ? validKeys : cleanKeys;

    if (candidateKeys.length <= 1) {
      return candidateKeys;
    }

    const cleanModel = (model || '').toLowerCase().trim();

    // 2. Clasificación de llaves
    const readyKeys: string[] = [];
    const coolingKeys: string[] = [];
    const exhaustedKeys: string[] = [];

    for (const key of candidateKeys) {
      const cooldownKey = cleanModel ? `${key}_${cleanModel}` : key;
      const isCooling = this.keyCooldowns.has(cooldownKey) || this.keyCooldowns.has(key);
      const isDailyExhausted = cleanModel ? this.dailyExhausted.has(`${key}_${cleanModel}`) : false;

      if (isDailyExhausted) {
        exhaustedKeys.push(key);
      } else if (isCooling) {
        coolingKeys.push(key);
      } else {
        readyKeys.push(key);
      }
    }

    // 3. Round-Robin sobre las llaves READY
    let rotatedReadyKeys = readyKeys;
    if (readyKeys.length > 1) {
      const currentIndex = this.userRoundRobinIndex.get(userId) || 0;
      const safeIndex = currentIndex % readyKeys.length;

      // Desplazar el inicio al safeIndex
      rotatedReadyKeys = [
        ...readyKeys.slice(safeIndex),
        ...readyKeys.slice(0, safeIndex),
      ];

      // Avanzar el puntero para la próxima petición
      this.userRoundRobinIndex.set(userId, (safeIndex + 1) % readyKeys.length);
    } else if (readyKeys.length === 0 && coolingKeys.length > 0) {
      // Si todas las llaves de este modelo están en enfriamiento temporal, rotar sobre coolingKeys en vez de devolver []
      const currentIndex = this.userRoundRobinIndex.get(userId) || 0;
      const safeIndex = currentIndex % coolingKeys.length;
      rotatedReadyKeys = [
        ...coolingKeys.slice(safeIndex),
        ...coolingKeys.slice(0, safeIndex),
      ];
      this.userRoundRobinIndex.set(userId, (safeIndex + 1) % coolingKeys.length);
    } else if (readyKeys.length === 0 && coolingKeys.length === 0 && exhaustedKeys.length > 0) {
      // Rescate cíclico: Si todas las llaves estaban aisladas, permitir rotación de rescate
      const currentIndex = this.userRoundRobinIndex.get(userId) || 0;
      const safeIndex = currentIndex % exhaustedKeys.length;
      rotatedReadyKeys = [
        ...exhaustedKeys.slice(safeIndex),
        ...exhaustedKeys.slice(0, safeIndex),
      ];
      this.userRoundRobinIndex.set(userId, (safeIndex + 1) % exhaustedKeys.length);
    }

    const prioritized =
      readyKeys.length > 0
        ? [...rotatedReadyKeys, ...coolingKeys, ...exhaustedKeys]
        : [...rotatedReadyKeys, ...exhaustedKeys];

    if (coolingKeys.length > 0 || exhaustedKeys.length > 0) {
      console.log(
        `[GeminiPoolManager] Pool para modelo "${cleanModel || 'general'}": ` +
        `${readyKeys.length} listas, ${coolingKeys.length} en enfriamiento, ${exhaustedKeys.length} agotadas hoy. ` +
        `Llave elegida: ${this.maskKey(prioritized[0])}`
      );
    }

    return prioritized;
  }

  /**
   * Notifica un fallo o límite encontrado en una clave API específica.
   */
  reportKeyStatus(key: string, model = '', info: KeyStatusReport = {}): void {
    if (!key || typeof key !== 'string') return;

    const { status, message = '', retryDelayMs, isDailyLimit } = info;
    const cleanKey = this.extractCleanApiKey(key);
    const cleanModel = (model || '').toLowerCase().trim();
    const masked = this.maskKey(cleanKey || key);
    const msg = message.toLowerCase();

    // 0. Detección de Clave Inválida o Revocada
    const isInvalidKey =
      msg.includes('api_key_invalid') ||
      msg.includes('api key not valid') ||
      msg.includes('invalid api key') ||
      msg.includes('api_key_expired');

    if (isInvalidKey) {
      // Cooldown de 5 minutos
      this.invalidKeys.set(cleanKey, Date.now() + 5 * 60 * 1000);
      console.error(
        `[GeminiPoolManager] [CircuitBreaker] Llave ${masked} en pausa de 5m por error de clave inválida (400).`
      );
      return;
    }

    // 1. Detección de Cuota Diaria Agotada (RPD - Requests Per Day)
    const isDaily =
      isDailyLimit ||
      msg.includes('generaterequestsperday') ||
      msg.includes('daily request') ||
      /\b(?:requests?\s+per\s+day|per\s+day\b|daily\s+quota|daily\s+limit)/i.test(msg) ||
      (/\blimit:\s*20\b/i.test(msg) && (msg.includes('day') || !msg.includes('minute')));

    if (isDaily && cleanModel) {
      const resetTime = this.getMidnightPacificTimestamp();
      this.dailyExhausted.set(`${key}_${cleanModel}`, resetTime);
      const hoursUntilReset = Math.round((resetTime - Date.now()) / (1000 * 60 * 60));
      console.warn(
        `[GeminiPoolManager] [CircuitBreaker] Llave ${masked} AGOTADA HOY para "${cleanModel}". ` +
        `Aislada para este modelo hasta medianoche PT (~${hoursUntilReset}h). Disponible para otros modelos.`
      );
      return;
    }

    // 2. Detección de Límite Temporal de Frecuencia (429 RPM / TPM)
    const isRateLimit =
      status === 429 ||
      msg.includes('429') ||
      msg.includes('quota') ||
      msg.includes('too many requests') ||
      msg.includes('resource_exhausted');

    if (isRateLimit) {
      let delay = 25000; // 25s estándar
      if (typeof retryDelayMs === 'number' && retryDelayMs > 0) {
        delay = Math.min(Math.max(retryDelayMs, 3000), 60000);
      } else {
        const retryMatch = msg.match(/retry in ([0-9\.]+)s/);
        if (retryMatch && retryMatch[1]) {
          delay = Math.round(parseFloat(retryMatch[1]) * 1000) + 500;
        }
      }

      const cooldownKey = cleanModel ? `${key}_${cleanModel}` : key;
      this.keyCooldowns.set(cooldownKey, Date.now() + delay);
      console.warn(
        `[GeminiPoolManager] [CircuitBreaker] Llave ${masked} en pausa temporal de ${Math.round(
          delay / 1000
        )}s para "${cleanModel || 'general'}" por límite de frecuencia (429). Rotando a la siguiente llave...`
      );
      return;
    }

    // 3. Sobrecarga de Servidor (503 Service Unavailable / High Demand)
    const is503 = status === 503 || msg.includes('503') || msg.includes('high demand') || msg.includes('overloaded');
    if (is503) {
      console.info(
        `[GeminiPoolManager] Sobrecarga temporal (503) en modelo "${cleanModel}". Las claves API se conservan listas para el siguiente modelo en la escalera.`
      );
    }
  }

  /**
   * Notifica llamada exitosa: limpia cooldown de la clave.
   */
  reportKeySuccess(key: string, model = ''): void {
    if (!key || typeof key !== 'string') return;
    const cleanModel = (model || '').toLowerCase().trim();
    if (this.keyCooldowns.has(key)) {
      this.keyCooldowns.delete(key);
    }
    if (cleanModel && this.keyCooldowns.has(`${key}_${cleanModel}`)) {
      this.keyCooldowns.delete(`${key}_${cleanModel}`);
    }
  }

  /**
   * Obtiene estadísticas de salud del pool de claves para inspección.
   */
  getPoolStats(keys: string[], model = ''): PoolStats {
    const cleanKeys = this.extractCleanApiKeys(keys);
    const now = Date.now();
    let readyCount = 0;
    let coolingCount = 0;
    let dailyExhaustedCount = 0;
    let invalidCount = 0;

    const details = cleanKeys.map((k) => {
      const masked = this.maskKey(k);
      if (this.invalidKeys.has(k) && (this.invalidKeys.get(k) || 0) > now) {
        invalidCount++;
        return {
          key: masked,
          status: 'invalid' as const,
          cooldownRemainingMs: (this.invalidKeys.get(k) || 0) - now,
        };
      }
      if (model && this.dailyExhausted.has(`${k}_${model.toLowerCase()}`)) {
        dailyExhaustedCount++;
        return {
          key: masked,
          status: 'exhausted' as const,
          cooldownRemainingMs: (this.dailyExhausted.get(`${k}_${model.toLowerCase()}`) || 0) - now,
        };
      }
      if (this.keyCooldowns.has(k) && (this.keyCooldowns.get(k) || 0) > now) {
        coolingCount++;
        return {
          key: masked,
          status: 'cooling' as const,
          cooldownRemainingMs: (this.keyCooldowns.get(k) || 0) - now,
        };
      }
      readyCount++;
      return {
        key: masked,
        status: 'ready' as const,
      };
    });

    return {
      totalKeys: cleanKeys.length,
      readyKeys: readyCount,
      coolingKeys: coolingCount,
      dailyExhaustedKeys: dailyExhaustedCount,
      invalidKeys: invalidCount,
      details,
    };
  }
}

export const geminiPoolManager = new GeminiPoolManager();
