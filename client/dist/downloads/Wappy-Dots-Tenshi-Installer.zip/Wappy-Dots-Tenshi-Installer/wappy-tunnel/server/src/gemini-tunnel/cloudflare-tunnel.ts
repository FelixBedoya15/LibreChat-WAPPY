/**
 * cloudflare-tunnel.ts
 *
 * Administrador de Túnel Público Gratuito (Cloudflare Quick Tunnels) para Tenshi.
 * Permite acceder a Tenshi desde cualquier parte del mundo con datos móviles o Wi-Fi externo,
 * sin necesidad de comprar dominios, sin crear cuentas y 100% automático al iniciar la app.
 */

import { spawn, type ChildProcess } from 'node:child_process';
import { existsSync, mkdirSync, readFileSync, writeFileSync, chmodSync } from 'node:fs';
import { homedir, networkInterfaces } from 'node:os';
import { join } from 'node:path';
import QRCode from 'qrcode';

const HOME = homedir();
const WAPPY_DIR = join(HOME, '.wappy');
const BIN_DIR = join(WAPPY_DIR, 'bin');
const SHARED_FILES_DIR = join(WAPPY_DIR, 'shared-files');
const CLOUDFLARED_BIN = join(BIN_DIR, 'cloudflared');
const TUNNEL_STATE_PATH = join(WAPPY_DIR, 'public-tunnel.json');
const ARTIFACT_DIR = '/Users/venta/.gemini/antigravity/brain/41254d34-d184-4305-90a2-1bc0022aac60';

export interface PublicTunnelStatus {
  active: boolean;
  publicUrl: string | null;
  lanUrl: string;
  startedAt: string | null;
  error?: string;
}

let activeTunnelProcess: ChildProcess | null = null;
let activeCaffeinateProcess: ChildProcess | null = null;
let currentStatus: PublicTunnelStatus = {
  active: false,
  publicUrl: null,
  lanUrl: 'http://127.0.0.1:3001',
  startedAt: null,
};

function getLanIp(): string {
  try {
    const ifaces = networkInterfaces();
    for (const name of Object.keys(ifaces)) {
      for (const iface of ifaces[name] || []) {
        if (iface.family === 'IPv4' && !iface.internal) {
          return iface.address;
        }
      }
    }
  } catch {}
  return '127.0.0.1';
}

/**
 * Garantiza que el binario de cloudflared esté disponible en el sistema.
 * Si no está, lo descarga y desempaqueta automáticamente de los releases oficiales de Cloudflare.
 */
export async function ensureCloudflaredBinary(): Promise<string> {
  mkdirSync(BIN_DIR, { recursive: true });
  mkdirSync(SHARED_FILES_DIR, { recursive: true });

  if (existsSync(CLOUDFLARED_BIN)) {
    try {
      chmodSync(CLOUDFLARED_BIN, 0o755);
      return CLOUDFLARED_BIN;
    } catch {}
  }

  // Buscar si ya está en PATH
  try {
    const whichRes = Bun.which('cloudflared');
    if (whichRes && existsSync(whichRes)) {
      return whichRes;
    }
  } catch {}

  console.info('[CloudflareTunnel] Descargando binario oficial de cloudflared para macOS...');
  const arch = process.arch === 'arm64' ? 'darwin-arm64' : 'darwin-amd64';
  const url = `https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-${arch}.tgz`;
  const tarPath = join(BIN_DIR, 'cloudflared.tgz');

  const res = await fetch(url);
  if (!res.ok) {
    throw new Error(`Error al descargar cloudflared desde GitHub: ${res.statusText}`);
  }
  const arrayBuffer = await res.arrayBuffer();
  writeFileSync(tarPath, Buffer.from(arrayBuffer));

  const proc = spawn('tar', ['-xzf', tarPath, '-C', BIN_DIR]);
  await new Promise((resolve, reject) => {
    proc.on('close', (code) => (code === 0 ? resolve(true) : reject(new Error(`tar exited with code ${code}`))));
    proc.on('error', reject);
  });

  if (existsSync(CLOUDFLARED_BIN)) {
    chmodSync(CLOUDFLARED_BIN, 0o755);
    console.info('[CloudflareTunnel] cloudflared instalado con éxito en', CLOUDFLARED_BIN);
    return CLOUDFLARED_BIN;
  }

  throw new Error('No se pudo encontrar el binario de cloudflared después de la descarga');
}

/**
 * Regenera los códigos QR para celular apuntando a la URL pública (o LAN como fallback).
 */
export async function updateMobileQRCodes(targetUrl: string): Promise<void> {
  try {
    const fullUrl = targetUrl.endsWith('/mobile') ? targetUrl : `${targetUrl.replace(/\/$/, '')}/mobile`;
    const sharedQrPath = join(SHARED_FILES_DIR, 'qr_mobile_portal.png');
    await QRCode.toFile(sharedQrPath, fullUrl, {
      width: 420,
      margin: 2,
      color: { dark: '#000000', light: '#ffffff' },
    });

    if (existsSync(ARTIFACT_DIR)) {
      const artifactQrPath = join(ARTIFACT_DIR, 'qr_mobile_portal.png');
      await QRCode.toFile(artifactQrPath, fullUrl, {
        width: 420,
        margin: 2,
        color: { dark: '#000000', light: '#ffffff' },
      });
    }
    console.info(`[CloudflareTunnel] Códigos QR actualizados apuntando a: ${fullUrl}`);
  } catch (err) {
    console.warn('[CloudflareTunnel] Advertencia al generar QR:', err);
  }
}

/**
 * Inicia el túnel público gratuito de Cloudflare apuntando al puerto local.
 */
export async function startPublicTunnel(localPort = 3001): Promise<PublicTunnelStatus> {
  const lanIp = getLanIp();
  currentStatus.lanUrl = `http://${lanIp}:${localPort}`;

  if (activeTunnelProcess && currentStatus.active && currentStatus.publicUrl) {
    return currentStatus;
  }

  try {
    const binPath = await ensureCloudflaredBinary();

    // Detener túnel anterior si existiera
    stopPublicTunnel();

    console.info(`[CloudflareTunnel] Iniciando túnel hacia http://127.0.0.1:${localPort}...`);

    const child = spawn(binPath, ['tunnel', '--url', `http://127.0.0.1:${localPort}`], {
      stdio: ['ignore', 'pipe', 'pipe'],
    });
    activeTunnelProcess = child;

    // Activar caffeinate para evitar que macOS apague la red por inactividad
    try {
      activeCaffeinateProcess = spawn('caffeinate', ['-i', '-m', '-u']);
    } catch {}

    const urlPromise = new Promise<string>((resolve, reject) => {
      let resolved = false;
      const timeout = setTimeout(() => {
        if (!resolved) {
          reject(new Error('Tiempo de espera agotado esperando URL de Cloudflare'));
        }
      }, 25000);

      const onData = (chunk: Buffer) => {
        const text = chunk.toString();
        const match = text.match(/https:\/\/[a-zA-Z0-9-]+\.trycloudflare\.com/);
        if (match && !resolved) {
          resolved = true;
          clearTimeout(timeout);
          resolve(match[0]);
        }
      };

      child.stdout?.on('data', onData);
      child.stderr?.on('data', onData);

      child.on('error', (err) => {
        if (!resolved) {
          resolved = true;
          clearTimeout(timeout);
          reject(err);
        }
      });

      child.on('close', (code) => {
        if (!resolved) {
          resolved = true;
          clearTimeout(timeout);
          reject(new Error(`cloudflared cerró con código ${code}`));
        }
        currentStatus.active = false;
      });
    });

    const publicUrl = await urlPromise;
    currentStatus = {
      active: true,
      publicUrl,
      lanUrl: `http://${lanIp}:${localPort}`,
      startedAt: new Date().toISOString(),
    };

    // Guardar estado persistente en disco
    writeFileSync(TUNNEL_STATE_PATH, JSON.stringify(currentStatus, null, 2), 'utf8');

    // Actualizar los códigos QR para que el usuario escanee directamente el enlace público
    await updateMobileQRCodes(publicUrl);

    console.info('========================================================================');
    console.info(`🚀 [Tenshi Public Tunnel] ENLACE ACTIVO EN CUALQUIER RED MÓVIL (4G/5G/Wi-Fi):`);
    console.info(`👉 ${publicUrl}/mobile`);
    console.info('========================================================================');

    return currentStatus;
  } catch (err: any) {
    console.error('[CloudflareTunnel] Error al iniciar túnel:', err?.message || err);
    currentStatus = {
      active: false,
      publicUrl: null,
      lanUrl: `http://${lanIp}:${localPort}`,
      startedAt: null,
      error: err?.message || String(err),
    };
    // Fallback: actualizar QR con la IP LAN
    await updateMobileQRCodes(currentStatus.lanUrl);
    return currentStatus;
  }
}

/**
 * Detiene el túnel público y los procesos auxiliares.
 */
export function stopPublicTunnel(): void {
  if (activeTunnelProcess) {
    try {
      activeTunnelProcess.kill('SIGTERM');
    } catch {}
    activeTunnelProcess = null;
  }
  if (activeCaffeinateProcess) {
    try {
      activeCaffeinateProcess.kill('SIGTERM');
    } catch {}
    activeCaffeinateProcess = null;
  }
  currentStatus.active = false;
}

export function getPublicTunnelStatus(): PublicTunnelStatus {
  return currentStatus;
}
