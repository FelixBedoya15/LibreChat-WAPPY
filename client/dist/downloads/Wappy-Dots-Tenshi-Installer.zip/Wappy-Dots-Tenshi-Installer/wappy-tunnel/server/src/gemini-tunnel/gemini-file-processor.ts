/**
 * gemini-file-processor.ts
 *
 * Procesador multimodal de archivos para Wappy Dots (idéntico en capacidades a LibreChat-WAPPY):
 * Soporta exclusivamente:
 *   1. PDF (.pdf)                     -> Gemini inlineData / File API (visión + texto nativo de tablas/escaneos)
 *   2. Excel (.xlsx, .xls, .csv, .ods)-> Extracción completa de hojas/celdas con SheetJS (XLSX)
 *   3. Word (.docx, .doc, .rtf)       -> Extracción completa con Mammoth + fallback nativo macOS textutil
 *   4. Imágenes (.jpg, .png, .webp, .gif, .heic) -> Gemini inlineData (con conversión automática HEIC->JPEG vía sips)
 *   5. Audios (.mp3, .wav, .m4a, .ogg, .aac, .flac) -> Gemini inlineData / File API
 *   6. Videos (.mp4, .mov, .webm, .mpeg, .avi, .m4v) -> Gemini inlineData / File API (upload/v1beta/files)
 */

import { existsSync, readFileSync, statSync, unlinkSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { extname, basename, join } from 'node:path';
import { tmpdir } from 'node:os';
import * as XLSX from 'xlsx';
import * as mammoth from 'mammoth';

export interface ProcessedAttachment {
  kind: 'inline_media' | 'extracted_text';
  fileName: string;
  mimeType: string;
  /** Para Excel y Word: texto estructurado extraído de todas las hojas/páginas */
  extractedText?: string;
  /** Para PDF, Imagen, Audio y Video (<= 15 MB): base64 directo */
  base64Data?: string;
  /** Ruta absoluta en disco (usada si el archivo supera 15 MB para subirlo por Gemini File API) */
  filePath?: string;
  byteSize: number;
}

const INLINE_SIZE_LIMIT = 15 * 1024 * 1024; // 15 MB
const MAX_EXTRACTED_CHARS = 45_000; // Igual que LibreChat-WAPPY (tenshi.js maxLen = 45000) para evitar 429 por TPM

function compactSheetCsv(csv: string): string {
  if (!csv || !csv.trim()) return '';
  const lines = csv.split('\n');
  const cleaned: string[] = [];
  for (const line of lines) {
    const trimmed = line.replace(/,+$/, '').trim();
    if (trimmed && !/^,+$/.test(trimmed)) {
      cleaned.push(trimmed);
    }
  }
  return cleaned.join('\n').trim();
}

/**
 * Limpia documentos Word exportados como HTML / MHTML (como Informe_InvestigacionATEL.doc de WAPPY),
 * eliminando imágenes base64 incrustadas, cabeceras MIME, estilos CSS y bloques XML que inflan los tokens.
 */
function extractCleanTextFromHtmlOrMhtml(raw: string): string {
  let s = raw;
  // 1. Eliminar partes MIME codificadas en base64 (imágenes/binarios adjuntos en MHTML)
  s = s.replace(/Content-Transfer-Encoding:\s*base64[\s\S]*?(?=------=_NextPart|$)/gi, '\n');
  // 2. Eliminar data URIs base64 inline (ej. <img src="data:image/png;base64,...">)
  s = s.replace(/data:[a-zA-Z0-9/+.-]+;base64,[A-Za-z0-9+/=\r\n\s]+/g, '[IMAGEN]');
  // 3. Eliminar cabeceras MIME y fronteras multipart
  s = s.replace(/^MIME-Version:.*$/gim, '');
  s = s.replace(/^Content-(?:Type|Transfer-Encoding|Location|ID|Disposition):.*$/gim, '');
  s = s.replace(/------=_NextPart[^\r\n]*/g, '');
  // 4. Eliminar bloques <style>, <script>, <xml> y comentarios HTML
  s = s.replace(/<style\b[^>]*>[\s\S]*?<\/style>/gi, ' ');
  s = s.replace(/<script\b[^>]*>[\s\S]*?<\/script>/gi, ' ');
  s = s.replace(/<xml\b[^>]*>[\s\S]*?<\/xml>/gi, ' ');
  s = s.replace(/<!--[\s\S]*?-->/g, ' ');
  // 5. Preservar saltos de línea en párrafos, filas de tabla y encabezados, y separadores en celdas
  s = s.replace(/<\/(?:td|th)>/gi, ' | ');
  s = s.replace(/<(?:br|hr)\b[^>]*\/?>/gi, '\n');
  s = s.replace(/<\/(?:p|div|tr|li|h[1-6]|section|article|header|footer|table)>/gi, '\n');
  // 6. Quitar el resto de etiquetas HTML
  s = s.replace(/<[^>]+>/g, ' ');
  // 7. Decodificar entidades HTML comunes
  s = s
    .replace(/&nbsp;/gi, ' ')
    .replace(/&amp;/gi, '&')
    .replace(/&lt;/gi, '<')
    .replace(/&gt;/gi, '>')
    .replace(/&quot;/gi, '"')
    .replace(/&#39;/gi, "'")
    .replace(/&#(\d+);/g, (_, code) => {
      const n = parseInt(code, 10);
      return Number.isFinite(n) ? String.fromCharCode(n) : ' ';
    });
  // 8. Limpiar cadenas base64 sueltas residuales (>120 caracteres continuos sin espacios)
  s = s.replace(/[A-Za-z0-9+/=]{120,}/g, '');
  // 9. Compactar espacios y líneas vacías múltiples
  return s
    .split('\n')
    .map((line) => line.replace(/\s+/g, ' ').trim())
    .filter((line) => line.length > 0 && line !== '|')
    .join('\n')
    .trim();
}

function truncateExtractedText(text: string): string {
  const cleaned = text.replace(/data:[a-zA-Z0-9/+.-]+;base64,[A-Za-z0-9+/=\r\n]+/g, '[IMAGEN]').trim();
  if (cleaned.length <= MAX_EXTRACTED_CHARS) return cleaned;
  return (
    cleaned.slice(0, MAX_EXTRACTED_CHARS) +
    `\n\n... [Contenido truncado a ${MAX_EXTRACTED_CHARS} caracteres para proteger la cuota de tokens]`
  );
}

export function resolveMimeType(filePath: string): {
  category: 'pdf' | 'excel' | 'word' | 'image' | 'audio' | 'video' | 'unknown';
  mimeType: string;
} {
  const ext = extname(filePath).toLowerCase();
  switch (ext) {
    // PDF
    case '.pdf':
      return { category: 'pdf', mimeType: 'application/pdf' };

    // Excel
    case '.xlsx':
      return {
        category: 'excel',
        mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
      };
    case '.xls':
      return { category: 'excel', mimeType: 'application/vnd.ms-excel' };
    case '.csv':
      return { category: 'excel', mimeType: 'text/csv' };
    case '.tsv':
      return { category: 'excel', mimeType: 'text/tab-separated-values' };
    case '.ods':
      return { category: 'excel', mimeType: 'application/vnd.oasis.opendocument.spreadsheet' };

    // Word
    case '.docx':
      return {
        category: 'word',
        mimeType: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
      };
    case '.doc':
      return { category: 'word', mimeType: 'application/msword' };
    case '.rtf':
      return { category: 'word', mimeType: 'application/rtf' };

    // Imágenes
    case '.jpg':
    case '.jpeg':
      return { category: 'image', mimeType: 'image/jpeg' };
    case '.png':
      return { category: 'image', mimeType: 'image/png' };
    case '.webp':
      return { category: 'image', mimeType: 'image/webp' };
    case '.gif':
      return { category: 'image', mimeType: 'image/gif' };
    case '.heic':
    case '.heif':
      return { category: 'image', mimeType: 'image/heic' };
    case '.tiff':
    case '.tif':
      return { category: 'image', mimeType: 'image/tiff' };
    case '.bmp':
      return { category: 'image', mimeType: 'image/bmp' };

    // Audio
    case '.mp3':
      return { category: 'audio', mimeType: 'audio/mp3' };
    case '.wav':
      return { category: 'audio', mimeType: 'audio/wav' };
    case '.m4a':
      return { category: 'audio', mimeType: 'audio/mp4' };
    case '.aac':
      return { category: 'audio', mimeType: 'audio/aac' };
    case '.ogg':
    case '.oga':
    case '.opus':
      return { category: 'audio', mimeType: 'audio/ogg' };
    case '.flac':
      return { category: 'audio', mimeType: 'audio/flac' };

    // Video
    case '.mp4':
    case '.m4v':
      return { category: 'video', mimeType: 'video/mp4' };
    case '.mov':
      return { category: 'video', mimeType: 'video/quicktime' };
    case '.webm':
      return { category: 'video', mimeType: 'video/webm' };
    case '.mpeg':
    case '.mpg':
      return { category: 'video', mimeType: 'video/mpeg' };
    case '.avi':
      return { category: 'video', mimeType: 'video/x-msvideo' };
    case '.mkv':
      return { category: 'video', mimeType: 'video/x-matroska' };

    default:
      return { category: 'unknown', mimeType: 'application/octet-stream' };
  }
}

/**
 * Procesa un archivo local desde `filePath` para ser leído por Gemini.
 */
export async function processLocalAttachment(
  filePath: string,
  customName?: string,
): Promise<ProcessedAttachment | null> {
  if (!filePath || !existsSync(filePath)) {
    console.warn(`[GeminiFileProcessor] Archivo no encontrado en ruta: ${filePath}`);
    return null;
  }

  const fileName = customName || basename(filePath);
  const stat = statSync(filePath);
  const { category, mimeType } = resolveMimeType(filePath);

  // 1. EXCEL (.xlsx, .xls, .csv, .tsv, .ods)
  if (category === 'excel') {
    const buffer = readFileSync(filePath);
    const workbook = XLSX.read(buffer, { type: 'buffer' });
    let extractedSheets = '';
    for (const sheetName of workbook.SheetNames) {
      const worksheet = workbook.Sheets[sheetName];
      const rawCsv = XLSX.utils.sheet_to_csv(worksheet);
      const compacted = compactSheetCsv(rawCsv);
      if (compacted) {
        extractedSheets += `--- Hoja de Excel: ${sheetName} ---\n${compacted}\n\n`;
      }
    }
    const finalExcelText = truncateExtractedText(
      extractedSheets.trim() || '(El archivo de Excel está vacío o no contiene celdas con datos)',
    );
    return {
      kind: 'extracted_text',
      fileName,
      mimeType,
      extractedText: finalExcelText,
      byteSize: stat.size,
    };
  }

  // 2. WORD (.docx, .doc, .rtf)
  if (category === 'word') {
    const buffer = readFileSync(filePath);
    let text = '';
    const isZipDocx =
      buffer.length >= 4 && buffer[0] === 0x50 && buffer[1] === 0x4b && buffer[2] === 0x03 && buffer[3] === 0x04;

    // 2a. Si es un archivo .docx (ZIP OOXML), extraer con Mammoth (igual que LibreChat-WAPPY)
    if (isZipDocx || filePath.toLowerCase().endsWith('.docx')) {
      try {
        const result = await mammoth.extractRawText({ buffer });
        if (result?.value?.trim()) {
          text = result.value.trim();
        }
      } catch (e: any) {
        console.warn(`[GeminiFileProcessor] Mammoth falló en ${fileName}: ${e?.message}`);
      }
      if (!text) {
        try {
          const htmlRes = await mammoth.convertToHtml({ buffer });
          if (htmlRes?.value?.trim()) {
            text = extractCleanTextFromHtmlOrMhtml(htmlRes.value);
          }
        } catch {}
      }
    }

    // 2b. Detectar si el archivo .doc es un documento Word HTML / MHTML (como Informe_InvestigacionATEL.doc)
    if (!text) {
      const headSample = buffer.subarray(0, Math.min(buffer.length, 4096)).toString('utf8');
      const isHtmlOrMhtml =
        /MIME-Version:/i.test(headSample) ||
        /multipart\/related/i.test(headSample) ||
        /text\/html/i.test(headSample) ||
        /<!DOCTYPE\s+html/i.test(headSample) ||
        /<html\b/i.test(headSample) ||
        /<w:WordDocument\b/i.test(headSample);

      if (isHtmlOrMhtml) {
        const rawUtf8 = buffer.toString('utf8');
        text = extractCleanTextFromHtmlOrMhtml(rawUtf8);
      }
    }

    // 2c. Fallback con /usr/bin/textutil de macOS (para .doc binario OLE2 o .rtf)
    if (!text) {
      try {
        const out = execFileSync('/usr/bin/textutil', ['-convert', 'txt', '-stdout', filePath], {
          encoding: 'utf8',
          maxBuffer: 20 * 1024 * 1024,
        });
        if (out?.trim()) {
          text = extractCleanTextFromHtmlOrMhtml(out);
        }
      } catch (e: any) {
        console.warn(`[GeminiFileProcessor] textutil falló en ${fileName}: ${e?.message}`);
      }
    }

    const finalWordText = truncateExtractedText(
      text || '(No se pudo extraer texto legible del documento de Word)',
    );
    return {
      kind: 'extracted_text',
      fileName,
      mimeType,
      extractedText: finalWordText,
      byteSize: stat.size,
    };
  }

  // 3. IMÁGENES (.jpg, .png, .webp, .gif, .heic, .tiff, .bmp)
  if (category === 'image') {
    let targetPath = filePath;
    let finalMime = mimeType;
    let tempJpg: string | null = null;

    // Convertir HEIC / TIFF / BMP a JPEG usando sips de macOS para compatibilidad universal
    if (['image/heic', 'image/tiff', 'image/bmp'].includes(mimeType)) {
      try {
        tempJpg = join(tmpdir(), `wappy_img_${Date.now()}.jpg`);
        execFileSync('/usr/bin/sips', ['-s', 'format', 'jpeg', filePath, '--out', tempJpg], {
          stdio: 'ignore',
        });
        if (existsSync(tempJpg)) {
          targetPath = tempJpg;
          finalMime = 'image/jpeg';
        }
      } catch {}
    }

    const buffer = readFileSync(targetPath);
    if (tempJpg && existsSync(tempJpg)) {
      try {
        unlinkSync(tempJpg);
      } catch {}
    }

    return {
      kind: 'inline_media',
      fileName,
      mimeType: finalMime,
      base64Data: buffer.toString('base64'),
      filePath,
      byteSize: buffer.length,
    };
  }

  // 4. PDF, AUDIO Y VIDEO
  if (category === 'pdf' || category === 'audio' || category === 'video') {
    if (stat.size <= INLINE_SIZE_LIMIT) {
      const buffer = readFileSync(filePath);
      return {
        kind: 'inline_media',
        fileName,
        mimeType,
        base64Data: buffer.toString('base64'),
        filePath,
        byteSize: stat.size,
      };
    } else {
      // Archivo grande (> 15 MB): se subirá por Gemini File API (upload/v1beta/files)
      return {
        kind: 'inline_media',
        fileName,
        mimeType,
        filePath,
        byteSize: stat.size,
      };
    }
  }

  return null;
}

/**
 * Sube un archivo grande (> 15 MB, como videos o PDFs pesados) a Google Gemini File API
 * y espera hasta que su estado sea ACTIVE.
 */
export async function uploadToGeminiFileAPI(
  filePath: string,
  mimeType: string,
  displayName: string,
  apiKey: string,
): Promise<{ fileUri: string; mimeType: string }> {
  const fileBuffer = readFileSync(filePath);
  const numBytes = fileBuffer.length;

  // 1. Iniciar sesión resumable
  const startRes = await fetch(
    `https://generativelanguage.googleapis.com/upload/v1beta/files?key=${encodeURIComponent(apiKey)}`,
    {
      method: 'POST',
      headers: {
        'X-Goog-Upload-Protocol': 'resumable',
        'X-Goog-Upload-Command': 'start',
        'X-Goog-Upload-Header-Content-Length': String(numBytes),
        'X-Goog-Upload-Header-Content-Type': mimeType,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ file: { display_name: displayName } }),
    },
  );

  if (!startRes.ok) {
    throw new Error(`Error iniciando subida a Gemini File API: HTTP ${startRes.status}`);
  }

  const uploadUrl = startRes.headers.get('x-goog-upload-url');
  if (!uploadUrl) {
    throw new Error('Gemini File API no devolvió x-goog-upload-url');
  }

  // 2. Subir los bytes
  const uploadRes = await fetch(uploadUrl, {
    method: 'POST',
    headers: {
      'Content-Length': String(numBytes),
      'X-Goog-Upload-Offset': '0',
      'X-Goog-Upload-Command': 'upload, finalize',
    },
    body: fileBuffer,
  });

  if (!uploadRes.ok) {
    throw new Error(`Error subiendo bytes a Gemini File API: HTTP ${uploadRes.status}`);
  }

  const uploadJson: any = await uploadRes.json();
  const fileInfo = uploadJson.file;
  const fileUri = fileInfo?.uri;
  const fileName = fileInfo?.name;
  if (!fileUri) {
    throw new Error('Gemini File API no devolvió file.uri');
  }

  // 3. Esperar si está en estado PROCESSING (común en videos)
  let state = fileInfo?.state || 'ACTIVE';
  let attempts = 0;
  while (state === 'PROCESSING' && attempts < 45) {
    await new Promise((r) => setTimeout(r, 2000));
    attempts++;
    const checkRes = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/${fileName}?key=${encodeURIComponent(apiKey)}`,
    );
    if (checkRes.ok) {
      const checkJson: any = await checkRes.json();
      state = checkJson?.state || 'ACTIVE';
      if (state === 'FAILED') {
        throw new Error('El procesamiento del video/archivo en Gemini falló');
      }
    }
  }

  return { fileUri, mimeType: fileInfo?.mimeType || mimeType };
}

/**
 * Ejecuta una llamada multimodal nativa a `v1beta/models/{model}:generateContent`
 * soportando PDF, Imágenes, Audio, Video, Excel y Word, y devuelve formato OpenAI `chat.completion`.
 */
export async function generateMultimodalCompletion(params: {
  model: string;
  apiKey: string;
  messages: any[];
  attachment: ProcessedAttachment;
  maxTokens?: number;
}): Promise<any> {
  const { model, apiKey, messages, attachment, maxTokens = 8192 } = params;

  const systemParts: string[] = [];
  const contents: Array<{ role: 'user' | 'model'; parts: any[] }> = [];

  for (const m of messages) {
    const role = m.role;
    const rawText =
      typeof m.content === 'string'
        ? m.content
        : Array.isArray(m.content)
          ? m.content.map((b: any) => b?.text || '').join('\n')
          : '';
    if (role === 'system') {
      if (rawText.trim()) systemParts.push(rawText.trim());
    } else if (role === 'assistant' || role === 'model') {
      if (rawText.trim()) {
        contents.push({ role: 'model', parts: [{ text: rawText }] });
      }
    } else if (role === 'user') {
      if (rawText.trim()) {
        contents.push({ role: 'user', parts: [{ text: rawText }] });
      }
    }
  }

  if (contents.length === 0 || contents[contents.length - 1].role !== 'user') {
    contents.push({ role: 'user', parts: [{ text: 'Analiza el archivo adjunto.' }] });
  }

  // Adjuntar el archivo en el turno del usuario
  const targetTurn = contents[contents.length - 1];

  if (attachment.kind === 'extracted_text' && attachment.extractedText) {
    targetTurn.parts.unshift({
      text: `[ARCHIVO ADJUNTO CARGADO: "${attachment.fileName}" (${attachment.mimeType})]\nCONTENIDO COMPLETO DEL ARCHIVO:\n${attachment.extractedText}\n--- FIN DEL ARCHIVO ---\n\n`,
    });
  } else if (attachment.kind === 'inline_media') {
    if (attachment.base64Data) {
      targetTurn.parts.unshift({
        inlineData: {
          mimeType: attachment.mimeType,
          data: attachment.base64Data,
        },
      });
      targetTurn.parts.push({
        text: `\n(Nota: El archivo adjunto se llama "${attachment.fileName}". Analízalo directamente.)`,
      });
    } else if (attachment.filePath) {
      const uploaded = await uploadToGeminiFileAPI(
        attachment.filePath,
        attachment.mimeType,
        attachment.fileName,
        apiKey,
      );
      targetTurn.parts.unshift({
        fileData: {
          mimeType: uploaded.mimeType,
          fileUri: uploaded.fileUri,
        },
      });
      targetTurn.parts.push({
        text: `\n(Nota: El archivo multimedia adjunto se llama "${attachment.fileName}". Analízalo directamente.)`,
      });
    }
  }

  const payload: any = {
    contents,
    generationConfig: {
      maxOutputTokens: maxTokens,
      temperature: 0.4,
    },
  };

  if (systemParts.length > 0) {
    payload.systemInstruction = {
      parts: [{ text: systemParts.join('\n\n') }],
    };
  }

  const cleanModel = model.replace(/^models\//, '');
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${cleanModel}:generateContent?key=${encodeURIComponent(apiKey)}`;

  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });

  if (!res.ok) {
    const errText = await res.text();
    const err: any = new Error(errText || `HTTP ${res.status}`);
    err.status = res.status;
    err.rawText = errText;
    throw err;
  }

  const data: any = await res.json();
  const candidate = data?.candidates?.[0];
  const parts = candidate?.content?.parts ?? [];
  const answerText = parts
    .map((p: any) => (typeof p?.text === 'string' ? p.text : ''))
    .filter(Boolean)
    .join('\n')
    .trim();

  return {
    id: `wappy-mm-${Date.now()}`,
    object: 'chat.completion',
    created: Math.floor(Date.now() / 1000),
    model: cleanModel,
    choices: [
      {
        index: 0,
        message: {
          role: 'assistant',
          content: answerText || 'He revisado el archivo, ¿qué deseas saber en específico?',
        },
        finish_reason: 'stop',
      },
    ],
  };
}
