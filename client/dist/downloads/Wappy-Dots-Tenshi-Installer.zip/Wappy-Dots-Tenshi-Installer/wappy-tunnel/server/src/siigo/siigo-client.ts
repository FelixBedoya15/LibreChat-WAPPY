/**
 * Cliente oficial y robusto para la API V1 de Siigo Nube.
 *
 * Características:
 * - Cumplimiento estricto del estándar de Siigo: https://siigoapi.docs.apiary.io/
 * - Inclusión obligatoria del encabezado `Partner-Id` (3-100 caracteres alfanuméricos).
 * - Autenticación JWT OAuth contra `https://api.siigo.com/auth` con renovación automática anticipada.
 * - Soporte para configuración en ~/.wappy/siigo-config.json o variables de entorno.
 * - Modo Sandbox con persistencia en memoria y datos simulados colombianos para operar
 *   sin fallos mientras el usuario ingresa sus claves reales de Siigo.
 */

import { existsSync, readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';
import type {
  SiigoAuthConfig,
  SiigoAuthResponse,
  SiigoCustomer,
  SiigoInvoice,
  SiigoProduct,
  SiigoVoucher,
  SiigoDocumentType,
  SiigoPaymentType,
  SiigoTax,
  SiigoUser,
  SiigoStatusResponse,
} from './siigo-types';
import {
  MOCK_CUSTOMERS,
  MOCK_INVOICES,
  MOCK_PRODUCTS,
  MOCK_VOUCHERS,
  MOCK_DOCUMENT_TYPES,
  MOCK_PAYMENT_TYPES,
  MOCK_TAXES,
  MOCK_USERS,
} from './siigo-mock-data';

const CONFIG_PATH = join(homedir(), '.wappy', 'siigo-config.json');
const DEFAULT_BASE_URL = 'https://api.siigo.com/v1';
const DEFAULT_AUTH_URL = 'https://api.siigo.com/auth';
const DEFAULT_PARTNER_ID = 'WappyBot';

export class SiigoClient {
  private config: SiigoAuthConfig;
  private accessToken: string | null = null;
  private tokenExpiresAt: number | null = null;
  private authPromise: Promise<string> | null = null;

  // Repositorios en memoria para el modo Sandbox
  private sandboxCustomers: SiigoCustomer[] = [...MOCK_CUSTOMERS];
  private sandboxInvoices: SiigoInvoice[] = [...MOCK_INVOICES];
  private sandboxProducts: SiigoProduct[] = [...MOCK_PRODUCTS];
  private sandboxVouchers: SiigoVoucher[] = [...MOCK_VOUCHERS];

  constructor(customConfig?: Partial<SiigoAuthConfig>) {
    this.config = this.loadConfig(customConfig);
  }

  /**
   * Carga la configuración combinando archivo ~/.wappy/siigo-config.json,
   * variables de entorno y valores por defecto.
   */
  public loadConfig(custom?: Partial<SiigoAuthConfig>): SiigoAuthConfig {
    let fileConfig: Partial<SiigoAuthConfig> = {};
    if (existsSync(CONFIG_PATH)) {
      try {
        const raw = readFileSync(CONFIG_PATH, 'utf8');
        fileConfig = JSON.parse(raw);
      } catch (err) {
        console.warn('[SiigoClient] Error al leer ~/.wappy/siigo-config.json:', err);
      }
    }

    const partnerIdRaw =
      custom?.partner_id ||
      fileConfig.partner_id ||
      process.env.SIIGO_PARTNER_ID ||
      DEFAULT_PARTNER_ID;

    // Validación según documentación oficial de Siigo:
    // Alfanumérico, sin espacios ni caracteres especiales, entre 3 y 100 caracteres.
    const partnerIdClean = partnerIdRaw.replace(/[^a-zA-Z0-9]/g, '').slice(0, 100);
    const partnerId = partnerIdClean.length >= 3 ? partnerIdClean : DEFAULT_PARTNER_ID;

    const username = (
      custom?.username ??
      fileConfig.username ??
      process.env.SIIGO_USERNAME ??
      ''
    ).trim();

    const accessKey = (
      custom?.access_key ??
      fileConfig.access_key ??
      process.env.SIIGO_ACCESS_KEY ??
      ''
    ).trim();

    const sandbox =
      custom?.sandbox !== undefined
        ? custom.sandbox
        : fileConfig.sandbox !== undefined
          ? fileConfig.sandbox
          : process.env.SIIGO_SANDBOX !== undefined
            ? process.env.SIIGO_SANDBOX === 'true'
            : !username || !accessKey;

    this.config = {
      username,
      access_key: accessKey,
      partner_id: partnerId,
      sandbox,
      base_url: custom?.base_url || fileConfig.base_url || process.env.SIIGO_BASE_URL || DEFAULT_BASE_URL,
      auth_url: custom?.auth_url || fileConfig.auth_url || process.env.SIIGO_AUTH_URL || DEFAULT_AUTH_URL,
    };

    return this.config;
  }

  /**
   * Guarda y actualiza la configuración en ~/.wappy/siigo-config.json
   */
  public saveConfig(updates: Partial<SiigoAuthConfig>): SiigoStatusResponse {
    const dir = join(homedir(), '.wappy');
    if (!existsSync(dir)) {
      mkdirSync(dir, { recursive: true });
    }

    const newConfig: SiigoAuthConfig = {
      ...this.config,
      ...updates,
    };

    if (updates.partner_id) {
      const clean = updates.partner_id.replace(/[^a-zA-Z0-9]/g, '').slice(0, 100);
      newConfig.partner_id = clean.length >= 3 ? clean : DEFAULT_PARTNER_ID;
    }

    // Si el usuario proporciona credenciales válidas y no especifica sandbox, cambiamos a modo live
    if (newConfig.username && newConfig.access_key && updates.sandbox === undefined) {
      newConfig.sandbox = false;
    }

    const toPersist = {
      username: newConfig.username || '',
      access_key: newConfig.access_key || '',
      partner_id: newConfig.partner_id || DEFAULT_PARTNER_ID,
      sandbox: Boolean(newConfig.sandbox),
      base_url: newConfig.base_url || DEFAULT_BASE_URL,
      auth_url: newConfig.auth_url || DEFAULT_AUTH_URL,
      _instructions:
        "Ingresa tu 'username' (correo de Siigo Nube) y 'access_key' (generada en Siigo: Más configuraciones > API/Integraciones > Credenciales Usuario API). Mientras estén vacías, Wappy Bot operará en modo sandbox con datos simulados.",
    };

    writeFileSync(CONFIG_PATH, JSON.stringify(toPersist, null, 2), 'utf8');

    // Invalida token previo para reautenticar con los nuevos datos
    this.accessToken = null;
    this.tokenExpiresAt = null;
    this.config = newConfig;

    return this.getStatus();
  }

  /**
   * Retorna el estado actual de conexión e integración de Siigo.
   */
  public getStatus(): SiigoStatusResponse {
    const hasUsername = Boolean(this.config.username && this.config.username.length > 3);
    const hasKey = Boolean(this.config.access_key && this.config.access_key.length > 5);
    const isConfigured = hasUsername && hasKey;
    const isSandbox = Boolean(this.config.sandbox || !isConfigured);

    let masked: string | null = null;
    if (this.config.username) {
      const parts = this.config.username.split('@');
      if (parts.length === 2) {
        const u = parts[0];
        masked = `${u.slice(0, 2)}***@${parts[1]}`;
      } else {
        masked = `${this.config.username.slice(0, 3)}***`;
      }
    }

    const now = Date.now();
    const isAuthenticated = Boolean(
      !isSandbox && this.accessToken && this.tokenExpiresAt && this.tokenExpiresAt > now,
    );

    let msg = '';
    if (isSandbox) {
      msg = isConfigured
        ? 'Siigo configurado en modo Sandbox de pruebas.'
        : 'Siigo sin credenciales configuradas; operando con sandbox de datos simulados.';
    } else {
      msg = isAuthenticated
        ? 'Conectado exitosamente a la API en producción de Siigo Nube.'
        : 'Credenciales ingresadas. Listo para autenticar en el primer llamado.';
    }

    return {
      configured: isConfigured,
      sandbox: isSandbox,
      partnerId: this.config.partner_id || DEFAULT_PARTNER_ID,
      usernameMasked: masked,
      hasAccessKey: hasKey,
      authenticated: isAuthenticated,
      tokenExpiresAt: this.tokenExpiresAt ? new Date(this.tokenExpiresAt).toISOString() : null,
      apiUrl: this.config.base_url || DEFAULT_BASE_URL,
      mode: isSandbox ? 'sandbox' : 'live',
      message: msg,
    };
  }

  /**
   * Autenticación OAuth contra el endpoint /auth de Siigo.
   * Maneja el token JWT en caché y renueva automáticamente antes de expirar.
   */
  public async authenticate(force = false): Promise<string> {
    if (this.config.sandbox || !this.config.username || !this.config.access_key) {
      return 'SANDBOX_MOCK_TOKEN';
    }

    const now = Date.now();
    // Reutilizar token si aún tiene más de 5 minutos de vigencia
    if (!force && this.accessToken && this.tokenExpiresAt && this.tokenExpiresAt - now > 5 * 60 * 1000) {
      return this.accessToken;
    }

    // Evitar llamadas de autenticación simultáneas concurrentes
    if (this.authPromise) {
      return this.authPromise;
    }

    this.authPromise = (async () => {
      try {
        const authUrl = this.config.auth_url || DEFAULT_AUTH_URL;
        const partnerId = this.config.partner_id || DEFAULT_PARTNER_ID;

        const res = await fetch(authUrl, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Partner-Id': partnerId,
          },
          body: JSON.stringify({
            username: this.config.username,
            access_key: this.config.access_key,
          }),
        });

        if (!res.ok) {
          const errText = await res.text();
          let parsedErr: any = {};
          try {
            parsedErr = JSON.parse(errText);
          } catch {}
          const errorMsg =
            parsedErr?.Errors?.[0]?.Message ||
            parsedErr?.message ||
            parsedErr?.error ||
            `Error ${res.status}: ${res.statusText}`;
          throw new Error(`[Siigo /auth] Fallo de autenticación: ${errorMsg}`);
        }

        const data = (await res.json()) as SiigoAuthResponse;
        if (!data.access_token) {
          throw new Error('[Siigo /auth] La respuesta no contiene access_token válido.');
        }

        this.accessToken = data.access_token;
        // expires_in usualmente es 86400 (24h)
        const expiresInSec = Number(data.expires_in) || 86400;
        this.tokenExpiresAt = Date.now() + expiresInSec * 1000;

        return this.accessToken;
      } finally {
        this.authPromise = null;
      }
    })();

    return this.authPromise;
  }

  /**
   * Realiza una petición autenticada a la API de Siigo.
   */
  private async request<T = any>(
    endpoint: string,
    options: {
      method?: 'GET' | 'POST' | 'PUT' | 'DELETE';
      body?: any;
      query?: Record<string, string | number | boolean | undefined>;
    } = {},
  ): Promise<T> {
    const token = await this.authenticate();

    let urlStr = `${this.config.base_url || DEFAULT_BASE_URL}${endpoint.startsWith('/') ? endpoint : `/${endpoint}`}`;
    if (options.query) {
      const q = new URLSearchParams();
      for (const [k, v] of Object.entries(options.query)) {
        if (v !== undefined && v !== null && v !== '') {
          q.set(k, String(v));
        }
      }
      const qs = q.toString();
      if (qs) {
        urlStr += (urlStr.includes('?') ? '&' : '?') + qs;
      }
    }

    const partnerId = this.config.partner_id || DEFAULT_PARTNER_ID;

    const doFetch = async (authToken: string) => {
      return fetch(urlStr, {
        method: options.method || 'GET',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken}`,
          'Partner-Id': partnerId,
        },
        body: options.body ? JSON.stringify(options.body) : undefined,
      });
    };

    let res = await doFetch(token);

    // Si Siigo responde 401 Unauthorized, forzamos renovación del token e intentamos una vez más
    if (res.status === 401) {
      const freshToken = await this.authenticate(true);
      res = await doFetch(freshToken);
    }

    if (!res.ok) {
      const raw = await res.text();
      let errObj: any = {};
      try {
        errObj = JSON.parse(raw);
      } catch {}
      const details =
        errObj?.Errors?.map((e: any) => `${e.Code || ''}: ${e.Message || ''} ${e.Detail || ''}`).join('; ') ||
        errObj?.message ||
        raw ||
        `HTTP ${res.status}`;
      throw new Error(`Siigo API Error (${res.status}): ${details}`);
    }

    return (await res.json()) as T;
  }

  /**
   * Prueba de conectividad con Siigo.
   */
  public async testConnection(): Promise<{ success: boolean; message: string; data?: any }> {
    if (this.config.sandbox || !this.config.username || !this.config.access_key) {
      return {
        success: true,
        message: 'Modo Sandbox activo. Conectividad simulada funcionando correctamente.',
        data: {
          mode: 'sandbox',
          partnerId: this.config.partner_id,
          mockCustomersCount: this.sandboxCustomers.length,
          mockInvoicesCount: this.sandboxInvoices.length,
          mockProductsCount: this.sandboxProducts.length,
        },
      };
    }

    try {
      const token = await this.authenticate(true);
      // Validamos consultando tipos de documentos (endpoint ligero)
      const docTypes = await this.request('/document-types?type=FV');
      return {
        success: true,
        message: '¡Conexión exitosa con Siigo Nube API V1!',
        data: {
          mode: 'live',
          partnerId: this.config.partner_id,
          tokenValid: true,
          expiresAt: this.tokenExpiresAt ? new Date(this.tokenExpiresAt).toISOString() : null,
          documentTypesFound: Array.isArray(docTypes) ? docTypes.length : 1,
        },
      };
    } catch (err: any) {
      return {
        success: false,
        message: `Fallo al conectar con Siigo: ${err.message}`,
      };
    }
  }

  // =========================================================================
  // CLIENTES (CUSTOMERS)
  // =========================================================================

  public async getCustomers(query?: {
    identification?: string;
    name?: string;
    page?: number;
    page_size?: number;
  }): Promise<{ results: SiigoCustomer[]; total_results?: number; page?: number }> {
    if (this.config.sandbox || !this.config.username || !this.config.access_key) {
      let filtered = [...this.sandboxCustomers];
      if (query?.identification) {
        filtered = filtered.filter((c) =>
          c.identification.toLowerCase().includes(String(query.identification).toLowerCase()),
        );
      }
      if (query?.name) {
        const qName = String(query.name).toLowerCase();
        filtered = filtered.filter(
          (c) =>
            c.name.some((n) => n.toLowerCase().includes(qName)) ||
            (c.commercial_name && c.commercial_name.toLowerCase().includes(qName)),
        );
      }
      return {
        results: filtered,
        total_results: filtered.length,
        page: query?.page || 1,
      };
    }

    return this.request('/customers', {
      method: 'GET',
      query: {
        identification: query?.identification,
        name: query?.name,
        page: query?.page || 1,
        page_size: query?.page_size || 25,
      },
    });
  }

  public async getCustomerById(id: string): Promise<SiigoCustomer | null> {
    if (this.config.sandbox || !this.config.username || !this.config.access_key) {
      const found = this.sandboxCustomers.find(
        (c) => c.id === id || c.identification === id,
      );
      return found || null;
    }

    try {
      return await this.request(`/customers/${id}`);
    } catch (err: any) {
      if (err.message?.includes('404')) return null;
      throw err;
    }
  }

  public async createCustomer(customer: SiigoCustomer): Promise<SiigoCustomer> {
    if (this.config.sandbox || !this.config.username || !this.config.access_key) {
      const created: SiigoCustomer = {
        ...customer,
        id: customer.id || `c-demo-${Date.now()}`,
        active: customer.active !== false,
        created_at: new Date().toISOString(),
      };
      this.sandboxCustomers.unshift(created);
      return created;
    }

    return this.request('/customers', {
      method: 'POST',
      body: customer,
    });
  }

  // =========================================================================
  // FACTURAS (INVOICES)
  // =========================================================================

  public async getInvoices(query?: {
    date_start?: string;
    date_end?: string;
    customer_identification?: string;
    page?: number;
    page_size?: number;
  }): Promise<{ results: SiigoInvoice[]; total_results?: number; page?: number }> {
    if (this.config.sandbox || !this.config.username || !this.config.access_key) {
      let filtered = [...this.sandboxInvoices];
      if (query?.customer_identification) {
        filtered = filtered.filter(
          (inv) => inv.customer?.identification === query.customer_identification,
        );
      }
      if (query?.date_start) {
        filtered = filtered.filter((inv) => inv.date >= query.date_start!);
      }
      if (query?.date_end) {
        filtered = filtered.filter((inv) => inv.date <= query.date_end!);
      }
      return {
        results: filtered,
        total_results: filtered.length,
        page: query?.page || 1,
      };
    }

    return this.request('/invoices', {
      method: 'GET',
      query: {
        date_start: query?.date_start,
        date_end: query?.date_end,
        customer_identification: query?.customer_identification,
        page: query?.page || 1,
        page_size: query?.page_size || 25,
      },
    });
  }

  public async getInvoiceById(id: string): Promise<SiigoInvoice | null> {
    if (this.config.sandbox || !this.config.username || !this.config.access_key) {
      const found = this.sandboxInvoices.find(
        (inv) => inv.id === id || String(inv.number) === id || inv.name === id,
      );
      return found || null;
    }

    try {
      return await this.request(`/invoices/${id}`);
    } catch (err: any) {
      if (err.message?.includes('404')) return null;
      throw err;
    }
  }

  public async getInvoicePdf(id: string): Promise<{ base64?: string; public_url?: string }> {
    if (this.config.sandbox || !this.config.username || !this.config.access_key) {
      return {
        public_url: `https://factura.siigo.com/view/demo-${id}`,
      };
    }

    return this.request(`/invoices/${id}/pdf`, { method: 'GET' });
  }

  public async createInvoice(invoice: Partial<SiigoInvoice>): Promise<SiigoInvoice> {
    if (this.config.sandbox || !this.config.username || !this.config.access_key) {
      const num = 1044 + this.sandboxInvoices.length;
      let total = 0;
      for (const it of invoice.items || []) {
        const lineTotal = (it.price || 0) * (it.quantity || 1);
        const taxVal = (it.taxes || []).reduce((acc, t) => acc + (lineTotal * (t.percentage || 0)) / 100, 0);
        total += lineTotal + taxVal;
      }

      const created: SiigoInvoice = {
        id: `f-demo-${Date.now()}`,
        document: invoice.document || { id: 24 },
        prefix: 'FV',
        number: num,
        name: `FV-${num}`,
        date: invoice.date || new Date().toISOString().slice(0, 10),
        customer: invoice.customer as any,
        cost_center: invoice.cost_center || 1,
        currency: invoice.currency || { code: 'COP', exchange_rate: 1 },
        seller: invoice.seller || 1,
        stamp: { status: 'Accepted' },
        mail: { status: 'Sent' },
        observations: invoice.observations || 'Factura emitida vía Tenshi & Wappy Bot',
        items: invoice.items || [],
        payments: invoice.payments || [{ id: 1, value: total, due_date: invoice.date }],
        total,
        balance: total,
        metadata: {
          created: new Date().toISOString(),
          dian_cufe: `demo-cufe-${Math.random().toString(16).slice(2)}`,
        },
        public_url: `https://factura.siigo.com/view/fv-${num}-demo`,
      };

      this.sandboxInvoices.unshift(created);
      return created;
    }

    return this.request('/invoices', {
      method: 'POST',
      body: invoice,
    });
  }

  // =========================================================================
  // PRODUCTOS Y SERVICIOS (PRODUCTS)
  // =========================================================================

  public async getProducts(query?: {
    code?: string;
    name?: string;
    page?: number;
    page_size?: number;
  }): Promise<{ results: SiigoProduct[]; total_results?: number; page?: number }> {
    if (this.config.sandbox || !this.config.username || !this.config.access_key) {
      let filtered = [...this.sandboxProducts];
      if (query?.code) {
        filtered = filtered.filter((p) =>
          p.code.toLowerCase().includes(String(query.code).toLowerCase()),
        );
      }
      if (query?.name) {
        filtered = filtered.filter((p) =>
          p.name.toLowerCase().includes(String(query.name).toLowerCase()),
        );
      }
      return {
        results: filtered,
        total_results: filtered.length,
        page: query?.page || 1,
      };
    }

    return this.request('/products', {
      method: 'GET',
      query: {
        code: query?.code,
        name: query?.name,
        page: query?.page || 1,
        page_size: query?.page_size || 25,
      },
    });
  }

  public async getProductById(id: string): Promise<SiigoProduct | null> {
    if (this.config.sandbox || !this.config.username || !this.config.access_key) {
      const found = this.sandboxProducts.find(
        (p) => p.id === id || p.code === id,
      );
      return found || null;
    }

    try {
      return await this.request(`/products/${id}`);
    } catch (err: any) {
      if (err.message?.includes('404')) return null;
      throw err;
    }
  }

  public async createProduct(product: Partial<SiigoProduct>): Promise<SiigoProduct> {
    if (this.config.sandbox || !this.config.username || !this.config.access_key) {
      const created: SiigoProduct = {
        id: `p-demo-${Date.now()}`,
        code: product.code || `PROD-${Date.now().toString().slice(-4)}`,
        name: product.name || 'Nuevo Servicio Wappy',
        account_group: product.account_group || 10,
        type: product.type || 'Service',
        stock_control: Boolean(product.stock_control),
        active: product.active !== false,
        tax_classification: product.tax_classification || 'Taxed',
        tax_included: Boolean(product.tax_included),
        taxes: product.taxes || [{ id: 1001, name: 'IVA 19%', percentage: 19 }],
        prices: product.prices || [{ currency_code: 'COP', price_list: [{ position: 1, value: 100000 }] }],
        unit: product.unit || '94',
        unit_label: product.unit_label || 'Servicio',
        description: product.description || '',
        available_quantity: product.available_quantity ?? 100,
      };
      this.sandboxProducts.unshift(created);
      return created;
    }

    return this.request('/products', {
      method: 'POST',
      body: product,
    });
  }

  // =========================================================================
  // RECIBOS DE CAJA / COMPROBANTES (VOUCHERS)
  // =========================================================================

  public async getVouchers(query?: {
    date_start?: string;
    date_end?: string;
    page?: number;
    page_size?: number;
  }): Promise<{ results: SiigoVoucher[]; total_results?: number; page?: number }> {
    if (this.config.sandbox || !this.config.username || !this.config.access_key) {
      let filtered = [...this.sandboxVouchers];
      if (query?.date_start) {
        filtered = filtered.filter((v) => v.date >= query.date_start!);
      }
      if (query?.date_end) {
        filtered = filtered.filter((v) => v.date <= query.date_end!);
      }
      return {
        results: filtered,
        total_results: filtered.length,
        page: query?.page || 1,
      };
    }

    return this.request('/vouchers', {
      method: 'GET',
      query: {
        date_start: query?.date_start,
        date_end: query?.date_end,
        page: query?.page || 1,
        page_size: query?.page_size || 25,
      },
    });
  }

  // =========================================================================
  // CATÁLOGOS BASE (DOCUMENT TYPES, PAYMENT TYPES, TAXES, USERS)
  // =========================================================================

  public async getDocumentTypes(type = 'FV'): Promise<SiigoDocumentType[]> {
    if (this.config.sandbox || !this.config.username || !this.config.access_key) {
      return type ? MOCK_DOCUMENT_TYPES.filter((d) => d.type === type) : MOCK_DOCUMENT_TYPES;
    }
    return this.request('/document-types', { method: 'GET', query: { type } });
  }

  public async getPaymentTypes(documentType = 'FV'): Promise<SiigoPaymentType[]> {
    if (this.config.sandbox || !this.config.username || !this.config.access_key) {
      return MOCK_PAYMENT_TYPES;
    }
    return this.request('/payment-types', { method: 'GET', query: { document_type: documentType } });
  }

  public async getTaxes(): Promise<SiigoTax[]> {
    if (this.config.sandbox || !this.config.username || !this.config.access_key) {
      return MOCK_TAXES;
    }
    return this.request('/taxes', { method: 'GET' });
  }

  public async getUsers(): Promise<SiigoUser[]> {
    if (this.config.sandbox || !this.config.username || !this.config.access_key) {
      return MOCK_USERS;
    }
    return this.request('/users', { method: 'GET' });
  }
}

// Instancia singleton compartida para el servidor
let sharedClientInstance: SiigoClient | null = null;

export function getSharedSiigoClient(): SiigoClient {
  if (!sharedClientInstance) {
    sharedClientInstance = new SiigoClient();
  }
  return sharedClientInstance;
}
