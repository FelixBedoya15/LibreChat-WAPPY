/**
 * agent-team-orchestrator.ts
 *
 * Orquestador Multi-Agente estilo OpenClaw para Wappy Dots (Tenshi Agent Team).
 * Coordina un equipo de agentes especialistas en paralelo y reporta cada evento en vivo
 * al Unix socket del Notch de Wappy Dots (`~/Library/Application Support/NotchBuddy/nb.sock`)
 * para que las píldoras y pasos de cada sub-agente se iluminen en tiempo real.
 */

import * as net from 'node:net';
import { homedir } from 'node:os';
import { join } from 'node:path';
import { existsSync } from 'node:fs';
import {
  listAntigravityProjects,
  listAntigravityChats,
  runAntigravityTask,
  generateSharedDocument,
  appendSharedChatMessage,
  resolveOrderedKeysAndModelsForAgent,
} from './antigravity-bridge';
import { geminiPoolManager } from './gemini-pool-manager';
import { getSharedSiigoClient } from '../siigo/siigo-client';
import { getSharedGoogleWorkspaceClient } from '../google/google-workspace-client';
import {
  getWappyMemorySnapshot,
  findRelevantSkillsForGoal,
  searchWappyHistoryFts,
  indexSessionMessageFts,
  runBackgroundLearningReview,
  registerCronRunner,
} from './wappy-autonomous-core';

export type TeamAgentId =
  | 'researcher'
  | 'antigravity'
  | 'workspace_erp'
  | 'browser_qa'
  | 'writer';

export interface DynamicSubagentSpec {
  id?: string;
  name: string;
  role: string;
  instructions: string;
  useWebSearch?: boolean;
}

export interface TeamAgentDefinition {
  id: TeamAgentId;
  name: string;
  notchAgentId: string;
  role: string;
  description: string;
}

export const TEAM_AGENTS: Record<TeamAgentId, TeamAgentDefinition> = {
  researcher: {
    id: 'researcher',
    name: 'Investigador Web & Normativo',
    notchAgentId: 'openclaw',
    role: 'Especialista en Búsqueda Web en Tiempo Real (Google Search Grounding 2025-2026)',
    description:
      'Investiga leyes, resoluciones (como Resolución 1843 de 2025), noticias, precios, documentación técnica y datos verificados en Google Search.',
  },
  antigravity: {
    id: 'antigravity',
    name: 'Ingeniero Antigravity',
    notchAgentId: 'antigravity',
    role: 'Especialista en Código, Repositorios y Sesiones de Google Antigravity',
    description:
      'Inspecciona proyectos locales, consulta conversaciones de Antigravity y ejecuta análisis técnicos de arquitectura y código.',
  },
  workspace_erp: {
    id: 'workspace_erp',
    name: 'Analista Siigo & Workspace',
    notchAgentId: 'openclaw',
    role: 'Especialista en ERP Siigo, Gmail, Google Calendar y Google Drive',
    description:
      'Consulta clientes, facturas y productos en Siigo Nube, correos en Gmail, agenda en Google Calendar y archivos en Google Drive.',
  },
  browser_qa: {
    id: 'browser_qa',
    name: 'Operador Web & Chrome',
    notchAgentId: 'openclaw',
    role: 'Operador de Navegador y Verificación de Sitios en Vivo',
    description:
      'Abre pestañas o búsquedas visuales en Chrome en el Mac y verifica páginas web en vivo.',
  },
  writer: {
    id: 'writer',
    name: 'Redactor & Generador Documental',
    notchAgentId: 'openclaw',
    role: 'Sintetizador Ejecutivo y Creador de Informes (HTML, PDF, Word, Excel)',
    description:
      'Consolida los hallazgos de todo el equipo de agentes y genera el informe ejecutivo o archivo descargable (PDF, DOCX, XLSX, HTML).',
  },
};

export interface TeamMissionInput {
  goal: string;
  agents?: TeamAgentId[];
  dynamicSubagents?: DynamicSubagentSpec[];
  project?: string;
  openBrowser?: boolean;
  outputFormat?: 'none' | 'html' | 'webpage' | 'pdf' | 'docx' | 'xlsx' | 'md';
  outputTitle?: string;
  apiKeys?: string[];
}

export interface SubagentStepResult {
  agentId: string;
  agentName: string;
  role: string;
  status: 'ok' | 'error';
  output: string;
  durationMs: number;
}

export interface TeamMissionResult {
  ok: boolean;
  missionId: string;
  goal: string;
  agentsUsed: TeamAgentId[];
  steps: SubagentStepResult[];
  synthesis: string;
  spokenSummary: string;
  generatedDoc?: {
    id: string;
    title: string;
    format: string;
    filename: string;
    url: string;
  };
  totalDurationMs: number;
}

const NOTCH_SOCKET_PATH = join(
  homedir(),
  'Library',
  'Application Support',
  'NotchBuddy',
  'nb.sock',
);

/**
 * Envía un evento en tiempo real al Unix domain socket de Wappy Dots (`nb.sock`)
 * para animar las píldoras de OpenClaw / Antigravity y mostrar el paso actual en el Notch.
 */
export async function emitNotchEvent(payload: Record<string, any>): Promise<void> {
  if (!existsSync(NOTCH_SOCKET_PATH)) return;
  return new Promise((resolve) => {
    const client = net.createConnection(NOTCH_SOCKET_PATH);
    const timer = setTimeout(() => {
      try {
        client.destroy();
      } catch {}
      resolve();
    }, 1200);

    client.on('connect', () => {
      const line = JSON.stringify(payload) + '\n';
      client.write(line, 'utf8', () => {
        clearTimeout(timer);
        try {
          client.end();
        } catch {}
        resolve();
      });
    });

    client.on('error', () => {
      clearTimeout(timer);
      resolve();
    });
  });
}

/**
 * Selecciona automáticamente los agentes especialistas ideales según el objetivo del usuario.
 */
export function selectTeamAgentsForGoal(goal: string, requested?: TeamAgentId[], outputFormat?: string): TeamAgentId[] {
  if (requested && requested.length > 0) {
    const unique = Array.from(new Set(requested.filter((id) => TEAM_AGENTS[id])));
    if (!unique.includes('writer')) unique.push('writer');
    return unique;
  }

  const lower = goal.toLowerCase();
  const chosen: TeamAgentId[] = [];

  // 1. Si menciona código, repositorio, proyecto, antigravity, bug, arquitectura
  if (
    /\b(codigo|código|proyecto|proyectos|repo|repositorio|antigravity|bug|error|arquitectura|backend|frontend|servidor|compila|script|typescript|swift)\b/i.test(
      lower,
    )
  ) {
    chosen.push('antigravity');
  }

  // 2. Si menciona Siigo, facturas, clientes, contabilidad, correo, gmail, calendario, agenda, drive
  if (
    /\b(siigo|factura|facturas|cliente|clientes|producto|productos|cotizacion|cotización|contabilidad|erp|correo|correos|gmail|email|calendario|agenda|reunion|reunión|drive|archivo)\b/i.test(
      lower,
    )
  ) {
    chosen.push('workspace_erp');
  }

  // 3. Si pide abrir navegador/pestaña/Chrome explícitamente
  if (/\b(abre en chrome|abre el navegador|abre una pestaña|muestrame en pantalla|muéstrame en chrome)\b/i.test(lower)) {
    chosen.push('browser_qa');
  }

  // 4. Siempre incluimos al Investigador Web si hay consulta normativa, actual o si no hay otro recolector
  if (
    chosen.length === 0 ||
    /\b(investiga|averigua|busca|norma|resolucion|resolución|decreto|ley|sst|actual|2024|2025|2026|mercado|comparativa|analisis|análisis|tendencia|web|internet|google)\b/i.test(
      lower,
    )
  ) {
    if (!chosen.includes('researcher')) chosen.unshift('researcher');
  }

  // 5. El Redactor & Sintetizador Ejecutivo siempre consolida el trabajo del equipo
  if (!chosen.includes('writer')) {
    chosen.push('writer');
  }

  return chosen;
}

/**
 * Recolecta resultados web reales y actualizados (2025-2026) de Google News RSS, Bing RSS y Wikipedia ES
 * para alimentar a los modelos oficiales del pool de Wappy (`gemini-3.5-flash-lite`, `gemini-3.8-flash`, `gemini-3.6-flash`)
 * sin depender de modelos externos ni agotar cuotas de Grounding experimental.
 */
export async function fetchLiveWebSearchSnippets(query: string): Promise<{
  snippetsText: string;
  sources: string[];
}> {
  const cleanQuery = query.trim();
  if (!cleanQuery) return { snippetsText: '', sources: [] };

  const items: string[] = [];
  const sources: string[] = [];

  const stripHtml = (s: string) =>
    s
      .replace(/<!\[CDATA\[|\]\]>/g, '')
      .replace(/<[^>]+>/g, ' ')
      .replace(/&nbsp;/gi, ' ')
      .replace(/&amp;/gi, '&')
      .replace(/&quot;/gi, '"')
      .replace(/&#39;/gi, "'")
      .replace(/&lt;/gi, '<')
      .replace(/&gt;/gi, '>')
      .replace(/\s+/g, ' ')
      .trim();

  await Promise.all([
    // 1. Google News Search RSS (Español / Latinoamérica / Colombia 2025-2026)
    (async () => {
      try {
        const url = `https://news.google.com/rss/search?q=${encodeURIComponent(cleanQuery)}&hl=es-419&gl=CO&ceid=CO:es-419`;
        const resp = await fetch(url, {
          headers: { 'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7)' },
          signal: AbortSignal.timeout(6000),
        });
        if (!resp.ok) return;
        const xml = await resp.text();
        const matches = [
          ...xml.matchAll(
            /<item>[\s\S]*?<title>([\s\S]*?)<\/title>[\s\S]*?<pubDate>([\s\S]*?)<\/pubDate>[\s\S]*?<description>([\s\S]*?)<\/description>[\s\S]*?<\/item>/g,
          ),
        ].slice(0, 8);
        for (const m of matches) {
          const title = stripHtml(m[1]);
          const pubDate = stripHtml(m[2]);
          const desc = stripHtml(m[3]);
          if (title) {
            items.push(`• [Google Search / Noticias - ${pubDate}] ${title}${desc && desc !== title ? ` — ${desc}` : ''}`);
            sources.push(title.slice(0, 90));
          }
        }
      } catch {}
    })(),

    // 2. Bing Web Search RSS
    (async () => {
      try {
        const url = `https://www.bing.com/search?q=${encodeURIComponent(cleanQuery)}&format=rss&setlang=es`;
        const resp = await fetch(url, {
          headers: {
            'User-Agent':
              'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
          },
          signal: AbortSignal.timeout(6000),
        });
        if (!resp.ok) return;
        const xml = await resp.text();
        const matches = [
          ...xml.matchAll(
            /<item>[\s\S]*?<title>([\s\S]*?)<\/title>[\s\S]*?<description>([\s\S]*?)<\/description>[\s\S]*?<\/item>/g,
          ),
        ].slice(0, 6);
        for (const m of matches) {
          const title = stripHtml(m[1]);
          const desc = stripHtml(m[2]);
          if (title && desc) {
            items.push(`• [Web] ${title}: ${desc}`);
            if (!sources.includes(title.slice(0, 90))) sources.push(title.slice(0, 90));
          }
        }
      } catch {}
    })(),

    // 3. Wikipedia ES Search API
    (async () => {
      try {
        const url = `https://es.wikipedia.org/w/api.php?action=query&list=search&srsearch=${encodeURIComponent(cleanQuery)}&utf8=1&format=json&srlimit=3`;
        const resp = await fetch(url, {
          headers: { 'User-Agent': 'WappyDots/1.0' },
          signal: AbortSignal.timeout(5000),
        });
        if (!resp.ok) return;
        const data: any = await resp.json();
        const searchList = data?.query?.search || [];
        for (const entry of searchList) {
          const title = stripHtml(String(entry.title || ''));
          const snippet = stripHtml(String(entry.snippet || ''));
          if (title && snippet) {
            items.push(`• [Enciclopedia] ${title}: ${snippet}`);
          }
        }
      } catch {}
    })(),
  ]);

  return {
    snippetsText: items.join('\n'),
    sources: sources.slice(0, 6),
  };
}

/**
 * Ejecuta una generación de texto utilizando EXCLUSIVAMENTE los modelos y la conexión oficial
 * del Wappy Gemini Rotation Tunnel (`resolveOrderedKeysAndModelsForAgent` + `geminiPoolManager`:
 * `gemini-3.5-flash-lite` -> `gemini-3.8-flash` -> `gemini-3.6-flash`, con rotación de claves en 429/403
 * y salto de modelo en 503, idéntico a `sgsstGemini.js` y `GoogleClient.js`).
 */
export async function callWappyTunnelGemini(
  prompt: string,
  options?: {
    agentRouteId?: string;
    useWebSearch?: boolean;
    webQuery?: string;
    systemInstruction?: string;
    extraKeys?: string[];
  },
): Promise<{ text: string; modelUsed: string; sources: string[] }> {
  const routeId = options?.agentRouteId || 'agent_team';
  const resolved = resolveOrderedKeysAndModelsForAgent(routeId);

  // Modelos oficiales que hoy utilizamos en Wappy (nunca modelos ajenos)
  const modelsToTry =
    resolved.models.length > 0
      ? resolved.models
      : ['gemini-3.5-flash-lite', 'gemini-3.8-flash', 'gemini-3.6-flash'];

  const candidateKeys = Array.from(
    new Set([...resolved.keys, ...(options?.extraKeys || [])].filter(Boolean)),
  );

  let finalPrompt = prompt;
  let webSources: string[] = [];

  if (options?.useWebSearch) {
    const queryToSearch = options.webQuery || prompt;
    const { snippetsText, sources } = await fetchLiveWebSearchSnippets(queryToSearch);
    webSources = sources;
    if (snippetsText) {
      finalPrompt = `[RESULTADOS REALES DE BÚSQUEDA WEB EN VIVO (2025-2026) PARA "${queryToSearch.slice(0, 120)}":\n${snippetsText}]\n\n===\nINSTRUCCIÓN:\nPrioriza estrictamente los hechos, fechas, leyes y resoluciones recientes (2025-2026) contenidos en los resultados web anteriores sobre cualquier conocimiento previo.\n\n${prompt}`;
    }
  }

  for (const currentModel of modelsToTry) {
    const prioritizedKeys = geminiPoolManager.getPrioritizedKeys(
      candidateKeys,
      currentModel,
      routeId,
    );

    for (const apiKey of prioritizedKeys) {
      try {
        const body: Record<string, any> = {
          contents: [{ role: 'user', parts: [{ text: finalPrompt }] }],
          generationConfig: {
            temperature: 0.15,
            maxOutputTokens: 4096,
          },
        };
        if (options?.systemInstruction) {
          body.systemInstruction = { parts: [{ text: options.systemInstruction }] };
        }

        const resp = await fetch(
          `https://generativelanguage.googleapis.com/v1beta/models/${currentModel}:generateContent?key=${encodeURIComponent(apiKey)}`,
          {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            signal: AbortSignal.timeout(15000),
            body: JSON.stringify(body),
          },
        );

        if (resp.ok) {
          const data: any = await resp.json();
          const parts = data?.candidates?.[0]?.content?.parts ?? [];
          const text = parts
            .map((p: any) => p?.text || '')
            .join(' ')
            .trim();
          if (text) {
            geminiPoolManager.reportKeySuccess(apiKey);
            return { text, modelUsed: currentModel, sources: webSources };
          }
        } else {
          const status = resp.status;
          const errText = await resp.text().catch(() => '');
          const msg = errText.toLowerCase();
          const isDailyLimit =
            msg.includes('generaterequestsperday') ||
            msg.includes('daily request') ||
            (msg.includes('limit: 20') && !msg.includes('minute'));

          geminiPoolManager.reportKeyStatus(apiKey, currentModel, {
            status,
            message: msg,
            isDailyLimit,
          });

          // En 503 o 404 saltar inmediatamente al siguiente modelo de la escalera Wappy
          if (
            status === 503 ||
            status === 404 ||
            msg.includes('overloaded') ||
            msg.includes('high demand') ||
            msg.includes('service unavailable')
          ) {
            break;
          }
          // En 429, 403 o 400 rotar a la siguiente clave API del pool
          continue;
        }
      } catch (err: any) {
        const m = String(err?.message || '').toLowerCase();
        if (m.includes('timeout') || m.includes('abort') || m.includes('503')) {
          break;
        }
        continue;
      }
    }
  }

  return { text: '', modelUsed: modelsToTry[0], sources: webSources };
}

async function runSpecialistAgent(
  agentId: TeamAgentId,
  input: TeamMissionInput,
  sessionId: string,
): Promise<SubagentStepResult> {
  const def = TEAM_AGENTS[agentId];
  const t0 = Date.now();

  await emitNotchEvent({
    hook_event_name: 'SubagentStart',
    coucou_agent: 'openclaw',
    session_id: sessionId,
    cwd: 'Team · Wappy Dots',
    subagent_name: def.name,
  });

  try {
    let output = '';

    if (agentId === 'researcher') {
      await emitNotchEvent({
        hook_event_name: 'PreToolUse',
        coucou_agent: 'openclaw',
        session_id: sessionId,
        cwd: 'Team · Wappy Dots',
        tool_name: 'WebSearch',
        tool_input: { query: `${ def.name }: ${input.goal.slice(0, 50)}` },
      });

      const { text: res } = await callWappyTunnelGemini(
        `Eres el ${def.name} del equipo de agentes de Wappy Dots.
Analiza e investiga exhaustivamente la siguiente misión con base en los resultados web actualizados (2025-2026):
"${input.goal}"

Entrega hechos concretos, fechas, normas vigentes, cifras y fuentes verificadas en español claro.`,
        {
          agentRouteId: 'agent_team',
          useWebSearch: true,
          webQuery: input.goal,
          extraKeys: input.apiKeys,
        },
      );
      output = res || 'No se obtuvieron resultados adicionales de búsqueda web.';
    } else if (agentId === 'antigravity') {
      await emitNotchEvent({
        hook_event_name: 'PreToolUse',
        coucou_agent: 'openclaw',
        session_id: sessionId,
        cwd: 'Team · Wappy Dots',
        tool_name: 'Task',
        tool_input: { command: `${def.name}: Analizando proyectos y sesiones` },
      });

      const projects = await listAntigravityProjects();
      const convs = await listAntigravityChats({ limit: 8 });
      const taskRes = await runAntigravityTask({
        project: input.project,
        prompt: input.goal,
        openInMac: false,
      });

      output = [
        `Proyectos detectados (${projects.length}): ${projects.map((p) => p.name).join(', ')}`,
        `Conversaciones recientes en Antigravity: ${convs
          .slice(0, 5)
          .map((c) => `${c.title} (${c.project || 'General'})`)
          .join(' | ')}`,
        `Análisis del Ingeniero Antigravity: ${taskRes.responseText}`,
      ].join('\n');
    } else if (agentId === 'workspace_erp') {
      await emitNotchEvent({
        hook_event_name: 'PreToolUse',
        coucou_agent: 'openclaw',
        session_id: sessionId,
        cwd: 'Team · Wappy Dots',
        tool_name: 'Read',
        tool_input: { query: `${def.name}: Consultando Siigo & Google Workspace` },
      });

      const parts: string[] = [];
      try {
        const siigo = getSharedSiigoClient();
        const siigoStatus = siigo.getConnectionStatus();
        if (siigoStatus.configured) {
          const customers = await siigo.getCustomers({ page_size: 5 }).catch(() => []);
          parts.push(`Siigo ERP conectado (${siigoStatus.username}). Clientes recientes: ${JSON.stringify(customers).slice(0, 500)}`);
        } else {
          parts.push('Siigo ERP: aún sin credenciales activas.');
        }
      } catch {
        parts.push('Siigo ERP: sin datos en esta sesión.');
      }

      try {
        const gClient = getSharedGoogleWorkspaceClient();
        const gStatus = gClient.getStatus();
        if (gStatus.connected) {
          const [emails, events, files] = await Promise.all([
            gClient.listEmails(4).catch(() => []),
            gClient.listUpcomingEvents(4).catch(() => []),
            gClient.listDriveFiles(5).catch(() => []),
          ]);
          parts.push(
            `Google Workspace conectado (${gStatus.email || 'activo'}):\n- Correos recientes: ${JSON.stringify(emails).slice(0, 500)}\n- Eventos próximos: ${JSON.stringify(events).slice(0, 500)}\n- Archivos en Drive: ${JSON.stringify(files).slice(0, 500)}`,
          );
        } else {
          parts.push('Google Workspace: cuenta pendiente de vincular en Ajustes → Integraciones.');
        }
      } catch {
        parts.push('Google Workspace: sin datos en esta sesión.');
      }

      output = parts.join('\n');
    } else if (agentId === 'browser_qa') {
      await emitNotchEvent({
        hook_event_name: 'PreToolUse',
        coucou_agent: 'openclaw',
        session_id: sessionId,
        cwd: 'Team · Wappy Dots',
        tool_name: 'WebFetch',
        tool_input: { query: `${def.name}: Abriendo búsqueda verificada` },
      });

      if (input.openBrowser) {
        const encoded = encodeURIComponent(input.goal);
        Bun.spawn(['open', `https://www.google.com/search?q=${encoded}`]);
      }
      output = `Verificación de navegador completada${input.openBrowser ? ' y pestaña abierta en pantalla' : ''}.`;
    }

    await emitNotchEvent({
      hook_event_name: 'SubagentStop',
      coucou_agent: 'openclaw',
      session_id: sessionId,
      cwd: 'Team · Wappy Dots',
      subagent_name: def.name,
    });

    return {
      agentId,
      agentName: def.name,
      role: def.role,
      status: 'ok',
      output,
      durationMs: Date.now() - t0,
    };
  } catch (err: any) {
    await emitNotchEvent({
      hook_event_name: 'SubagentStop',
      coucou_agent: 'openclaw',
      session_id: sessionId,
      cwd: 'Team · Wappy Dots',
      subagent_name: def.name,
    });
    return {
      agentId,
      agentName: def.name,
      role: def.role,
      status: 'error',
      output: err?.message || 'Error ejecutando sub-agente',
      durationMs: Date.now() - t0,
    };
  }
}

/**
 * Ejecuta un sub-agente personalizado instanciado bajo demanda (`sessions_spawn` + `subagent-announce` estilo OpenClaw).
 */
async function runDynamicSubagent(
  spec: DynamicSubagentSpec,
  input: TeamMissionInput,
  sessionId: string,
): Promise<SubagentStepResult> {
  const t0 = Date.now();
  const dynamicId = spec.id || `dyn_${spec.name.toLowerCase().replace(/[^a-z0-9]+/g, '_')}`;

  await emitNotchEvent({
    hook_event_name: 'SubagentStart',
    coucou_agent: 'openclaw',
    session_id: sessionId,
    cwd: 'Spawn · Wappy Dots',
    subagent_name: spec.name,
  });

  await emitNotchEvent({
    hook_event_name: 'PreToolUse',
    coucou_agent: 'openclaw',
    session_id: sessionId,
    cwd: 'Spawn · Wappy Dots',
    tool_name: spec.useWebSearch ? 'WebSearch' : 'Task',
    tool_input: { command: `${spec.name} (${spec.role}): ${spec.instructions.slice(0, 65)}` },
  });

  try {
    const { text } = await callWappyTunnelGemini(
      `Eres el sub-agente especializado "${spec.name}" (${spec.role}) convocado dinámicamente por Wappy Dots.
Instrucción específica para tu rol:
${spec.instructions}

Misión global del equipo:
"${input.goal}"

Entrega un análisis riguroso, accionable y directo en español.`,
      {
        agentRouteId: 'agent_team',
        useWebSearch: Boolean(spec.useWebSearch),
        webQuery: input.goal,
        extraKeys: input.apiKeys,
      },
    );

    await emitNotchEvent({
      hook_event_name: 'SubagentStop',
      coucou_agent: 'openclaw',
      session_id: sessionId,
      cwd: 'Spawn · Wappy Dots',
      subagent_name: spec.name,
    });

    return {
      agentId: dynamicId,
      agentName: spec.name,
      role: spec.role,
      status: 'ok',
      output: text || 'Sub-agente dinámico completado.',
      durationMs: Date.now() - t0,
    };
  } catch (err: any) {
    await emitNotchEvent({
      hook_event_name: 'SubagentStop',
      coucou_agent: 'openclaw',
      session_id: sessionId,
      cwd: 'Spawn · Wappy Dots',
      subagent_name: spec.name,
    });
    return {
      agentId: dynamicId,
      agentName: spec.name,
      role: spec.role,
      status: 'error',
      output: err?.message || 'Error en sub-agente dinámico',
      durationMs: Date.now() - t0,
    };
  }
}

/**
 * Ejecuta una misión completa con el Team de Agentes de Wappy Dots (estilo OpenClaw + Hermes).
 */
export async function runAgentTeamMission(input: TeamMissionInput): Promise<TeamMissionResult> {
  const t0 = Date.now();
  const missionId = `team_${Date.now().toString(36)}`;
  const selected = selectTeamAgentsForGoal(input.goal, input.agents, input.outputFormat);
  const workerAgents = selected.filter((a) => a !== 'writer');
  const dynamicSpecs = input.dynamicSubagents || [];

  // Indexar la solicitud en SQLite FTS5 BM25
  indexSessionMessageFts({
    id: `${missionId}_user`,
    sessionId: missionId,
    role: 'user',
    source: 'agent_team',
    project: input.project || 'Agent Team',
    content: input.goal,
  });

  // 1. Encender la píldora OpenClaw / Team en el Notch de Wappy Dots
  await emitNotchEvent({
    hook_event_name: 'SessionStart',
    coucou_agent: 'openclaw',
    session_id: missionId,
    cwd: 'Team · Wappy Dots',
  });

  await emitNotchEvent({
    hook_event_name: 'UserPromptSubmit',
    coucou_agent: 'openclaw',
    session_id: missionId,
    cwd: 'Team · Wappy Dots',
    prompt: `Team (${selected.length + dynamicSpecs.length} agentes): ${input.goal}`,
  });

  // 2. Ejecutar los agentes especialistas fijos + sub-agentes dinámicos en paralelo
  const workerSteps = await Promise.all([
    ...workerAgents.map((agentId) => runSpecialistAgent(agentId, input, missionId)),
    ...dynamicSpecs.map((spec) => runDynamicSubagent(spec, input, missionId)),
  ]);

  // 3. Recuperar Memoria Dual (USER.md + MEMORY.md), Skills relevantes (SKILL.md) y contexto FTS5 BM25
  const memorySnap = getWappyMemorySnapshot();
  const relevantSkills = findRelevantSkillsForGoal(input.goal, 2);
  const ftsHits = searchWappyHistoryFts(input.goal, 3);

  const skillsContext =
    relevantSkills.length > 0
      ? `\n[PROCEDIMIENTOS Y SKILLS ACTIVOS DE WAPPY DOTS]\n${relevantSkills
          .map((s) => `• ${s.title} (${s.slug}):\n${s.content}`)
          .join('\n\n')}\n`
      : '';

  const ftsContext =
    ftsHits.length > 0
      ? `\n[MEMORIA HISTÓRICA FTS5 BM25 RELACIONADA]\n${ftsHits
          .map((h) => `• [${h.project} · ${h.role}]: ${h.snippet}`)
          .join('\n')}\n`
      : '';

  // 4. Ejecutar el agente Redactor & Sintetizador Ejecutivo ('writer')
  const writerDef = TEAM_AGENTS.writer;
  const writerStart = Date.now();
  await emitNotchEvent({
    hook_event_name: 'SubagentStart',
    coucou_agent: 'openclaw',
    session_id: missionId,
    cwd: 'Team · Wappy Dots',
    subagent_name: writerDef.name,
  });

  await emitNotchEvent({
    hook_event_name: 'PreToolUse',
    coucou_agent: 'openclaw',
    session_id: missionId,
    cwd: 'Team · Wappy Dots',
    tool_name: 'Write',
    tool_input: { command: `${writerDef.name}: Consolidando resultados del equipo` },
  });

  const contextReport = workerSteps
    .map((s) => `### [${s.agentName} — ${s.role}]\n${s.output}`)
    .join('\n\n');

  const synthesisPrompt = `Eres Tenshi liderando el Team de Agentes de Wappy Dots (con arquitectura nativa OpenClaw + Hermes).
Misión solicitada por el usuario:
"${input.goal}"

A continuación tienes los informes entregados por tus agentes especialistas que trabajaron en paralelo:

${contextReport}
${skillsContext}${ftsContext}
INSTRUCCIONES:
1. Escribe primero una sección llamada "[RESUMEN HABLADO]" de 2 a 4 oraciones fluidas en español natural que resuma la conclusión exacta y mencione qué agentes del equipo intervinieron.
2. Escribe después una sección llamada "[INFORME DETALLADO]" en Markdown bien estructurado con todos los hallazgos, datos verificados, normas vigentes y pasos recomendados.`;

  const { text: rawSynthesis } = await callWappyTunnelGemini(synthesisPrompt, {
    agentRouteId: 'agent_team',
    useWebSearch: false,
    systemInstruction: memorySnap.systemPromptBlock,
    extraKeys: input.apiKeys,
  });

  let spokenSummary = '';
  let detailedSynthesis = rawSynthesis;

  const spokenMatch = rawSynthesis.match(/\[RESUMEN HABLADO\]\s*([\s\S]*?)(?=\[INFORME DETALLADO\]|$)/i);
  const detailMatch = rawSynthesis.match(/\[INFORME DETALLADO\]\s*([\s\S]*)$/i);

  if (spokenMatch?.[1]?.trim()) {
    spokenSummary = spokenMatch[1].trim().replace(/\*\*/g, '');
  }
  if (detailMatch?.[1]?.trim()) {
    detailedSynthesis = detailMatch[1].trim();
  }
  if (!spokenSummary) {
    spokenSummary = detailedSynthesis.split('\n').filter(Boolean).slice(0, 3).join(' ').replace(/\*\*/g, '');
  }

  let generatedDoc: TeamMissionResult['generatedDoc'] | undefined;
  let sharedFileObj: any;
  if (input.outputFormat && input.outputFormat !== 'none') {
    const docFormat = input.outputFormat === 'md' ? 'html' : input.outputFormat;
    const docTitle = input.outputTitle || `Informe Team Wappy Dots - ${input.goal.slice(0, 42)}`;
    const doc = await generateSharedDocument({
      title: docTitle,
      format: docFormat,
      content: detailedSynthesis,
      project: input.project || 'Wappy Dots Agent Team',
    });
    sharedFileObj = doc;
    generatedDoc = {
      id: doc.id,
      title: doc.title,
      format: doc.format,
      filename: doc.fileName,
      url: doc.localUrl,
    };
  }

  const allAgentNames = [
    ...selected.map((id) => TEAM_AGENTS[id]?.name),
    ...dynamicSpecs.map((d) => d.name),
  ].filter(Boolean);

  // Sincronizar con el historial compartido móvil y del Notch
  appendSharedChatMessage({
    role: 'assistant',
    content: `🤝 **Team de Agentes Wappy Dots (${allAgentNames.join(' · ')})**\n\n${detailedSynthesis}`,
    source: 'antigravity',
    project: input.project || 'Agent Team',
    files: sharedFileObj ? [sharedFileObj] : undefined,
  });

  // Indexar la síntesis en SQLite FTS5 BM25
  indexSessionMessageFts({
    id: `${missionId}_assistant`,
    sessionId: missionId,
    role: 'assistant',
    source: 'agent_team',
    project: input.project || 'Agent Team',
    content: detailedSynthesis,
  });

  // Disparar ciclo de auto-aprendizaje en segundo plano (Hermes Background Review) sin bloquear la respuesta
  void runBackgroundLearningReview({
    missionId,
    goal: input.goal,
    synthesis: detailedSynthesis,
    stepsCount: workerSteps.length + 1,
  });

  await emitNotchEvent({
    hook_event_name: 'SubagentStop',
    coucou_agent: 'openclaw',
    session_id: missionId,
    cwd: 'Team · Wappy Dots',
    subagent_name: writerDef.name,
  });

  const writerStep: SubagentStepResult = {
    agentId: 'writer',
    agentName: writerDef.name,
    role: writerDef.role,
    status: 'ok',
    output: detailedSynthesis,
    durationMs: Date.now() - writerStart,
  };

  const allSteps = [...workerSteps, writerStep];

  // 5. Notificar finalización al Notch de Wappy Dots
  await emitNotchEvent({
    hook_event_name: 'Stop',
    coucou_agent: 'openclaw',
    session_id: missionId,
    cwd: 'Team · Wappy Dots',
    last_assistant_message: `✓ Team completado (${allSteps.length} agentes): ${spokenSummary.slice(0, 90)}`,
  });

  return {
    ok: true,
    missionId,
    goal: input.goal,
    agentsUsed: selected,
    steps: allSteps,
    synthesis: detailedSynthesis,
    spokenSummary,
    generatedDoc,
    totalDurationMs: Date.now() - t0,
  };
}

// Registrar el motor de ejecución automática Cron para que ejecute misiones programadas
registerCronRunner(async (job) => {
  const res = await runAgentTeamMission({
    goal: `[AUTOMATIZACIÓN PROGRAMADA: ${job.name}] ${job.goal}`,
    agents: job.agents as TeamAgentId[] | undefined,
    outputFormat: job.outputFormat || 'none',
    project: `Cron · ${job.name}`,
  });
  return res.spokenSummary || res.synthesis.slice(0, 300);
});
