/**
 * google-workspace-client.ts
 *
 * Cliente oficial y unificado de Google Workspace para Wappy Bot y Tenshi.
 * Gestiona OAuth 2.0 (Gmail, Google Calendar, Google Drive, Google Sheets y Docs).
 */

import { existsSync, readFileSync, writeFileSync, mkdirSync } from 'node:fs';
import { homedir } from 'node:os';
import { join } from 'node:path';
import type {
  GoogleOAuthConfig,
  GoogleTokens,
  GoogleUserProfile,
  GoogleConnectionStatus,
  GmailMessageSummary,
  GmailFullMessage,
  CalendarEventItem,
  DriveFileItem,
  SheetValuesResult,
  GoogleDocContent,
} from './google-types';

const HOME = homedir();
const WAPPY_DIR = join(HOME, '.wappy');
const CONFIG_PATH = join(WAPPY_DIR, 'google-config.json');
const TOKENS_PATH = join(WAPPY_DIR, 'google-tokens.json');

const DEFAULT_CLIENT_ID = '802179818443-aai8ntr1eauqml063k7oo8ofpq02pl3j.apps.googleusercontent.com';
const DEFAULT_CLIENT_SECRET = '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';
const DEFAULT_REDIRECT_URI = 'http://localhost:3080/oauth/google/callback';

const DEFAULT_SCOPES = [
  'https://www.googleapis.com/auth/userinfo.email',
  'https://www.googleapis.com/auth/userinfo.profile',
  'https://www.googleapis.com/auth/drive',
  'https://www.googleapis.com/auth/calendar.events',
  'https://www.googleapis.com/auth/gmail.send',
  'https://www.googleapis.com/auth/gmail.compose',
  'https://www.googleapis.com/auth/gmail.readonly',
];

export class GoogleWorkspaceClient {
  private config: GoogleOAuthConfig;
  private tokens: GoogleTokens | null = null;
  private userProfile: GoogleUserProfile | null = null;
  private refreshPromise: Promise<string> | null = null;

  constructor() {
    this.config = this.loadConfig();
    this.loadTokens();
  }

  private loadConfig(): GoogleOAuthConfig {
    mkdirSync(WAPPY_DIR, { recursive: true });
    let fileConfig: Partial<GoogleOAuthConfig> = {};
    if (existsSync(CONFIG_PATH)) {
      try {
        fileConfig = JSON.parse(readFileSync(CONFIG_PATH, 'utf8'));
      } catch {}
    }

    return {
      client_id: fileConfig.client_id || process.env.GOOGLE_CLIENT_ID || DEFAULT_CLIENT_ID,
      client_secret: fileConfig.client_secret || process.env.GOOGLE_CLIENT_SECRET || DEFAULT_CLIENT_SECRET,
      redirect_uri: fileConfig.redirect_uri || process.env.GOOGLE_REDIRECT_URI || DEFAULT_REDIRECT_URI,
      scopes: fileConfig.scopes && fileConfig.scopes.length > 0 ? fileConfig.scopes : DEFAULT_SCOPES,
    };
  }

  private loadTokens(): void {
    if (existsSync(TOKENS_PATH)) {
      try {
        const raw = JSON.parse(readFileSync(TOKENS_PATH, 'utf8'));
        this.tokens = raw.tokens || null;
        this.userProfile = raw.profile || null;
      } catch {
        this.tokens = null;
        this.userProfile = null;
      }
    }
  }

  private saveTokens(): void {
    mkdirSync(WAPPY_DIR, { recursive: true });
    writeFileSync(
      TOKENS_PATH,
      JSON.stringify(
        {
          tokens: this.tokens,
          profile: this.userProfile,
          updated_at: new Date().toISOString(),
        },
        null,
        2,
      ),
      'utf8',
    );
  }

  /**
   * Genera la URL de autorización OAuth 2.0 de Google.
   */
  public getAuthUrl(state = 'wappy_dots_oauth'): string {
    const params = new URLSearchParams({
      client_id: this.config.client_id,
      redirect_uri: this.config.redirect_uri,
      response_type: 'code',
      scope: this.config.scopes.join(' '),
      access_type: 'offline',
      prompt: 'consent',
      state,
    });
    return `https://accounts.google.com/o/oauth2/v2/auth?${params.toString()}`;
  }

  /**
   * Intercambia el código de autorización devuelto por Google por tokens de acceso y refresco.
   */
  public async handleAuthCallback(code: string): Promise<{ profile: GoogleUserProfile; tokens: GoogleTokens }> {
    const res = await fetch('https://oauth2.googleapis.com/token', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams({
        code,
        client_id: this.config.client_id,
        client_secret: this.config.client_secret,
        redirect_uri: this.config.redirect_uri,
        grant_type: 'authorization_code',
      }),
    });

    if (!res.ok) {
      const errText = await res.text();
      throw new Error(`Error canjeando código de Google (${res.status}): ${errText}`);
    }

    const data = (await res.json()) as any;
    const expiryDate = Date.now() + (Number(data.expires_in) || 3600) * 1000;

    this.tokens = {
      access_token: data.access_token,
      refresh_token: data.refresh_token || this.tokens?.refresh_token,
      expiry_date: expiryDate,
      token_type: data.token_type,
      scope: data.scope,
    };

    // Consultar perfil de usuario
    try {
      const profileRes = await fetch('https://www.googleapis.com/oauth2/v2/userinfo', {
        headers: { Authorization: `Bearer ${this.tokens.access_token}` },
      });
      if (profileRes.ok) {
        this.userProfile = (await profileRes.json()) as GoogleUserProfile;
      }
    } catch {}

    this.saveTokens();
    return { profile: this.userProfile!, tokens: this.tokens };
  }

  /**
   * Obtiene un access_token válido, refrescándolo automáticamente si está próximo a vencer.
   */
  public async getAccessToken(): Promise<string> {
    if (!this.tokens) {
      throw new Error('Google Workspace no está conectado. Usa el botón "Conectar con Google".');
    }

    const now = Date.now();
    const isExpired = !this.tokens.expiry_date || this.tokens.expiry_date - now < 2 * 60 * 1000;

    if (!isExpired && this.tokens.access_token) {
      return this.tokens.access_token;
    }

    if (!this.tokens.refresh_token) {
      throw new Error('El token de Google expiró y no hay refresh_token disponible. Vuelve a autorizar.');
    }

    if (this.refreshPromise) {
      return this.refreshPromise;
    }

    this.refreshPromise = (async () => {
      try {
        const res = await fetch('https://oauth2.googleapis.com/token', {
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: new URLSearchParams({
            client_id: this.config.client_id,
            client_secret: this.config.client_secret,
            refresh_token: this.tokens!.refresh_token!,
            grant_type: 'refresh_token',
          }),
        });

        if (!res.ok) {
          const errText = await res.text();
          throw new Error(`Error refrescando token de Google (${res.status}): ${errText}`);
        }

        const data = (await res.json()) as any;
        const expiryDate = Date.now() + (Number(data.expires_in) || 3600) * 1000;

        this.tokens = {
          ...this.tokens!,
          access_token: data.access_token,
          refresh_token: data.refresh_token || this.tokens!.refresh_token,
          expiry_date: expiryDate,
        };

        this.saveTokens();
        return this.tokens.access_token;
      } finally {
        this.refreshPromise = null;
      }
    })();

    return this.refreshPromise;
  }

  /**
   * Retorna el estado actual de la integración.
   */
  public getStatus(): GoogleConnectionStatus {
    this.loadTokens();
    const isConnected = Boolean(this.tokens && (this.tokens.refresh_token || this.tokens.access_token));

    return {
      connected: isConnected,
      email: this.userProfile?.email || null,
      name: this.userProfile?.name || null,
      picture: this.userProfile?.picture || null,
      scopes: this.config.scopes,
      tokenExpiresAt: this.tokens?.expiry_date ? new Date(this.tokens.expiry_date).toISOString() : null,
      authUrl: this.getAuthUrl(),
      message: isConnected
        ? `Conectado a Google Workspace como ${this.userProfile?.email || 'cuenta autorizada'}.`
        : 'Google Workspace no conectado.',
    };
  }

  /**
   * Desconecta la cuenta de Google y elimina los tokens.
   */
  public disconnect(): void {
    if (this.tokens?.access_token) {
      fetch(`https://oauth2.googleapis.com/revoke?token=${encodeURIComponent(this.tokens.access_token)}`, {
        method: 'POST',
      }).catch(() => {});
    }
    this.tokens = null;
    this.userProfile = null;
    if (existsSync(TOKENS_PATH)) {
      try {
        writeFileSync(TOKENS_PATH, JSON.stringify({}), 'utf8');
      } catch {}
    }
  }

  // =========================================================================
  // GMAIL
  // =========================================================================

  public async searchEmails(query = '', maxResults = 10): Promise<GmailMessageSummary[]> {
    const token = await this.getAccessToken();
    const qParams = new URLSearchParams({
      maxResults: String(maxResults),
      q: query,
    });

    const res = await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages?${qParams.toString()}`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      throw new Error(`Gmail API error (${res.status}): ${await res.text()}`);
    }

    const data = (await res.json()) as any;
    const msgList: any[] = data.messages || [];

    const summaries: GmailMessageSummary[] = [];
    for (const m of msgList.slice(0, maxResults)) {
      try {
        const detailRes = await fetch(
          `https://gmail.googleapis.com/gmail/v1/users/me/messages/${m.id}?format=metadata&metadataHeaders=From&metadataHeaders=To&metadataHeaders=Subject&metadataHeaders=Date`,
          { headers: { Authorization: `Bearer ${token}` } },
        );
        if (detailRes.ok) {
          const detail = (await detailRes.json()) as any;
          const headers = detail.payload?.headers || [];
          const getH = (name: string) => headers.find((h: any) => h.name.toLowerCase() === name.toLowerCase())?.value || '';

          summaries.push({
            id: detail.id,
            threadId: detail.threadId,
            from: getH('From'),
            to: getH('To'),
            subject: getH('Subject') || '(Sin Asunto)',
            date: getH('Date'),
            snippet: detail.snippet || '',
          });
        }
      } catch {}
    }

    return summaries;
  }

  public async getEmail(id: string): Promise<GmailFullMessage> {
    const token = await this.getAccessToken();
    const res = await fetch(`https://gmail.googleapis.com/gmail/v1/users/me/messages/${id}?format=full`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      throw new Error(`Gmail API error (${res.status}): ${await res.text()}`);
    }

    const detail = (await res.json()) as any;
    const headers = detail.payload?.headers || [];
    const getH = (name: string) => headers.find((h: any) => h.name.toLowerCase() === name.toLowerCase())?.value || '';

    // Extraer cuerpo de texto
    let bodyText = '';
    const extractText = (part: any) => {
      if (part.mimeType === 'text/plain' && part.body?.data) {
        bodyText += Buffer.from(part.body.data, 'base64').toString('utf8');
      }
      if (part.parts) {
        for (const p of part.parts) extractText(p);
      }
    };
    if (detail.payload) extractText(detail.payload);
    if (!bodyText && detail.snippet) bodyText = detail.snippet;

    return {
      id: detail.id,
      threadId: detail.threadId,
      from: getH('From'),
      to: getH('To'),
      subject: getH('Subject') || '(Sin Asunto)',
      date: getH('Date'),
      snippet: detail.snippet || '',
      bodyText,
      labels: detail.labelIds || [],
    };
  }

  public async sendEmail(options: {
    to: string;
    subject: string;
    body: string;
    isHtml?: boolean;
    threadId?: string;
  }): Promise<{ id: string; threadId: string }> {
    const token = await this.getAccessToken();
    const from = this.userProfile?.email || 'me';

    const mimeLines = [
      `From: ${from}`,
      `To: ${options.to}`,
      `Subject: =?utf-8?B?${Buffer.from(options.subject).toString('base64')}?=`,
      'MIME-Version: 1.0',
      `Content-Type: ${options.isHtml ? 'text/html' : 'text/plain'}; charset=utf-8`,
      '',
      options.body,
    ];

    const rawMessage = Buffer.from(mimeLines.join('\r\n'))
      .toString('base64')
      .replace(/\+/g, '-')
      .replace(/\//g, '_')
      .replace(/=+$/, '');

    const res = await fetch('https://gmail.googleapis.com/gmail/v1/users/me/messages/send', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        raw: rawMessage,
        threadId: options.threadId || undefined,
      }),
    });

    if (!res.ok) {
      throw new Error(`Gmail Send error (${res.status}): ${await res.text()}`);
    }

    return (await res.json()) as any;
  }

  // =========================================================================
  // GOOGLE CALENDAR
  // =========================================================================

  public async listEvents(options: { timeMin?: string; timeMax?: string; maxResults?: number } = {}): Promise<CalendarEventItem[]> {
    const token = await this.getAccessToken();
    const now = new Date();
    const timeMin = options.timeMin || new Date(now.getFullYear(), now.getMonth(), now.getDate()).toISOString();

    const q = new URLSearchParams({
      calendarId: 'primary',
      timeMin,
      singleEvents: 'true',
      orderBy: 'startTime',
      maxResults: String(options.maxResults || 15),
    });
    if (options.timeMax) q.set('timeMax', options.timeMax);

    const res = await fetch(`https://www.googleapis.com/calendar/v3/calendars/primary/events?${q.toString()}`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      throw new Error(`Calendar API error (${res.status}): ${await res.text()}`);
    }

    const data = (await res.json()) as any;
    const items: any[] = data.items || [];

    return items.map((ev) => ({
      id: ev.id,
      summary: ev.summary || '(Sin título)',
      description: ev.description,
      start: ev.start?.dateTime || ev.start?.date || '',
      end: ev.end?.dateTime || ev.end?.date || '',
      location: ev.location,
      meetLink: ev.hangoutLink || ev.conferenceData?.entryPoints?.find((e: any) => e.entryPointType === 'video')?.uri,
      htmlLink: ev.htmlLink,
      attendees: (ev.attendees || []).map((a: any) => a.email),
      status: ev.status,
    }));
  }

  public async createEvent(options: {
    summary: string;
    description?: string;
    start: string; // ISO 8601 o fecha
    end: string;
    attendees?: string[];
    addMeetLink?: boolean;
    location?: string;
  }): Promise<CalendarEventItem> {
    const token = await this.getAccessToken();

    const isFullDay = options.start.length === 10;
    const body: any = {
      summary: options.summary,
      description: options.description,
      location: options.location,
      start: isFullDay ? { date: options.start } : { dateTime: options.start },
      end: isFullDay ? { date: options.end } : { dateTime: options.end },
      attendees: (options.attendees || []).map((email) => ({ email })),
    };

    if (options.addMeetLink !== false) {
      body.conferenceData = {
        createRequest: {
          requestId: `meet_${Date.now()}`,
          conferenceSolutionKey: { type: 'hangoutsMeet' },
        },
      };
    }

    const res = await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events?conferenceDataVersion=1', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(body),
    });

    if (!res.ok) {
      throw new Error(`Calendar Create error (${res.status}): ${await res.text()}`);
    }

    const ev = (await res.json()) as any;
    return {
      id: ev.id,
      summary: ev.summary,
      description: ev.description,
      start: ev.start?.dateTime || ev.start?.date || '',
      end: ev.end?.dateTime || ev.end?.date || '',
      location: ev.location,
      meetLink: ev.hangoutLink || ev.conferenceData?.entryPoints?.find((e: any) => e.entryPointType === 'video')?.uri,
      htmlLink: ev.htmlLink,
      attendees: (ev.attendees || []).map((a: any) => a.email),
      status: ev.status,
    };
  }

  // =========================================================================
  // GOOGLE DRIVE
  // =========================================================================

  public async searchFiles(query?: string, maxResults = 15): Promise<DriveFileItem[]> {
    const token = await this.getAccessToken();
    const qParts: string[] = ['trashed = false'];
    if (query) {
      qParts.push(`name contains '${query.replace(/'/g, "\\'")}'`);
    }

    const q = new URLSearchParams({
      pageSize: String(maxResults),
      q: qParts.join(' and '),
      fields: 'files(id, name, mimeType, size, modifiedTime, webViewLink, iconLink, owners)',
      supportsAllDrives: 'true',
      includeItemsFromAllDrives: 'true',
    });

    const res = await fetch(`https://www.googleapis.com/drive/v3/files?${q.toString()}`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      throw new Error(`Drive API error (${res.status}): ${await res.text()}`);
    }

    const data = (await res.json()) as any;
    const files: any[] = data.files || [];

    return files.map((f) => ({
      id: f.id,
      name: f.name,
      mimeType: f.mimeType,
      size: f.size ? Number(f.size) : undefined,
      modifiedTime: f.modifiedTime,
      webViewLink: f.webViewLink,
      iconLink: f.iconLink,
      owners: (f.owners || []).map((o: any) => o.emailAddress),
    }));
  }

  public async uploadFile(options: {
    name: string;
    mimeType: string;
    content: string | Buffer;
    folderId?: string;
  }): Promise<DriveFileItem> {
    const token = await this.getAccessToken();

    const metadata: any = {
      name: options.name,
      mimeType: options.mimeType,
    };
    if (options.folderId) {
      metadata.parents = [options.folderId];
    }

    const boundary = `wappy_boundary_${Date.now()}`;
    const delimiter = `\r\n--${boundary}\r\n`;
    const closeDelimiter = `\r\n--${boundary}--`;

    const bodyParts = [
      delimiter,
      'Content-Type: application/json; charset=UTF-8\r\n\r\n',
      JSON.stringify(metadata),
      delimiter,
      `Content-Type: ${options.mimeType}\r\n\r\n`,
      typeof options.content === 'string' ? options.content : options.content.toString('utf8'),
      closeDelimiter,
    ];

    const multipartBody = bodyParts.join('');

    const res = await fetch('https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id,name,mimeType,webViewLink', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': `multipart/related; boundary=${boundary}`,
      },
      body: multipartBody,
    });

    if (!res.ok) {
      throw new Error(`Drive Upload error (${res.status}): ${await res.text()}`);
    }

    return (await res.json()) as any;
  }

  // =========================================================================
  // GOOGLE SHEETS
  // =========================================================================

  public async readRange(spreadsheetId: string, range: string): Promise<SheetValuesResult> {
    const token = await this.getAccessToken();
    const res = await fetch(`https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      throw new Error(`Sheets API error (${res.status}): ${await res.text()}`);
    }

    const data = (await res.json()) as any;
    return {
      spreadsheetId,
      range: data.range || range,
      values: data.values || [],
    };
  }

  public async appendRows(spreadsheetId: string, range: string, rows: any[][]): Promise<{ updatedRows: number }> {
    const token = await this.getAccessToken();
    const url = `https://sheets.googleapis.com/v4/spreadsheets/${spreadsheetId}/values/${encodeURIComponent(range)}:append?valueInputOption=USER_ENTERED`;

    const res = await fetch(url, {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ values: rows }),
    });

    if (!res.ok) {
      throw new Error(`Sheets Append error (${res.status}): ${await res.text()}`);
    }

    const data = (await res.json()) as any;
    return { updatedRows: data.updates?.updatedRows || rows.length };
  }

  public async createSpreadsheet(title: string): Promise<{ spreadsheetId: string; spreadsheetUrl: string }> {
    const token = await this.getAccessToken();
    const res = await fetch('https://sheets.googleapis.com/v4/spreadsheets', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        properties: { title },
      }),
    });

    if (!res.ok) {
      throw new Error(`Sheets Create error (${res.status}): ${await res.text()}`);
    }

    const data = (await res.json()) as any;
    return {
      spreadsheetId: data.spreadsheetId,
      spreadsheetUrl: data.spreadsheetUrl,
    };
  }

  // =========================================================================
  // GOOGLE DOCS
  // =========================================================================

  public async readDoc(documentId: string): Promise<GoogleDocContent> {
    const token = await this.getAccessToken();
    const res = await fetch(`https://docs.googleapis.com/v1/documents/${documentId}`, {
      headers: { Authorization: `Bearer ${token}` },
    });

    if (!res.ok) {
      throw new Error(`Docs API error (${res.status}): ${await res.text()}`);
    }

    const data = (await res.json()) as any;
    let fullText = '';
    const bodyContent = data.body?.content || [];
    for (const elem of bodyContent) {
      if (elem.paragraph?.elements) {
        for (const pe of elem.paragraph.elements) {
          if (pe.textRun?.content) fullText += pe.textRun.content;
        }
      }
    }

    return {
      documentId,
      title: data.title || 'Documento',
      text: fullText,
    };
  }

  public async createDoc(title: string, text?: string): Promise<{ documentId: string; url: string }> {
    const token = await this.getAccessToken();
    const res = await fetch('https://docs.googleapis.com/v1/documents', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ title }),
    });

    if (!res.ok) {
      throw new Error(`Docs Create error (${res.status}): ${await res.text()}`);
    }

    const doc = (await res.json()) as any;
    const documentId = doc.documentId;

    if (text) {
      await fetch(`https://docs.googleapis.com/v1/documents/${documentId}:batchUpdate`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          requests: [
            {
              insertText: {
                location: { index: 1 },
                text,
              },
            },
          ],
        }),
      }).catch(() => {});
    }

    return {
      documentId,
      url: `https://docs.google.com/document/d/${documentId}/edit`,
    };
  }
}

let sharedWorkspaceClient: GoogleWorkspaceClient | null = null;

export function getSharedGoogleWorkspaceClient(): GoogleWorkspaceClient {
  if (!sharedWorkspaceClient) {
    sharedWorkspaceClient = new GoogleWorkspaceClient();
  }
  return sharedWorkspaceClient;
}
