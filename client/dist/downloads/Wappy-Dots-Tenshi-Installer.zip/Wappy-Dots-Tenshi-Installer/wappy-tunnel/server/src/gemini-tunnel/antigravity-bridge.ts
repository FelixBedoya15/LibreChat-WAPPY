/**
 * antigravity-bridge.ts
 *
 * Puente bidireccional entre Tenshi (Wappy Dots / Wappy Bot) y Google Antigravity.
 * Permite que Tenshi actúe como Orquestador de Agentes:
 *   1. Listar proyectos locales (/Users/venta/Documents/GitHub y workspaces de Antigravity).
 *   2. Listar y buscar conversaciones/chats reales de Antigravity (~/.gemini/antigravity/conversation_summaries.db).
 *   3. Leer el contenido y artefactos de cualquier chat de Antigravity (~/.gemini/antigravity/brain/<id>).
 *   4. Abrir un proyecto o chat en Antigravity (nuevo o existente) y ejecutar tareas mediante `agy` CLI.
 *   5. Generar documentos reales (HTML, PDF, Word .docx, Excel .xlsx, Páginas Web) y entregarlos
 *      directamente en el chat de Tenshi (accesibles tanto en el Notch del Mac como desde el celular).
 */

import { execFile, spawn } from 'node:child_process';
import {
  copyFileSync,
  existsSync,
  mkdirSync,
  readdirSync,
  readFileSync,
  statSync,
  writeFileSync,
} from 'node:fs';
import { networkInterfaces, homedir } from 'node:os';
import { basename, extname, join, resolve } from 'node:path';
import { promisify } from 'node:util';
import * as XLSX from 'xlsx';
import { SIIGO_OPENAI_TOOLS, executeSiigoToolCall } from '../siigo/siigo-tools';
import { GOOGLE_WORKSPACE_OPENAI_TOOLS, executeGoogleToolCall } from '../google/google-tools';

const execFileAsync = promisify(execFile);

const HOME = homedir();
const WAPPY_DIR = join(HOME, '.wappy');
const SHARED_FILES_DIR = join(WAPPY_DIR, 'shared-files');
const SHARED_CHAT_PATH = join(WAPPY_DIR, 'tenshi-shared-chat.json');
const AGY_CONFIG_PATH = join(WAPPY_DIR, 'antigravity-config.json');

const AGY_BRAIN_DIR = join(HOME, '.gemini', 'antigravity', 'brain');
const AGY_DB_PATH = join(HOME, '.gemini', 'antigravity', 'conversation_summaries.db');
const AGY_HOOKS_PATH = join(HOME, '.gemini', 'config', 'hooks.json');

function ensureDirs() {
  mkdirSync(WAPPY_DIR, { recursive: true });
  mkdirSync(SHARED_FILES_DIR, { recursive: true });
}
ensureDirs();

export interface AntigravityBridgeConfig {
  enabled: boolean;
  projectsRoot: string;
  autoShareFilesToChat: boolean;
  allowCreateChats: boolean;
  allowResumeChats: boolean;
  apiSelection?: string;
  synthesisModel?: string;
  ideModel?: 'flash_lite' | 'flash' | 'flash_high' | 'pro';
  autoRotateFallback?: boolean;
  updatedAt?: string;
}

export interface AgentRouteEntry {
  id: string;
  name: string;
  category: 'agent' | 'connection';
  description: string;
  apiProvider: 'google_gemini';
  apiSelection: string; // 'auto_pool' | 'auto_voice_pool' | 'text_key_1' .. 'text_key_6' | 'voice_key_1' .. 'voice_key_3'
  model: string;        // 'gemini-3.8-flash' | 'gemini-3.5-flash-lite' | 'gemini-3.6-flash' | 'gemini-3.1-flash-live-preview' | 'gemini-3.8-live'
  ideModel?: 'flash_lite' | 'flash' | 'flash_high' | 'pro';
  autoRotateFallback: boolean;
  rotationOffset?: number;
  updatedAt?: string;
}

export interface ActiveApiKeyInfo {
  slotId: string;       // e.g. 'text_key_1', 'voice_key_1'
  label: string;        // e.g. 'Clave Gemini Texto #1 (AQ.A...qDfw)'
  pool: 'text' | 'voice';
  maskedKey: string;
  active: boolean;
}

const AGENT_ROUTING_PATH = join(WAPPY_DIR, 'agent-routing.json');
const AGY_STATE_PBTXT_PATH = join(HOME, '.gemini', 'antigravity', 'antigravity_state.pbtxt');

const IDE_MODEL_TO_PLACEHOLDER: Record<string, { placeholder: string; cliTier: 'flash_lite' | 'flash' | 'pro'; label: string }> = {
  flash_lite: {
    placeholder: 'MODEL_PLACEHOLDER_M320',
    cliTier: 'flash_lite',
    label: 'Gemini 3.8 Flash (Low / Ultra Rápido)',
  },
  flash: {
    placeholder: 'MODEL_PLACEHOLDER_M319',
    cliTier: 'flash',
    label: 'Gemini 3.8 Flash (Medium / Recomendado)',
  },
  flash_high: {
    placeholder: 'MODEL_PLACEHOLDER_M318',
    cliTier: 'flash',
    label: 'Gemini 3.8 Flash (High / Razonamiento)',
  },
  pro: {
    placeholder: 'MODEL_PLACEHOLDER_M418',
    cliTier: 'pro',
    label: 'Gemini 4 Argon / Pro (Complejo)',
  },
};

export function syncAntigravityIdeDefaultGeminiModel(ideModel: string = 'flash') {
  try {
    const entry = IDE_MODEL_TO_PLACEHOLDER[ideModel] || IDE_MODEL_TO_PLACEHOLDER.flash;
    if (existsSync(AGY_STATE_PBTXT_PATH)) {
      const raw = readFileSync(AGY_STATE_PBTXT_PATH, 'utf8');
      if (raw.includes('last_selected_agent_model:')) {
        const updated = raw.replace(
          /last_selected_agent_model:\s*[A-Z0-9_]+/,
          `last_selected_agent_model: ${entry.placeholder}`,
        );
        if (updated !== raw) {
          writeFileSync(AGY_STATE_PBTXT_PATH, updated, 'utf8');
        }
      }
    }
  } catch {}
}

const DEFAULT_AGENT_ROUTES: Record<string, AgentRouteEntry> = {
  antigravity: {
    id: 'antigravity',
    name: 'Agente Antigravity (IDE + Proyectos)',
    category: 'agent',
    description: 'Orquestador principal de código, proyectos y chats en Antigravity.app',
    apiProvider: 'google_gemini',
    apiSelection: 'auto_pool',
    model: 'gemini-3.5-flash-lite',
    ideModel: 'flash',
    autoRotateFallback: true,
    rotationOffset: 0,
  },
  tenshi_chat: {
    id: 'tenshi_chat',
    name: 'Tenshi Chat (Notch & Portal Móvil)',
    category: 'agent',
    description: 'Cerebro conversacional de texto y herramientas en el Notch del Mac y celular',
    apiProvider: 'google_gemini',
    apiSelection: 'auto_pool',
    model: 'gemini-3.8-flash',
    autoRotateFallback: true,
    rotationOffset: 0,
  },
  tenshi_voice: {
    id: 'tenshi_voice',
    name: 'Tenshi Voz («OK Tenshi» Gemini Live)',
    category: 'agent',
    description: 'Voz bidireccional en vivo de baja latencia (24 kHz)',
    apiProvider: 'google_gemini',
    apiSelection: 'auto_voice_pool',
    model: 'gemini-3.1-flash-live-preview',
    autoRotateFallback: true,
    rotationOffset: 0,
  },
  document_generator: {
    id: 'document_generator',
    name: 'Generador de Informes (PDF, Word, Excel, HTML)',
    category: 'connection',
    description: 'Síntesis y maquetación de documentos compartidos al chat y celular',
    apiProvider: 'google_gemini',
    apiSelection: 'auto_pool',
    model: 'gemini-3.5-flash-lite',
    autoRotateFallback: true,
    rotationOffset: 0,
  },
  gemini_cli: {
    id: 'gemini_cli',
    name: 'Agente Gemini CLI & Hooks',
    category: 'agent',
    description: 'Sesiones de terminal y agente local de Google Gemini CLI',
    apiProvider: 'google_gemini',
    apiSelection: 'auto_pool',
    model: 'gemini-3.8-flash',
    autoRotateFallback: true,
    rotationOffset: 0,
  },
  integrations_hub: {
    id: 'integrations_hub',
    name: 'Conexiones & Webhooks (GitHub, n8n, Vercel, Notion)',
    category: 'connection',
    description: 'Procesamiento inteligente de integraciones y automatizaciones conectadas',
    apiProvider: 'google_gemini',
    apiSelection: 'auto_pool',
    model: 'gemini-3.5-flash-lite',
    autoRotateFallback: true,
    rotationOffset: 0,
  },
  agent_team: {
    id: 'agent_team',
    name: 'Team de Agentes Wappy Dots (OpenClaw)',
    category: 'agent',
    description: 'Orquestación multi-agente en paralelo (Investigador, Antigravity, Siigo/Workspace, Redactor)',
    apiProvider: 'google_gemini',
    apiSelection: 'auto_pool',
    model: 'gemini-3.5-flash-lite',
    autoRotateFallback: true,
    rotationOffset: 0,
  },
};

export function loadAgentRoutingConfig(): Record<string, AgentRouteEntry> {
  const result: Record<string, AgentRouteEntry> = JSON.parse(JSON.stringify(DEFAULT_AGENT_ROUTES));
  try {
    if (existsSync(AGENT_ROUTING_PATH)) {
      const parsed = JSON.parse(readFileSync(AGENT_ROUTING_PATH, 'utf8'));
      const routes = parsed?.routes || parsed || {};
      for (const [id, entry] of Object.entries(routes)) {
        if (result[id] && entry && typeof entry === 'object') {
          result[id] = {
            ...result[id],
            ...(entry as Partial<AgentRouteEntry>),
            id,
            apiProvider: 'google_gemini',
          };
        }
      }
    }
  } catch {}
  return result;
}

export function saveAgentRoutingConfig(
  updates: Record<string, Partial<AgentRouteEntry>> | { agentId: string; config: Partial<AgentRouteEntry> },
): Record<string, AgentRouteEntry> {
  const current = loadAgentRoutingConfig();
  if ('agentId' in updates && typeof updates.agentId === 'string') {
    const id = updates.agentId;
    if (current[id]) {
      current[id] = {
        ...current[id],
        ...updates.config,
        id,
        apiProvider: 'google_gemini',
        updatedAt: new Date().toISOString(),
      };
    }
  } else {
    for (const [id, partial] of Object.entries(updates)) {
      if (current[id] && partial && typeof partial === 'object') {
        current[id] = {
          ...current[id],
          ...(partial as Partial<AgentRouteEntry>),
          id,
          apiProvider: 'google_gemini',
          updatedAt: new Date().toISOString(),
        };
      }
    }
  }
  ensureDirs();
  writeFileSync(AGENT_ROUTING_PATH, JSON.stringify({ routes: current, updatedAt: new Date().toISOString() }, null, 2), 'utf8');
  if (current.antigravity?.ideModel) {
    syncAntigravityIdeDefaultGeminiModel(current.antigravity.ideModel);
  }
  return current;
}

export function rotateAgentKeyNow(agentId: string): {
  agentId: string;
  nextSelection: string;
  nextLabel: string;
  route: AgentRouteEntry;
} {
  const routes = loadAgentRoutingConfig();
  const route = routes[agentId] || routes.antigravity;
  const activeApis = getActiveSystemApisSync();
  const poolKeys =
    route.id === 'tenshi_voice'
      ? activeApis.keys.filter((k) => k.pool === 'voice')
      : activeApis.keys.filter((k) => k.pool === 'text');

  const options = [
    route.id === 'tenshi_voice' ? 'auto_voice_pool' : 'auto_pool',
    ...poolKeys.map((k) => k.slotId),
  ];
  const currentIdx = options.indexOf(route.apiSelection);
  const nextSelection = options[(currentIdx + 1) % options.length] || options[0];
  const nextOffset = ((route.rotationOffset || 0) + 1) % Math.max(poolKeys.length, 1);

  const updatedRoutes = saveAgentRoutingConfig({
    agentId: route.id,
    config: {
      apiSelection: nextSelection,
      rotationOffset: nextOffset,
    },
  });

  const matchedKey = activeApis.keys.find((k) => k.slotId === nextSelection);
  const nextLabel = matchedKey
    ? matchedKey.label
    : nextSelection === 'auto_voice_pool'
      ? `Rotación Automática Pool Live (${poolKeys.length} claves activas)`
      : `Rotación Automática Pool Gemini (${poolKeys.length} claves activas)`;

  return {
    agentId: route.id,
    nextSelection,
    nextLabel,
    route: updatedRoutes[route.id],
  };
}

function maskKey(k: string): string {
  const clean = String(k || '').trim();
  if (clean.length <= 10) return clean ? '***' : '';
  return `${clean.slice(0, 6)}...${clean.slice(-4)}`;
}

export function getActiveSystemApisSync() {
  const tunnelCfgPath =
    process.env.GEMINI_TUNNEL_CONFIG_PATH || join(HOME, '.wappy', 'gemini-tunnel.json');
  let rawTextKeys: string[] = [];
  let rawVoiceKeys: string[] = [];
  let primaryTextModel = 'gemini-3.8-flash';
  let primaryLiveModel = 'gemini-3.1-flash-live-preview';

  if (existsSync(tunnelCfgPath)) {
    try {
      const parsed = JSON.parse(readFileSync(tunnelCfgPath, 'utf8'));
      if (Array.isArray(parsed.textKeys)) rawTextKeys = parsed.textKeys.map((k: any) => String(k || '').trim()).filter(Boolean);
      if (Array.isArray(parsed.voiceKeys)) rawVoiceKeys = parsed.voiceKeys.map((k: any) => String(k || '').trim()).filter(Boolean);
      if (parsed.textModel) primaryTextModel = String(parsed.textModel);
      if (parsed.liveModel) primaryLiveModel = String(parsed.liveModel);
    } catch {}
  }

  if (rawTextKeys.length === 0) {
    for (let i = 1; i <= 6; i++) {
      const k = (process.env[`GEMINI_TEXT_KEY_${i}`] || process.env[`GEMINI_POOL_KEY_${i}`])?.trim();
      if (k && !rawTextKeys.includes(k)) rawTextKeys.push(k);
    }
  }
  if (rawVoiceKeys.length === 0) {
    for (let i = 1; i <= 3; i++) {
      const k = process.env[`GEMINI_VOICE_KEY_${i}`]?.trim();
      if (k && !rawVoiceKeys.includes(k)) rawVoiceKeys.push(k);
    }
  }

  const keys: ActiveApiKeyInfo[] = [];
  rawTextKeys.forEach((k, idx) => {
    keys.push({
      slotId: `text_key_${idx + 1}`,
      label: `Clave Gemini Texto #${idx + 1} (${maskKey(k)})`,
      pool: 'text',
      maskedKey: maskKey(k),
      active: true,
    });
  });
  rawVoiceKeys.forEach((k, idx) => {
    keys.push({
      slotId: `voice_key_${idx + 1}`,
      label: `Clave Gemini Live/Voz #${idx + 1} (${maskKey(k)})`,
      pool: 'voice',
      maskedKey: maskKey(k),
      active: true,
    });
  });

  const apiOptions = [
    {
      id: 'auto_pool',
      label: `Rotación Automática Pool Gemini Texto (${rawTextKeys.length} claves activas)`,
      pool: 'text',
    },
    {
      id: 'auto_voice_pool',
      label: `Rotación Automática Pool Gemini Live/Voz (${rawVoiceKeys.length} claves activas)`,
      pool: 'voice',
    },
    ...keys.map((k) => ({
      id: k.slotId,
      label: k.label,
      pool: k.pool,
    })),
  ];

  const textModels = [
    { id: 'gemini-3.5-flash-lite', label: 'Gemini 3.5 Flash Lite (Ultra Rápido · Ideal Agentes/Informes)' },
    { id: 'gemini-3.8-flash', label: 'Gemini 3.8 Flash (Balanceado · Principal Wappy)' },
    { id: 'gemini-3.6-flash', label: 'Gemini 3.6 Flash (Estable · Respaldo)' },
  ];

  const voiceModels = [
    { id: 'gemini-3.1-flash-live-preview', label: 'Gemini 3.1 Flash Live Preview (Voz Nativa 24kHz)' },
    { id: 'gemini-3.8-live', label: 'Gemini 3.8 Live (Voz Bidireccional Respaldo)' },
  ];

  const antigravityIdeModels = Object.entries(IDE_MODEL_TO_PLACEHOLDER).map(([id, info]) => ({
    id,
    label: info.label,
    placeholder: info.placeholder,
    cliTier: info.cliTier,
  }));

  return {
    activeProvider: 'google_gemini',
    activeProviderLabel: 'Google Gemini AI (Wappy Rotation Tunnel Activo)',
    inactiveProvidersIgnored: ['Claude Opus 5.5 (Desactivado por defecto — Sistema en modo Gemini)'],
    textKeysCount: rawTextKeys.length,
    voiceKeysCount: rawVoiceKeys.length,
    primaryTextModel,
    primaryLiveModel,
    keys,
    rawTextKeys,
    rawVoiceKeys,
    apiOptions,
    textModels,
    voiceModels,
    antigravityIdeModels,
    routes: loadAgentRoutingConfig(),
  };
}

// Sincronizar al arranque para que Antigravity.app nunca quede en Claude Opus 5.5 por defecto
syncAntigravityIdeDefaultGeminiModel(loadAgentRoutingConfig().antigravity?.ideModel || 'flash');

export interface SharedFileItem {
  id: string;
  fileName: string;
  title: string;
  format: 'html' | 'pdf' | 'docx' | 'xlsx' | 'other';
  filePath: string;
  sizeBytes: number;
  localUrl: string;
  lanUrl: string;
  createdAt: string;
  project?: string;
  conversationId?: string;
}

export interface SharedChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  content: string;
  createdAt: string;
  source?: 'notch-chat' | 'notch-voice' | 'antigravity' | 'mobile';
  files?: SharedFileItem[];
  project?: string;
  conversationId?: string;
}

export function loadAntigravityConfig(): AntigravityBridgeConfig {
  const agyRoute = loadAgentRoutingConfig().antigravity;
  try {
    if (existsSync(AGY_CONFIG_PATH)) {
      const raw = JSON.parse(readFileSync(AGY_CONFIG_PATH, 'utf8'));
      return {
        enabled: raw.enabled ?? true,
        projectsRoot: raw.projectsRoot || join(HOME, 'Documents', 'GitHub'),
        autoShareFilesToChat: raw.autoShareFilesToChat ?? true,
        allowCreateChats: raw.allowCreateChats ?? true,
        allowResumeChats: raw.allowResumeChats ?? true,
        apiSelection: agyRoute?.apiSelection || raw.apiSelection || 'auto_pool',
        synthesisModel: agyRoute?.model || raw.synthesisModel || 'gemini-3.5-flash-lite',
        ideModel: agyRoute?.ideModel || raw.ideModel || 'flash',
        autoRotateFallback: agyRoute?.autoRotateFallback ?? raw.autoRotateFallback ?? true,
        updatedAt: raw.updatedAt,
      };
    }
  } catch {}
  return {
    enabled: true,
    projectsRoot: join(HOME, 'Documents', 'GitHub'),
    autoShareFilesToChat: true,
    allowCreateChats: true,
    allowResumeChats: true,
    apiSelection: agyRoute?.apiSelection || 'auto_pool',
    synthesisModel: agyRoute?.model || 'gemini-3.5-flash-lite',
    ideModel: agyRoute?.ideModel || 'flash',
    autoRotateFallback: agyRoute?.autoRotateFallback ?? true,
  };
}

export function saveAntigravityConfig(partial: Partial<AntigravityBridgeConfig>): AntigravityBridgeConfig {
  const current = loadAntigravityConfig();
  const next: AntigravityBridgeConfig = {
    ...current,
    ...partial,
    updatedAt: new Date().toISOString(),
  };
  ensureDirs();
  writeFileSync(AGY_CONFIG_PATH, JSON.stringify(next, null, 2), 'utf8');

  if (
    partial.apiSelection !== undefined ||
    partial.synthesisModel !== undefined ||
    partial.ideModel !== undefined ||
    partial.autoRotateFallback !== undefined
  ) {
    saveAgentRoutingConfig({
      agentId: 'antigravity',
      config: {
        ...(partial.apiSelection !== undefined ? { apiSelection: partial.apiSelection } : {}),
        ...(partial.synthesisModel !== undefined ? { model: partial.synthesisModel } : {}),
        ...(partial.ideModel !== undefined ? { ideModel: partial.ideModel } : {}),
        ...(partial.autoRotateFallback !== undefined ? { autoRotateFallback: partial.autoRotateFallback } : {}),
      },
    });
  }

  return loadAntigravityConfig();
}

export function getLanIp(): string {
  try {
    const nets = networkInterfaces();
    for (const name of Object.keys(nets)) {
      for (const net of nets[name] || []) {
        if (net.family === 'IPv4' && !net.internal) {
          return net.address;
        }
      }
    }
  } catch {}
  return '127.0.0.1';
}

export function findAgyBinary(): string | null {
  const candidates = [
    join(HOME, '.local', 'bin', 'agy'),
    '/opt/homebrew/bin/agy',
    '/usr/local/bin/agy',
    '/Applications/Antigravity.app/Contents/MacOS/Antigravity',
  ];
  for (const c of candidates) {
    if (existsSync(c)) return c;
  }
  return null;
}

export function findAntigravityApp(): string | null {
  const candidates = [
    '/Applications/Antigravity.app',
    '/Applications/Antigravity IDE.app',
  ];
  for (const c of candidates) {
    if (existsSync(c)) return c;
  }
  return null;
}

export function getAntigravityStatus() {
  const cfg = loadAntigravityConfig();
  const agyBin = findAgyBinary();
  const appPath = findAntigravityApp();
  const dbExists = existsSync(AGY_DB_PATH);
  const hooksInstalled = (() => {
    try {
      if (!existsSync(AGY_HOOKS_PATH)) return false;
      const content = readFileSync(AGY_HOOKS_PATH, 'utf8');
      return content.includes('nb-hook');
    } catch {
      return false;
    }
  })();

  const lanIp = getLanIp();
  const activeApis = getActiveSystemApisSync();
  return {
    connected: Boolean(agyBin || appPath || dbExists),
    enabled: cfg.enabled,
    agyBinary: agyBin,
    appPath,
    brainDatabaseReady: dbExists,
    hooksInstalled,
    config: cfg,
    activeApis,
    routes: activeApis.routes,
    mobilePortalUrl: `http://${lanIp}:3001/api/gemini-tunnel/mobile`,
    localPortalUrl: `http://127.0.0.1:3001/api/gemini-tunnel/mobile`,
  };
}

// ---------------------------------------------------------------------------
// Historial compartido (Mac Notch <-> Servidor <-> Celular)
// ---------------------------------------------------------------------------

export function loadSharedChat(): { messages: SharedChatMessage[]; files: SharedFileItem[] } {
  try {
    if (existsSync(SHARED_CHAT_PATH)) {
      const parsed = JSON.parse(readFileSync(SHARED_CHAT_PATH, 'utf8'));
      return {
        messages: Array.isArray(parsed.messages) ? parsed.messages : [],
        files: Array.isArray(parsed.files) ? parsed.files : [],
      };
    }
  } catch {}
  return { messages: [], files: [] };
}

export function appendSharedChatMessage(msg: Omit<SharedChatMessage, 'id' | 'createdAt'>): SharedChatMessage {
  ensureDirs();
  const store = loadSharedChat();
  const entry: SharedChatMessage = {
    id: `msg_${Date.now()}_${Math.random().toString(36).slice(2, 7)}`,
    createdAt: new Date().toISOString(),
    ...msg,
  };
  store.messages.push(entry);
  if (store.messages.length > 200) {
    store.messages = store.messages.slice(-200);
  }
  if (entry.files?.length) {
    for (const f of entry.files) {
      if (!store.files.some((existing) => existing.fileName === f.fileName)) {
        store.files.unshift(f);
      }
    }
    if (store.files.length > 100) {
      store.files = store.files.slice(0, 100);
    }
  }
  writeFileSync(SHARED_CHAT_PATH, JSON.stringify(store, null, 2), 'utf8');
  return entry;
}

export function registerSharedFile(params: {
  filePath: string;
  title?: string;
  project?: string;
  conversationId?: string;
}): SharedFileItem {
  ensureDirs();
  const ext = extname(params.filePath).toLowerCase().replace('.', '');
  const base = basename(params.filePath);
  const safeName = base.replace(/[^a-zA-Z0-9._-]/g, '_');
  const destPath = join(SHARED_FILES_DIR, safeName);
  if (resolve(params.filePath) !== resolve(destPath)) {
    copyFileSync(params.filePath, destPath);
  }
  const st = statSync(destPath);
  const lanIp = getLanIp();
  const format: SharedFileItem['format'] =
    ext === 'pdf'
      ? 'pdf'
      : ext === 'docx' || ext === 'doc'
        ? 'docx'
        : ext === 'xlsx' || ext === 'xls' || ext === 'csv'
          ? 'xlsx'
          : ext === 'html' || ext === 'htm'
            ? 'html'
            : 'other';

  const encoded = encodeURIComponent(safeName);
  const item: SharedFileItem = {
    id: `file_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
    fileName: safeName,
    title: params.title || safeName,
    format,
    filePath: destPath,
    sizeBytes: st.size,
    localUrl: `http://127.0.0.1:3001/api/gemini-tunnel/files/${encoded}`,
    lanUrl: `http://${lanIp}:3001/api/gemini-tunnel/files/${encoded}`,
    createdAt: new Date().toISOString(),
    project: params.project,
    conversationId: params.conversationId,
  };

  const store = loadSharedChat();
  store.files = [item, ...store.files.filter((f) => f.fileName !== item.fileName)].slice(0, 100);
  writeFileSync(SHARED_CHAT_PATH, JSON.stringify(store, null, 2), 'utf8');
  return item;
}

export function getSharedFilePath(fileName: string): string | null {
  const safe = basename(decodeURIComponent(fileName));
  const candidate = join(SHARED_FILES_DIR, safe);
  if (existsSync(candidate)) return candidate;
  return null;
}

// ---------------------------------------------------------------------------
// 1. Listar Proyectos de Antigravity / GitHub
// ---------------------------------------------------------------------------

export interface AntigravityProjectInfo {
  name: string;
  path: string;
  lastModified: string;
  isGitRepo: boolean;
}

export async function listAntigravityProjects(): Promise<AntigravityProjectInfo[]> {
  const cfg = loadAntigravityConfig();
  const root = cfg.projectsRoot;
  const results: AntigravityProjectInfo[] = [];
  const seenPaths = new Set<string>();

  if (existsSync(root)) {
    for (const entry of readdirSync(root, { withFileTypes: true })) {
      if (!entry.isDirectory() || entry.name.startsWith('.')) continue;
      const fullPath = join(root, entry.name);
      try {
        const st = statSync(fullPath);
        const isGit = existsSync(join(fullPath, '.git'));
        results.push({
          name: entry.name,
          path: fullPath,
          lastModified: st.mtime.toISOString(),
          isGitRepo: isGit,
        });
        seenPaths.add(fullPath);
      } catch {}
    }
  }

  // También agregar workspaces registrados en conversation_summaries.db
  if (existsSync(AGY_DB_PATH)) {
    try {
      const { stdout } = await execFileAsync('sqlite3', [
        '-json',
        AGY_DB_PATH,
        `SELECT DISTINCT workspace_uris FROM conversation_summaries WHERE workspace_uris != '' AND workspace_uris != '[]' LIMIT 50;`,
      ]);
      const rows = JSON.parse(stdout || '[]');
      for (const r of rows) {
        try {
          const uris: string[] = JSON.parse(r.workspace_uris || '[]');
          for (const u of uris) {
            if (u.startsWith('file://')) {
              const p = decodeURIComponent(u.replace('file://', ''));
              if (!seenPaths.has(p) && existsSync(p)) {
                const st = statSync(p);
                results.push({
                  name: basename(p),
                  path: p,
                  lastModified: st.mtime.toISOString(),
                  isGitRepo: existsSync(join(p, '.git')),
                });
                seenPaths.add(p);
              }
            }
          }
        } catch {}
      }
    } catch {}
  }

  return results.sort((a, b) => b.lastModified.localeCompare(a.lastModified));
}

// ---------------------------------------------------------------------------
// 2. Listar Conversaciones / Chats de Antigravity
// ---------------------------------------------------------------------------

export interface AntigravityChatSummary {
  conversationId: string;
  title: string;
  preview: string;
  project: string;
  workspacePath: string;
  projectId: string;
  stepCount: number;
  lastModifiedTime: string;
  status: string;
}

export async function listAntigravityChats(options?: {
  project?: string;
  query?: string;
  limit?: number;
}): Promise<AntigravityChatSummary[]> {
  if (!existsSync(AGY_DB_PATH)) return [];
  const limit = Math.min(Math.max(options?.limit || 20, 1), 50);

  try {
    const { stdout } = await execFileAsync('sqlite3', [
      '-json',
      AGY_DB_PATH,
      `SELECT conversation_id, title, substr(preview, 1, 240) AS preview, workspace_uris, project_id, step_count, last_modified_time, status
       FROM conversation_summaries
       WHERE parent_conversation_id = ''
       ORDER BY last_modified_time DESC
       LIMIT 100;`,
    ]);
    const rows = JSON.parse(stdout || '[]');
    let summaries: AntigravityChatSummary[] = rows.map((r: any) => {
      let workspacePath = '';
      try {
        const uris: string[] = JSON.parse(r.workspace_uris || '[]');
        if (uris[0]?.startsWith('file://')) {
          workspacePath = decodeURIComponent(uris[0].replace('file://', ''));
        }
      } catch {}
      return {
        conversationId: r.conversation_id,
        title: r.title || '(Sin título)',
        preview: r.preview || '',
        project: workspacePath ? basename(workspacePath) : 'General',
        workspacePath,
        projectId: r.project_id || '',
        stepCount: Number(r.step_count || 0),
        lastModifiedTime: r.last_modified_time || '',
        status: r.status || '',
      };
    });

    if (options?.project) {
      const pFilter = options.project.toLowerCase().trim();
      summaries = summaries.filter(
        (s) =>
          s.project.toLowerCase().includes(pFilter) ||
          s.workspacePath.toLowerCase().includes(pFilter),
      );
    }

    if (options?.query) {
      const qFilter = options.query.toLowerCase().trim();
      summaries = summaries.filter(
        (s) =>
          s.title.toLowerCase().includes(qFilter) ||
          s.preview.toLowerCase().includes(qFilter) ||
          s.project.toLowerCase().includes(qFilter),
      );
    }

    return summaries.slice(0, limit);
  } catch (err: any) {
    console.warn('[AntigravityBridge] Error leyendo conversation_summaries.db:', err?.message);
    return [];
  }
}

// ---------------------------------------------------------------------------
// 3. Leer el detalle y artefactos de un chat específico de Antigravity
// ---------------------------------------------------------------------------

export async function readAntigravityChat(conversationId: string): Promise<{
  conversationId: string;
  title?: string;
  project?: string;
  recentMessages: Array<{ role: string; text: string; createdAt?: string }>;
  artifacts: string[];
}> {
  const cleanId = basename(conversationId.trim());
  const convDir = join(AGY_BRAIN_DIR, cleanId);
  const transcriptPath = join(convDir, '.system_generated', 'logs', 'transcript.jsonl');

  const recentMessages: Array<{ role: string; text: string; createdAt?: string }> = [];
  const artifacts: string[] = [];

  if (existsSync(convDir)) {
    try {
      for (const entry of readdirSync(convDir, { withFileTypes: true })) {
        if (entry.isFile() && !entry.name.startsWith('.')) {
          artifacts.push(join(convDir, entry.name));
        }
      }
    } catch {}
  }

  if (existsSync(transcriptPath)) {
    try {
      const raw = readFileSync(transcriptPath, 'utf8');
      const lines = raw.split('\n').filter(Boolean);
      for (const line of lines.slice(-60)) {
        try {
          const step = JSON.parse(line);
          if (step.type === 'USER_INPUT' && step.content) {
            const cleaned = String(step.content)
              .replace(/<USER_REQUEST>|<\/USER_REQUEST>/g, '')
              .replace(/<ADDITIONAL_METADATA>[\s\S]*?<\/ADDITIONAL_METADATA>/g, '')
              .trim();
            if (cleaned) {
              recentMessages.push({
                role: 'user',
                text: cleaned.slice(0, 1500),
                createdAt: step.created_at,
              });
            }
          } else if (step.type === 'PLANNER_RESPONSE' && step.content) {
            const cleaned = String(step.content).trim();
            if (cleaned) {
              recentMessages.push({
                role: 'assistant',
                text: cleaned.slice(0, 2000),
                createdAt: step.created_at,
              });
            }
          }
        } catch {}
      }
    } catch {}
  }

  const allChats = await listAntigravityChats({ limit: 50 });
  const meta = allChats.find((c) => c.conversationId === cleanId);

  return {
    conversationId: cleanId,
    title: meta?.title,
    project: meta?.project,
    recentMessages: recentMessages.slice(-12),
    artifacts,
  };
}

// ---------------------------------------------------------------------------
// 4. Abrir proyecto o ventana de Antigravity en el Mac
// ---------------------------------------------------------------------------

const AGY_PROJECTS_DIR = join(HOME, '.gemini', 'config', 'projects');
const AGY_LANGUAGE_SERVER_BIN =
  '/Applications/Antigravity.app/Contents/Resources/bin/language_server';

function cleanupDefaultCliProject() {
  try {
    const cliProjFile = join(AGY_PROJECTS_DIR, 'default-cli-project.json');
    if (existsSync(cliProjFile)) {
      const { unlinkSync } = require('node:fs');
      unlinkSync(cliProjFile);
    }
    const cliCacheFile = join(HOME, '.gemini', 'antigravity-cli', 'cache', 'default_project_id.txt');
    if (existsSync(cliCacheFile)) {
      const { unlinkSync } = require('node:fs');
      unlinkSync(cliCacheFile);
    }
  } catch {}
}
cleanupDefaultCliProject();

export function resolveOrEnsureAntigravityProjectId(
  targetProjectPath: string,
  targetProjectName: string,
): string {
  cleanupDefaultCliProject();
  try {
    if (existsSync(AGY_PROJECTS_DIR)) {
      const files = readdirSync(AGY_PROJECTS_DIR).filter(
        (f) =>
          f.endsWith('.json') &&
          f !== 'default-cli-project.json' &&
          f !== 'outside-of-project.json',
      );
      const qName = targetProjectName.toLowerCase().trim();
      const qPath = targetProjectPath.toLowerCase().trim();

      for (const file of files) {
        try {
          const parsed = JSON.parse(readFileSync(join(AGY_PROJECTS_DIR, file), 'utf8'));
          const id = String(parsed.id || '').trim();
          const name = decodeURIComponent(String(parsed.name || '')).toLowerCase().trim();
          const resources: any[] = parsed?.projectResources?.resources || [];
          const uris = resources
            .map((r) => decodeURIComponent(String(r?.folderUri || r?.gitFolder?.folderUri || '')))
            .join(' ')
            .toLowerCase();

          if (
            id &&
            (name === qName ||
              name.includes(qName) ||
              qName.includes(name) ||
              (qPath && uris.includes(qPath)))
          ) {
            return id;
          }
        } catch {}
      }
    }

    // Si el proyecto existe en disco pero aún no tiene su archivo <uuid>.json en Antigravity, crearlo con su nombre real
    if (existsSync(targetProjectPath)) {
      mkdirSync(AGY_PROJECTS_DIR, { recursive: true });
      const { randomUUID } = require('node:crypto');
      const newId = randomUUID();
      const folderUri = `file://${targetProjectPath.split('/').map(encodeURIComponent).join('/')}`;
      const isGit = existsSync(join(targetProjectPath, '.git'));
      const projPayload = {
        id: newId,
        name: targetProjectName,
        projectResources: {
          resources: [
            isGit
              ? {
                  gitFolder: {
                    folderUri,
                    defaultBranch: 'main',
                    allowWrite: true,
                  },
                }
              : { folderUri },
          ],
        },
        permissionGrants: { v2Migrated: true },
        settings: {},
        isWorkspaceOnly: false,
      };
      writeFileSync(join(AGY_PROJECTS_DIR, `${newId}.json`), JSON.stringify(projPayload, null, 2), 'utf8');
      return newId;
    }
  } catch {}
  return '';
}

export async function openAntigravityInMac(params: {
  project?: string;
  conversationId?: string;
}): Promise<{ opened: boolean; targetPath: string; message: string }> {
  cleanupDefaultCliProject();
  const projects = await listAntigravityProjects();
  let targetPath = loadAntigravityConfig().projectsRoot;
  let targetName = 'Antigravity';

  if (params.project) {
    const q = params.project.toLowerCase().trim();
    const matched = projects.find(
      (p) => p.name.toLowerCase() === q || p.name.toLowerCase().includes(q) || p.path.toLowerCase().includes(q),
    );
    if (matched) {
      targetPath = matched.path;
      targetName = matched.name;
    } else if (existsSync(params.project)) {
      targetPath = params.project;
      targetName = basename(params.project);
    }
  } else if (params.conversationId) {
    const chats = await listAntigravityChats({ limit: 50 });
    const found = chats.find((c) => c.conversationId === params.conversationId);
    if (found?.workspacePath && existsSync(found.workspacePath)) {
      targetPath = found.workspacePath;
      targetName = found.project;
    }
  }

  // Asegurar que el proyecto exista con su nombre real en ~/.gemini/config/projects/
  resolveOrEnsureAntigravityProjectId(targetPath, targetName);

  const appPath = findAntigravityApp();
  try {
    if (appPath) {
      // Traer Antigravity.app al frente y activar todas sus ventanas sin crear un proyecto suelto
      await execFileAsync('open', ['-a', appPath]);
      await execFileAsync('osascript', ['-e', 'tell application "Antigravity" to activate']).catch(() => {});
      return {
        opened: true,
        targetPath,
        message: `Antigravity abierto en el proyecto "${targetName}" (${targetPath}).`,
      };
    } else {
      await execFileAsync('open', [targetPath]);
      return {
        opened: true,
        targetPath,
        message: `Carpeta del proyecto "${targetName}" abierta.`,
      };
    }
  } catch (e: any) {
    return {
      opened: false,
      targetPath,
      message: `No se pudo abrir la ventana de Antigravity: ${e?.message}`,
    };
  }
}

// ---------------------------------------------------------------------------
// 5. Generador Real de Documentos y Páginas Web (HTML, PDF, Word .docx, Excel .xlsx)
// ---------------------------------------------------------------------------

function slugifyFileName(title: string, ext: string): string {
  const clean = title
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9_-]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 60);
  const stamp = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
  return `${clean || 'Informe_Antigravity'}_${stamp}.${ext.replace(/^\./, '')}`;
}

function markdownOrTextToStyledHtml(title: string, content: string, fullWebPage = false): string {
  // Si el contenido ya es un documento HTML completo, devolverlo directamente
  const trimmed = content.trim();
  if (trimmed.toLowerCase().startsWith('<!doctype html') || trimmed.toLowerCase().startsWith('<html')) {
    return trimmed;
  }

  // Convertir Markdown ligero a HTML limpio y elegante
  const lines = content.split('\n');
  const htmlBlocks: string[] = [];
  let inList = false;
  let inCode = false;
  let codeBuf: string[] = [];

  const formatInline = (text: string) =>
    text
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.+?)\*/g, '<em>$1</em>')
      .replace(/`([^`]+)`/g, '<code>$1</code>');

  for (const rawLine of lines) {
    const line = rawLine.trimEnd();
    if (line.trim().startsWith('```')) {
      if (inCode) {
        htmlBlocks.push(`<pre><code>${codeBuf.join('\n').replace(/</g, '&lt;')}</code></pre>`);
        codeBuf = [];
        inCode = false;
      } else {
        if (inList) {
          htmlBlocks.push('</ul>');
          inList = false;
        }
        inCode = true;
      }
      continue;
    }
    if (inCode) {
      codeBuf.push(rawLine);
      continue;
    }

    const stripped = line.trim();
    if (!stripped) {
      if (inList) {
        htmlBlocks.push('</ul>');
        inList = false;
      }
      continue;
    }

    if (stripped.startsWith('### ')) {
      if (inList) {
        htmlBlocks.push('</ul>');
        inList = false;
      }
      htmlBlocks.push(`<h3>${formatInline(stripped.slice(4))}</h3>`);
    } else if (stripped.startsWith('## ')) {
      if (inList) {
        htmlBlocks.push('</ul>');
        inList = false;
      }
      htmlBlocks.push(`<h2>${formatInline(stripped.slice(3))}</h2>`);
    } else if (stripped.startsWith('# ')) {
      if (inList) {
        htmlBlocks.push('</ul>');
        inList = false;
      }
      htmlBlocks.push(`<h1>${formatInline(stripped.slice(2))}</h1>`);
    } else if (stripped.startsWith('- ') || stripped.startsWith('* ') || stripped.startsWith('• ')) {
      if (!inList) {
        htmlBlocks.push('<ul>');
        inList = true;
      }
      htmlBlocks.push(`<li>${formatInline(stripped.slice(2))}</li>`);
    } else {
      if (inList) {
        htmlBlocks.push('</ul>');
        inList = false;
      }
      htmlBlocks.push(`<p>${formatInline(stripped)}</p>`);
    }
  }
  if (inList) htmlBlocks.push('</ul>');
  if (inCode && codeBuf.length) {
    htmlBlocks.push(`<pre><code>${codeBuf.join('\n').replace(/</g, '&lt;')}</code></pre>`);
  }

  const dateStr = new Date().toLocaleString('es-CO', {
    dateStyle: 'long',
    timeStyle: 'short',
  });

  return `<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>${title.replace(/</g, '&lt;')}</title>
  <style>
    :root {
      --primary: #4f46e5;
      --bg: ${fullWebPage ? '#0f172a' : '#ffffff'};
      --card: ${fullWebPage ? '#1e293b' : '#ffffff'};
      --text: ${fullWebPage ? '#f8fafc' : '#1e293b'};
      --muted: ${fullWebPage ? '#94a3b8' : '#64748b'};
      --border: ${fullWebPage ? '#334155' : '#e2e8f0'};
    }
    * { box-sizing: border-box; }
    body {
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      background: var(--bg);
      color: var(--text);
      margin: 0;
      padding: ${fullWebPage ? '32px 16px' : '28px 36px'};
      line-height: 1.65;
    }
    .container {
      max-width: 880px;
      margin: 0 auto;
      background: var(--card);
      border: 1px solid var(--border);
      border-radius: 16px;
      padding: 36px 40px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.06);
    }
    .header-badge {
      display: inline-block;
      font-size: 12px;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.08em;
      color: #6366f1;
      background: rgba(99, 102, 241, 0.12);
      padding: 4px 12px;
      border-radius: 999px;
      margin-bottom: 12px;
    }
    h1 {
      font-size: 28px;
      margin: 0 0 8px 0;
      color: var(--text);
    }
    .meta {
      font-size: 13px;
      color: var(--muted);
      margin-bottom: 28px;
      padding-bottom: 16px;
      border-bottom: 1px solid var(--border);
    }
    h2 {
      font-size: 20px;
      margin-top: 26px;
      margin-bottom: 10px;
      color: #4f46e5;
    }
    h3 {
      font-size: 16px;
      margin-top: 20px;
      margin-bottom: 8px;
    }
    p, li {
      font-size: 15px;
      margin-bottom: 10px;
    }
    ul {
      padding-left: 22px;
      margin-bottom: 16px;
    }
    code {
      font-family: ui-monospace, SFMono-Regular, Menlo, monospace;
      background: rgba(99, 102, 241, 0.1);
      padding: 2px 6px;
      border-radius: 4px;
      font-size: 13.5px;
    }
    pre {
      background: #0f172a;
      color: #e2e8f0;
      padding: 16px;
      border-radius: 10px;
      overflow-x: auto;
    }
    pre code {
      background: transparent;
      padding: 0;
      color: inherit;
    }
  </style>
</head>
<body>
  <div class="container">
    <div class="header-badge">WAPPY IA · Tenshi × Antigravity</div>
    <h1>${title.replace(/</g, '&lt;')}</h1>
    <div class="meta">Generado el ${dateStr}</div>
    ${htmlBlocks.join('\n    ')}
  </div>
</body>
</html>`;
}

export async function generateSharedDocument(params: {
  title: string;
  format: 'html' | 'webpage' | 'pdf' | 'docx' | 'word' | 'xlsx' | 'excel';
  content: string;
  rows?: Array<Record<string, any>>;
  project?: string;
  conversationId?: string;
}): Promise<SharedFileItem> {
  ensureDirs();
  const normFormat = params.format.toLowerCase().trim();

  if (normFormat === 'xlsx' || normFormat === 'excel') {
    const fileName = slugifyFileName(params.title, 'xlsx');
    const outPath = join(SHARED_FILES_DIR, fileName);
    const wb = XLSX.utils.book_new();

    let sheetData: any[] = [];
    if (Array.isArray(params.rows) && params.rows.length > 0) {
      sheetData = params.rows;
    } else {
      // Parse markdown/text lines or tables into rows
      const lines = params.content.split('\n').filter((l) => l.trim().length > 0);
      sheetData = lines.map((line, idx) => ({
        Item: idx + 1,
        Seccion: line.startsWith('#') ? 'Título / Sección' : 'Detalle',
        Contenido: line.replace(/^#+\s*/, '').replace(/^[-*•]\s*/, ''),
      }));
    }

    const ws = XLSX.utils.json_to_sheet(sheetData);
    XLSX.utils.book_append_sheet(wb, ws, 'Informe');
    XLSX.writeFile(wb, outPath);
    return registerSharedFile({
      filePath: outPath,
      title: params.title,
      project: params.project,
      conversationId: params.conversationId,
    });
  }

  if (normFormat === 'docx' || normFormat === 'word') {
    const html = markdownOrTextToStyledHtml(params.title, params.content, false);
    const tempHtmlPath = join(SHARED_FILES_DIR, `.tmp_${Date.now()}.html`);
    const fileName = slugifyFileName(params.title, 'docx');
    const outPath = join(SHARED_FILES_DIR, fileName);
    writeFileSync(tempHtmlPath, html, 'utf8');
    try {
      await execFileAsync('/usr/bin/textutil', ['-convert', 'docx', tempHtmlPath, '-output', outPath]);
    } finally {
      try {
        const { unlinkSync } = await import('node:fs');
        unlinkSync(tempHtmlPath);
      } catch {}
    }
    return registerSharedFile({
      filePath: outPath,
      title: params.title,
      project: params.project,
      conversationId: params.conversationId,
    });
  }

  if (normFormat === 'pdf') {
    const html = markdownOrTextToStyledHtml(params.title, params.content, false);
    const tempHtmlPath = join(SHARED_FILES_DIR, `.tmp_${Date.now()}.html`);
    const fileName = slugifyFileName(params.title, 'pdf');
    const outPath = join(SHARED_FILES_DIR, fileName);
    writeFileSync(tempHtmlPath, html, 'utf8');

    const chromeBin = existsSync('/Applications/Google Chrome.app/Contents/MacOS/Google Chrome')
      ? '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome'
      : '/Applications/Brave Browser.app/Contents/MacOS/Brave Browser';

    try {
      await execFileAsync(chromeBin, [
        '--headless',
        '--disable-gpu',
        '--no-pdf-header-footer',
        `--print-to-pdf=${outPath}`,
        `file://${tempHtmlPath}`,
      ]);
    } finally {
      try {
        const { unlinkSync } = await import('node:fs');
        unlinkSync(tempHtmlPath);
      } catch {}
    }
    return registerSharedFile({
      filePath: outPath,
      title: params.title,
      project: params.project,
      conversationId: params.conversationId,
    });
  }

  // Default: HTML / Página Web
  const html = markdownOrTextToStyledHtml(params.title, params.content, normFormat === 'webpage');
  const fileName = slugifyFileName(params.title, 'html');
  const outPath = join(SHARED_FILES_DIR, fileName);
  writeFileSync(outPath, html, 'utf8');
  return registerSharedFile({
    filePath: outPath,
    title: params.title,
    project: params.project,
    conversationId: params.conversationId,
  });
}

// ---------------------------------------------------------------------------
// 6. Ejecutar Tarea en Antigravity (`agy` CLI + Síntesis Rápida + Artefactos)
// ---------------------------------------------------------------------------

async function notifyNotchHook(
  eventName: 'UserPromptSubmit' | 'PreToolUse' | 'PostToolUse' | 'Stop',
  cwd: string,
  toolName?: string,
) {
  try {
    await fetch('http://127.0.0.1:47629/hook', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        session_id: 'tenshi-agy-orchestrator',
        hook_event_name: eventName,
        cwd,
        agent: 'antigravity',
        ...(toolName ? { tool_name: toolName } : {}),
      }),
    });
  } catch {}
}

async function gatherProjectAndChatContext(
  targetProjectPath: string,
  targetProjectName: string,
  resolvedConvId?: string,
): Promise<string> {
  const sections: string[] = [];
  sections.push(`PROYECTO: ${targetProjectName} (${targetProjectPath})`);

  // 1. Listar estructura principal del proyecto y leer archivos clave
  if (existsSync(targetProjectPath)) {
    try {
      const entries = readdirSync(targetProjectPath, { withFileTypes: true })
        .filter((e) => !e.name.startsWith('.') && e.name !== 'node_modules')
        .slice(0, 40)
        .map((e) => (e.isDirectory() ? `${e.name}/` : e.name));
      sections.push(`ESTRUCTura RAÍZ DEL PROYECTO:\n${entries.join(', ')}`);
    } catch {}

    const docCandidates = ['README.md', 'CLAUDE.md', 'AGENTS.md', 'package.json'];
    for (const fileName of docCandidates) {
      const fullPath = join(targetProjectPath, fileName);
      if (existsSync(fullPath)) {
        try {
          const raw = readFileSync(fullPath, 'utf8').slice(0, 5000);
          sections.push(`ARCHIVO ${fileName}:\n${raw}`);
        } catch {}
      }
    }
  }

  // 2. Chats recientes del proyecto en Antigravity
  const projectChats = await listAntigravityChats({ project: targetProjectName, limit: 8 });
  if (projectChats.length > 0) {
    const chatListText = projectChats
      .map(
        (c, i) =>
          `${i + 1}. "${c.title}" (ID: ${c.conversationId}, Pasos: ${c.stepCount}) — Preview: ${c.preview}`,
      )
      .join('\n');
    sections.push(`CHATS RECIENTES EN ANTIGRAVITY PARA ESTE PROYECTO:\n${chatListText}`);
  }

  // 3. Mensajes detallados del chat seleccionado o del chat más reciente del proyecto
  const convToRead = resolvedConvId || projectChats[0]?.conversationId;
  if (convToRead) {
    try {
      const chatDetail = await readAntigravityChat(convToRead);
      if (chatDetail.recentMessages.length > 0) {
        const msgsText = chatDetail.recentMessages
          .slice(-8)
          .map((m) => `[${m.role.toUpperCase()}]: ${m.text.slice(0, 800)}`)
          .join('\n\n');
        sections.push(
          `HISTORIAL DEL CHAT "${chatDetail.title || convToRead}" (${convToRead}):\n${msgsText}`,
        );
      }
      if (chatDetail.artifacts.length > 0) {
        sections.push(`ARTEFACTOS DEL CHAT:\n${chatDetail.artifacts.join('\n')}`);
      }
    } catch {}
  }

  return sections.join('\n\n---\n\n');
}

function getFastGeminiKeys(): string[] {
  const keys: string[] = [];
  // 1. Leer de ~/.wappy/gemini-tunnel.json (donde están las 6 claves de texto y 3 de voz configuradas)
  const tunnelCfgPath =
    process.env.GEMINI_TUNNEL_CONFIG_PATH || join(HOME, '.wappy', 'gemini-tunnel.json');
  if (existsSync(tunnelCfgPath)) {
    try {
      const parsed = JSON.parse(readFileSync(tunnelCfgPath, 'utf8'));
      for (const k of [...(parsed.textKeys || []), ...(parsed.voiceKeys || [])]) {
        const clean = String(k || '').trim();
        if (clean && !keys.includes(clean)) keys.push(clean);
      }
    } catch {}
  }

  // 2. Revisar variables de entorno GEMINI_TEXT_KEY_1..6
  for (let i = 1; i <= 6; i++) {
    const k = (process.env[`GEMINI_TEXT_KEY_${i}`] || process.env[`GEMINI_POOL_KEY_${i}`])?.trim();
    if (k && !keys.includes(k)) keys.push(k);
  }
  const extra = (
    process.env.GEMINI_TEXT_API_KEYS ||
    process.env.GOOGLE_KEY ||
    process.env.GEMINI_API_KEY ||
    ''
  )
    .split(',')
    .map((s) => s.trim())
    .filter(Boolean);
  for (const k of extra) {
    if (!keys.includes(k)) keys.push(k);
  }
  return keys;
}

async function discoverLiveAntigravityServer(): Promise<{
  lsAddress: string;
  csrfToken: string;
} | null> {
  try {
    const { stdout: psOut } = await execFileAsync('ps', ['ax', '-o', 'pid=,command=']);
    const lines = psOut.split('\n');
    for (const line of lines) {
      if (
        line.includes('/Antigravity.app/Contents/Resources/bin/language_server') &&
        line.includes('--csrf_token') &&
        line.includes('--app_data_dir antigravity')
      ) {
        const pidMatch = line.trim().match(/^(\d+)\s+/);
        const csrfMatch = line.match(/--csrf_token\s+([a-f0-9-]+)/i);
        if (!pidMatch || !csrfMatch) continue;
        const pid = pidMatch[1];
        const csrfToken = csrfMatch[1];
        const { stdout: lsofOut } = await execFileAsync('lsof', [
          '-nP',
          '-iTCP',
          '-sTCP:LISTEN',
          '-a',
          '-p',
          pid,
        ]);
        const ports: number[] = [];
        for (const lLine of lsofOut.split('\n')) {
          const m = lLine.match(/127\.0\.0\.1:(\d+)\s+\(LISTEN\)/);
          if (m) ports.push(Number(m[1]));
        }
        // Probar cuál puerto responde HTTP /healthz (normalmente el segundo puerto es HTTP)
        for (const port of [...ports].reverse()) {
          try {
            const r = await fetch(`http://127.0.0.1:${port}/healthz`, {
              signal: AbortSignal.timeout(800),
            });
            if (r.ok) {
              return { lsAddress: `127.0.0.1:${port}`, csrfToken };
            }
          } catch {}
        }
      }
    }
  } catch {}
  return null;
}

export function resolveOrderedKeysAndModelsForAgent(agentId: string = 'antigravity'): {
  keys: string[];
  models: string[];
  ideCliTier: 'flash_lite' | 'flash' | 'pro';
  route: AgentRouteEntry;
} {
  const activeApis = getActiveSystemApisSync();
  const routes = activeApis.routes;
  const route = routes[agentId] || routes.antigravity;

  const allTextKeys = activeApis.rawTextKeys;
  const allVoiceKeys = activeApis.rawVoiceKeys;
  const allKeys = [...allTextKeys];
  for (const vk of allVoiceKeys) {
    if (!allKeys.includes(vk)) allKeys.push(vk);
  }

  let prioritizedKeys: string[] = [];
  const sel = route.apiSelection || 'auto_pool';

  if (sel.startsWith('text_key_')) {
    const idx = Math.max(0, Number(sel.replace('text_key_', '')) - 1);
    if (allTextKeys[idx]) prioritizedKeys.push(allTextKeys[idx]);
  } else if (sel.startsWith('voice_key_')) {
    const idx = Math.max(0, Number(sel.replace('voice_key_', '')) - 1);
    if (allVoiceKeys[idx]) prioritizedKeys.push(allVoiceKeys[idx]);
  } else if (sel === 'auto_voice_pool') {
    const offset = (route.rotationOffset || 0) % Math.max(allVoiceKeys.length, 1);
    prioritizedKeys = [
      ...allVoiceKeys.slice(offset),
      ...allVoiceKeys.slice(0, offset),
    ];
  } else {
    const offset = (route.rotationOffset || 0) % Math.max(allTextKeys.length, 1);
    prioritizedKeys = [
      ...allTextKeys.slice(offset),
      ...allTextKeys.slice(0, offset),
    ];
  }

  if (route.autoRotateFallback !== false || prioritizedKeys.length === 0) {
    for (const k of allKeys) {
      if (!prioritizedKeys.includes(k)) prioritizedKeys.push(k);
    }
  }
  if (prioritizedKeys.length === 0) {
    prioritizedKeys = getFastGeminiKeys();
  }

  const baseModels =
    agentId === 'tenshi_voice'
      ? ['gemini-3.1-flash-live-preview', 'gemini-3.8-live']
      : ['gemini-3.5-flash-lite', 'gemini-3.8-flash', 'gemini-3.6-flash'];
  const preferredModel = route.model || baseModels[0];
  const models =
    route.autoRotateFallback !== false
      ? [preferredModel, ...baseModels.filter((m) => m !== preferredModel)]
      : [preferredModel];

  const ideInfo = IDE_MODEL_TO_PLACEHOLDER[route.ideModel || 'flash'] || IDE_MODEL_TO_PLACEHOLDER.flash;

  return {
    keys: prioritizedKeys,
    models,
    ideCliTier: ideInfo.cliTier,
    route,
  };
}

async function dispatchToLiveAntigravityApp(params: {
  projectId: string;
  conversationId?: string;
  title: string;
  prompt: string;
}): Promise<{ conversationId?: string; plannerReply?: string }> {
  if (!existsSync(AGY_LANGUAGE_SERVER_BIN) || !params.projectId) {
    return {};
  }
  const liveServer = await discoverLiveAntigravityServer();
  if (!liveServer) return {};

  const { ideCliTier, route } = resolveOrderedKeysAndModelsForAgent('antigravity');
  syncAntigravityIdeDefaultGeminiModel(route.ideModel || 'flash');

  const env: Record<string, string> = {};
  for (const [k, v] of Object.entries(process.env)) {
    if (
      v !== undefined &&
      k !== 'ANTIGRAVITY_CONVERSATION_ID' &&
      k !== 'ANTIGRAVITY_SOURCE_METADATA' &&
      k !== 'ANTIGRAVITY_TRAJECTORY_ID'
    ) {
      env[k] = v;
    }
  }
  env.ANTIGRAVITY_LS_ADDRESS = liveServer.lsAddress;
  env.ANTIGRAVITY_CSRF_TOKEN = liveServer.csrfToken;
  env.ANTIGRAVITY_PROJECT_ID = params.projectId;

  let activeConvId = params.conversationId;
  try {
    if (activeConvId) {
      await execFileAsync(
        AGY_LANGUAGE_SERVER_BIN,
        ['agentapi', 'send-message', activeConvId, params.prompt],
        { env, timeout: 10000 },
      );
    } else {
      const { stdout } = await execFileAsync(
        AGY_LANGUAGE_SERVER_BIN,
        [
          'agentapi',
          'new-conversation',
          `--model=${ideCliTier}`,
          `--title=${params.title}`,
          params.prompt,
        ],
        { env, timeout: 10000 },
      );
      const parsed = JSON.parse(stdout || '{}');
      activeConvId = parsed?.response?.newConversation?.conversationId;
    }
  } catch (err: any) {
    console.warn('[AntigravityBridge] agentapi aviso:', err?.message);
  }

  // Esperar brevemente (hasta ~4.5s) por si Antigravity ya escribió la primera respuesta directa en transcript.jsonl
  if (activeConvId) {
    const transcriptPath = join(
      AGY_BRAIN_DIR,
      activeConvId,
      '.system_generated',
      'logs',
      'transcript.jsonl',
    );
    for (let i = 0; i < 6; i++) {
      await new Promise((r) => setTimeout(r, 700));
      if (!existsSync(transcriptPath)) continue;
      try {
        const lines = readFileSync(transcriptPath, 'utf8').split('\n').filter(Boolean);
        for (let idx = lines.length - 1; idx >= 0; idx--) {
          const step = JSON.parse(lines[idx]);
          if (
            step.type === 'PLANNER_RESPONSE' &&
            step.status === 'DONE' &&
            typeof step.content === 'string' &&
            step.content.trim().length > 20
          ) {
            return { conversationId: activeConvId, plannerReply: step.content.trim() };
          }
        }
      } catch {}
    }
  }

  return { conversationId: activeConvId };
}

async function synthesizeAntigravityResponseFast(
  prompt: string,
  contextText: string,
  targetProjectName: string,
): Promise<string> {
  const { keys, models } = resolveOrderedKeysAndModelsForAgent('antigravity');

  const sysPrompt = `Eres Antigravity conectado a Tenshi (WAPPY IA).
Tienes acceso directo al contexto real del proyecto "${targetProjectName}", su código/documentación y sus conversaciones reales en Antigravity.
Responde en español de forma clara, completa, estructurada y precisa a la solicitud del usuario basándote en los datos reales del proyecto y sus chats.
No inventes información; usa los datos del contexto adjunto.`;

  for (const model of models) {
    for (const key of keys) {
      try {
        const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${encodeURIComponent(key)}`;
        const res = await fetch(url, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          signal: AbortSignal.timeout(10000),
          body: JSON.stringify({
            systemInstruction: { parts: [{ text: sysPrompt }] },
            contents: [
              {
                role: 'user',
                parts: [
                  {
                    text: `CONTEXTO REAL DE ANTIGRAVITY (${targetProjectName}):\n\n${contextText}\n\n===\nSOLICITUD DEL USUARIO:\n${prompt}`,
                  },
                ],
              },
            ],
            generationConfig: {
              temperature: 0.3,
              maxOutputTokens: 1500,
            },
          }),
        });
        if (!res.ok) continue;
        const data: any = await res.json();
        const text = (data?.candidates?.[0]?.content?.parts || [])
          .map((p: any) => p?.text || '')
          .join('')
          .trim();
        if (text) return text;
      } catch {}
    }
  }
  return '';
}

export async function runAntigravityTask(params: {
  prompt: string;
  project?: string;
  conversationId?: string;
  chatQuery?: string;
  continueLatest?: boolean;
  openInMac?: boolean;
  outputFormat?: 'html' | 'webpage' | 'pdf' | 'docx' | 'word' | 'xlsx' | 'excel' | 'none';
  outputTitle?: string;
}): Promise<{
  ok: boolean;
  project: string;
  projectPath: string;
  conversationId?: string;
  responseText: string;
  generatedFiles: SharedFileItem[];
}> {
  cleanupDefaultCliProject();
  const projects = await listAntigravityProjects();
  let targetProjectPath = loadAntigravityConfig().projectsRoot;
  let targetProjectName = 'Wappy Bot';

  if (params.project) {
    const q = params.project.toLowerCase().trim();
    const matched = projects.find(
      (p) => p.name.toLowerCase() === q || p.name.toLowerCase().includes(q) || p.path.toLowerCase().includes(q),
    );
    if (matched) {
      targetProjectPath = matched.path;
      targetProjectName = matched.name;
    } else if (existsSync(params.project)) {
      targetProjectPath = params.project;
      targetProjectName = basename(params.project);
    }
  }

  // Resolver conversación existente si el usuario pidió abrir un chat específico por nombre o ID, o continuar el último
  let resolvedConvId = params.conversationId?.trim();
  if (!resolvedConvId && (params.chatQuery || params.continueLatest)) {
    const matchingChats = await listAntigravityChats({
      project: targetProjectName,
      query: params.chatQuery,
      limit: 5,
    });
    if (matchingChats.length > 0) {
      resolvedConvId = matchingChats[0].conversationId;
      if (matchingChats[0].workspacePath && existsSync(matchingChats[0].workspacePath)) {
        targetProjectPath = matchingChats[0].workspacePath;
        targetProjectName = matchingChats[0].project;
      }
    }
  }

  // Resolver el projectId real de ~/.gemini/config/projects/<id>.json (NUNCA default-cli-project)
  const realProjectId = resolveOrEnsureAntigravityProjectId(targetProjectPath, targetProjectName);

  // Notificar inmediatamente al Notch que Antigravity está trabajando en este proyecto
  await notifyNotchHook('UserPromptSubmit', targetProjectPath);
  await notifyNotchHook('PreToolUse', targetProjectPath, `Proyecto ${targetProjectName}`);

  // Traer Antigravity.app al frente si corresponde
  const shouldOpenInMac = params.openInMac !== false;
  if (shouldOpenInMac) {
    await openAntigravityInMac({ project: targetProjectPath, conversationId: resolvedConvId });
  }

  // Ejecutar en paralelo:
  // 1) Crear o continuar la conversación real dentro del proyecto en Antigravity.app vía `language_server agentapi`
  // 2) Recolectar el contexto real del proyecto y sintetizar respuesta rápida para que Tenshi no espere
  const shortTitle = `Tenshi: ${params.prompt.slice(0, 42).trim()}`;
  const [liveDispatch, fastSynthesis] = await Promise.all([
    dispatchToLiveAntigravityApp({
      projectId: realProjectId,
      conversationId: resolvedConvId,
      title: shortTitle,
      prompt: params.prompt,
    }),
    (async () => {
      const contextText = await gatherProjectAndChatContext(
        targetProjectPath,
        targetProjectName,
        resolvedConvId,
      );
      const text = await synthesizeAntigravityResponseFast(
        params.prompt,
        contextText,
        targetProjectName,
      );
      return { text, contextText };
    })(),
  ]);

  if (liveDispatch.conversationId) {
    resolvedConvId = liveDispatch.conversationId;
  }

  let responseText = liveDispatch.plannerReply || fastSynthesis.text;

  // Fallback adicional si aún no hubiera texto
  if (!responseText) {
    responseText = fastSynthesis.contextText
      ? `He abierto el proyecto **${targetProjectName}** en Antigravity.\n\n${fastSynthesis.contextText.slice(0, 1500)}`
      : `Tarea ejecutada en Antigravity (Proyecto: **${targetProjectName}**).`;
  }

  cleanupDefaultCliProject();

  const generatedFiles: SharedFileItem[] = [];

  // 1) Sincronizar artefactos o documentos que Antigravity haya creado en la conversación (~/.gemini/antigravity/brain/<id>)
  if (resolvedConvId) {
    try {
      const convDir = join(AGY_BRAIN_DIR, basename(resolvedConvId));
      if (existsSync(convDir)) {
        for (const entry of readdirSync(convDir, { withFileTypes: true })) {
          if (!entry.isFile() || entry.name.startsWith('.')) continue;
          const fullArtifactPath = join(convDir, entry.name);
          const ext = extname(entry.name).toLowerCase();
          if (ext === '.md') {
            const mdRaw = readFileSync(fullArtifactPath, 'utf8');
            if (mdRaw.trim().length > 20) {
              const baseTitle = basename(entry.name, '.md');
              const htmlItem = await generateSharedDocument({
                title: `${targetProjectName}_${baseTitle}`,
                format: 'html',
                content: mdRaw,
                project: targetProjectName,
                conversationId: resolvedConvId,
              });
              if (!generatedFiles.some((f) => f.fileName === htmlItem.fileName)) {
                generatedFiles.push(htmlItem);
              }
            }
          } else if (['.pdf', '.docx', '.xlsx', '.html', '.htm', '.csv', '.png', '.jpg'].includes(ext)) {
            const regItem = registerSharedFile({
              filePath: fullArtifactPath,
              title: `${targetProjectName} · ${entry.name}`,
              project: targetProjectName,
              conversationId: resolvedConvId,
            });
            if (!generatedFiles.some((f) => f.fileName === regItem.fileName)) {
              generatedFiles.push(regItem);
            }
          }
        }
      }
    } catch {}
  }

  // 2) Detectar automáticamente si el usuario pidió generar o enviar un documento/informe al celular por voz
  let effectiveFormat = params.outputFormat && params.outputFormat !== 'none' ? params.outputFormat : 'none';
  if (effectiveFormat === 'none') {
    const pLower = params.prompt.toLowerCase();
    if (/\b(word|docx|\.doc)\b/i.test(pLower)) {
      effectiveFormat = 'docx';
    } else if (/\b(excel|xlsx|planilla|hoja de c[aá]lculo)\b/i.test(pLower)) {
      effectiveFormat = 'xlsx';
    } else if (/\b(html|p[aá]gina web|pagina web|landing)\b/i.test(pLower)) {
      effectiveFormat = 'html';
    } else if (
      /\b(pdf|informe|documento|reporte|archivo)\b/i.test(pLower) ||
      /\b(env[ií]a(?:me|lo|selo)|p[aá]sa(?:me|lo|selo)|transm[ií]t(?:e|elo)|manda(?:me|lo)|a mi celular|al celular|pantalla de(?:l)? celular)\b/i.test(pLower)
    ) {
      effectiveFormat = 'pdf';
    }
  }

  // Si el usuario pidió generar un archivo (HTML, PDF, Word, Excel, Página Web) y pasarlo por el chat / celular
  if (effectiveFormat && effectiveFormat !== 'none') {
    await notifyNotchHook('PreToolUse', targetProjectPath, `Generar ${effectiveFormat.toUpperCase()}`);
    const docContent =
      responseText ||
      `# ${params.outputTitle || 'Informe de Antigravity'}\n\nProyecto: **${targetProjectName}**\n\nSolicitud ejecutada:\n${params.prompt}`;
    const item = await generateSharedDocument({
      title: params.outputTitle || `Informe_${targetProjectName}`,
      format: effectiveFormat,
      content: docContent,
      project: targetProjectName,
      conversationId: resolvedConvId,
    });
    generatedFiles.unshift(item);
  }

  await notifyNotchHook('PostToolUse', targetProjectPath, `Proyecto ${targetProjectName}`);
  await notifyNotchHook('Stop', targetProjectPath);

  // Registrar en el historial compartido para que aparezca en el celular y en el Notch con trazabilidad completa
  const activityHeader = `🛠️ **Actividad ejecutada en Antigravity**\n• **Proyecto**: ${targetProjectName}\n• **Instrucción**: "${params.prompt}"${resolvedConvId ? `\n• **Sesión Antigravity**: \`${resolvedConvId.slice(0, 8)}\`` : ''}\n\n---\n\n`;
  const summaryMsg = [
    activityHeader,
    responseText,
    ...generatedFiles.map(
      (f) =>
        `\n\n📎 **Documento transmitido al celular (${f.format.toUpperCase()})**: [${f.fileName}](${f.localUrl})\n🌐 Acceso móvil: [Abrir ${f.fileName}](${f.lanUrl})`,
    ),
  ].join('');

  appendSharedChatMessage({
    role: 'assistant',
    content: summaryMsg,
    source: 'antigravity',
    project: targetProjectName,
    conversationId: resolvedConvId,
    files: generatedFiles,
  });

  return {
    ok: true,
    project: targetProjectName,
    projectPath: targetProjectPath,
    conversationId: resolvedConvId,
    responseText: summaryMsg,
    generatedFiles,
  };
}

// ---------------------------------------------------------------------------
// 7. Declaraciones de Herramientas (Tools) para Gemini (Chat y Voz)
// ---------------------------------------------------------------------------

export const ANTIGRAVITY_OPENAI_TOOLS = [
  {
    type: 'function',
    function: {
      name: 'antigravity_list_projects',
      description:
        'Lista todos los proyectos y repositorios disponibles en Antigravity y en la carpeta GitHub del Mac. Úsala cuando el usuario pregunte qué proyectos tiene o pida abrir un proyecto en Antigravity.',
      parameters: {
        type: 'object',
        properties: {},
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'antigravity_list_chats',
      description:
        'Lista o busca los chats y conversaciones reales de Antigravity en el Mac, mostrando su título, proyecto, ID de conversación y vista previa.',
      parameters: {
        type: 'object',
        properties: {
          project: {
            type: 'string',
            description: 'Nombre opcional del proyecto para filtrar (ej. "Wappy Bot", "LibreChat-WAPPY").',
          },
          query: {
            type: 'string',
            description: 'Texto opcional para buscar por título o tema del chat.',
          },
        },
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'antigravity_read_chat',
      description:
        'Lee los últimos mensajes y artefactos de un chat específico de Antigravity usando su conversationId.',
      parameters: {
        type: 'object',
        properties: {
          conversationId: {
            type: 'string',
            description: 'El ID de la conversación de Antigravity.',
          },
        },
        required: ['conversationId'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'antigravity_run_task',
      description:
        'Ingresa a Antigravity, abre un proyecto (en un chat existente o en un nuevo chat), ejecuta una instrucción o actividad y opcionalmente genera un informe (HTML, PDF, Word, Excel o página web) y lo pasa al chat de Tenshi.',
      parameters: {
        type: 'object',
        properties: {
          prompt: {
            type: 'string',
            description: 'La instrucción, pregunta o tarea completa que debe realizar Antigravity.',
          },
          project: {
            type: 'string',
            description: 'Nombre del proyecto donde trabajar (ej. "Wappy Bot", "LibreChat-WAPPY").',
          },
          conversationId: {
            type: 'string',
            description: 'ID de un chat existente si el usuario pidió continuar uno específico.',
          },
          chatQuery: {
            type: 'string',
            description: 'Nombre o tema del chat existente si el usuario lo mencionó por título.',
          },
          continueLatest: {
            type: 'boolean',
            description: 'True si debe continuar el chat más reciente del proyecto; False para un nuevo chat.',
          },
          openInMac: {
            type: 'boolean',
            description: 'True si además debe abrir la ventana visual de Antigravity en el Mac.',
          },
          outputFormat: {
            type: 'string',
            enum: ['none', 'html', 'webpage', 'pdf', 'docx', 'xlsx'],
            description:
              'Si el usuario pidió que le pases un archivo por el chat (informe HTML, PDF, Word .docx, Excel .xlsx o página web), indica aquí el formato.',
          },
          outputTitle: {
            type: 'string',
            description: 'Título descriptivo para el archivo generado.',
          },
        },
        required: ['prompt'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'antigravity_generate_document',
      description:
        'Genera inmediatamente un archivo descargable (HTML, página web completa, PDF, documento de Word .docx o tabla de Excel .xlsx) y lo envía directamente al chat de Tenshi para abrirlo en el Mac o en el celular.',
      parameters: {
        type: 'object',
        properties: {
          title: {
            type: 'string',
            description: 'Título del documento, informe o página web.',
          },
          format: {
            type: 'string',
            enum: ['html', 'webpage', 'pdf', 'docx', 'xlsx'],
            description: 'Formato del archivo a generar y enviar al chat.',
          },
          content: {
            type: 'string',
            description:
              'Contenido completo y detallado del documento (en Markdown bien estructurado o código HTML5 completo si es webpage/html).',
          },
          project: {
            type: 'string',
            description: 'Nombre opcional del proyecto relacionado.',
          },
        },
        required: ['title', 'format', 'content'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'wappy_agent_team',
      description:
        'Coordina el Team de Agentes de Wappy Dots (estilo OpenClaw) en paralelo: Investigador Web & Normativo (Google Search Grounding 2025-2026), Ingeniero Antigravity (código y proyectos), Analista Siigo & Workspace (Siigo ERP, Gmail, Calendar, Drive), Operador Web & Chrome y Redactor Documental (HTML, PDF, Word, Excel). Anima cada sub-agente en tiempo real en el Notch de Wappy Dots.',
      parameters: {
        type: 'object',
        properties: {
          goal: {
            type: 'string',
            description: 'Objetivo o misión completa que debe resolver el Team de Agentes en paralelo.',
          },
          agents: {
            type: 'array',
            items: {
              type: 'string',
              enum: ['researcher', 'antigravity', 'workspace_erp', 'browser_qa', 'writer'],
            },
            description: 'Lista opcional de agentes especialistas a convocar (si se omite, el orquestador elige automáticamente).',
          },
          project: {
            type: 'string',
            description: 'Proyecto opcional de Antigravity relacionado.',
          },
          openBrowser: {
            type: 'boolean',
            description: 'True si el agente browser_qa debe abrir una pestaña de búsqueda verificada en Chrome.',
          },
          outputFormat: {
            type: 'string',
            enum: ['none', 'html', 'webpage', 'pdf', 'docx', 'xlsx'],
            description: 'Formato opcional de informe descargable generado por el equipo.',
          },
          outputTitle: {
            type: 'string',
            description: 'Título opcional del informe.',
          },
          dynamicSubagents: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                name: { type: 'string' },
                role: { type: 'string' },
                instructions: { type: 'string' },
                useWebSearch: { type: 'boolean' },
              },
              required: ['name', 'role', 'instructions'],
            },
            description: 'Sub-agentes personalizados adicionales instanciados bajo demanda (sessions_spawn).',
          },
        },
        required: ['goal'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'wappy_memory_skills',
      description:
        'Gestiona la Memoria Dual estructurada de Wappy Dots (USER.md y MEMORY.md), la búsqueda instantánea de sesiones pasadas en SQLite FTS5 BM25 y el catálogo de Skills procedimentales (SKILL.md).',
      parameters: {
        type: 'object',
        properties: {
          action: {
            type: 'string',
            enum: ['get_memory', 'save_memory', 'dream_memory', 'search_history', 'list_skills', 'save_skill'],
            description: 'Acción a ejecutar en el núcleo autónomo de Wappy Dots.',
          },
          target: {
            type: 'string',
            enum: ['user', 'memory', 'soul'],
            description: 'Archivo de memoria objetivo cuando action="save_memory".',
          },
          content: {
            type: 'string',
            description: 'Hecho a guardar en memoria o contenido Markdown de la Skill.',
          },
          query: {
            type: 'string',
            description: 'Consulta de búsqueda para SQLite FTS5 BM25 cuando action="search_history".',
          },
          slug: {
            type: 'string',
            description: 'Identificador kebab-case de la Skill cuando action="save_skill".',
          },
          title: {
            type: 'string',
            description: 'Título de la Skill cuando action="save_skill".',
          },
          description: {
            type: 'string',
            description: 'Descripción de la Skill cuando action="save_skill".',
          },
        },
        required: ['action'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'wappy_cron_schedule',
      description:
        'Crea, lista, ejecuta o elimina tareas programadas automáticas (Cron) en Wappy Dots que corren con el Team de Agentes y notifican en el Notch.',
      parameters: {
        type: 'object',
        properties: {
          action: {
            type: 'string',
            enum: ['list', 'create', 'run_now', 'delete'],
            description: 'Acción sobre el motor Cron de Wappy Dots.',
          },
          id: {
            type: 'string',
            description: 'ID del job cuando action="run_now" o "delete".',
          },
          name: {
            type: 'string',
            description: 'Nombre descriptivo de la automatización.',
          },
          goal: {
            type: 'string',
            description: 'Instrucción o misión que ejecutará automáticamente el Team de Agentes.',
          },
          everyMinutes: {
            type: 'number',
            description: 'Intervalo en minutos (ej. 60 para cada hora).',
          },
          dailyAt: {
            type: 'string',
            description: 'Hora fija diaria en formato HH:MM (ej. "08:00").',
          },
        },
        required: ['action'],
      },
    },
  },
  {
    type: 'function',
    function: {
      name: 'wappy_external_agent',
      description:
        'Consulta el estado o delega opcionalmente una tarea a conectores externos (OpenClaw Gateway, Hermes Agent u OpenMausBot) cuando el usuario desee conectarse a ellos.',
      parameters: {
        type: 'object',
        properties: {
          action: {
            type: 'string',
            enum: ['status', 'delegate'],
            description: 'Consultar estado de conectores o delegar misión.',
          },
          target: {
            type: 'string',
            enum: ['openclaw', 'hermes', 'openmausbot'],
            description: 'Agente externo destino.',
          },
          goal: {
            type: 'string',
            description: 'Misión a delegar al agente externo.',
          },
        },
        required: ['action'],
      },
    },
  },
  // Herramientas Oficiales de Siigo Nube API V1
  ...SIIGO_OPENAI_TOOLS,
  // Herramientas Oficiales de Google Workspace (Gmail, Drive, Calendar, Sheets, Docs)
  ...GOOGLE_WORKSPACE_OPENAI_TOOLS,
];

export async function executeAntigravityToolCall(
  name: string,
  args: Record<string, any>,
): Promise<{ resultText: string; files: SharedFileItem[] }> {
  if (name.startsWith('siigo_')) {
    const siigoRes = await executeSiigoToolCall(name, args);
    appendSharedChatMessage({
      role: 'assistant',
      content: siigoRes.resultText,
      source: 'siigo',
    });
    return {
      resultText: siigoRes.resultText,
      files: (siigoRes.files as SharedFileItem[]) || [],
    };
  }

  if (name.startsWith('google_') || name.startsWith('gmail_')) {
    const googleRes = await executeGoogleToolCall(name, args);
    const resultText = typeof googleRes === 'string' ? googleRes : JSON.stringify(googleRes, null, 2);
    appendSharedChatMessage({
      role: 'assistant',
      content: resultText,
      source: 'google',
    });
    return {
      resultText,
      files: [],
    };
  }

  switch (name) {
    case 'antigravity_list_projects': {
      const projects = await listAntigravityProjects();
      const summaryLines = projects.map(
        (p, idx) => `${idx + 1}. **${p.name}** (${p.path})`,
      );
      const summaryText = `📂 **Proyectos detectados en Antigravity (${projects.length})**:\n${summaryLines.join('\n')}`;
      appendSharedChatMessage({
        role: 'assistant',
        content: summaryText,
        source: 'antigravity',
      });
      return {
        resultText: summaryText,
        files: [],
      };
    }

    case 'antigravity_list_chats': {
      const chats = await listAntigravityChats({
        project: args.project,
        query: args.query || args.chatQuery,
        limit: 15,
      });
      const summaryLines = chats.slice(0, 10).map(
        (c, idx) =>
          `${idx + 1}. **${c.title}** — Proyecto: *${c.project}* (ID: \`${c.conversationId}\`, ${c.stepCount} pasos)`,
      );
      const summaryText =
        chats.length > 0
          ? `💬 **Conversaciones en Antigravity (${chats.length})**:\n${summaryLines.join('\n')}`
          : `No se encontraron conversaciones en Antigravity para ese filtro.`;
      appendSharedChatMessage({
        role: 'assistant',
        content: summaryText,
        source: 'antigravity',
        project: args.project,
      });
      return {
        resultText: summaryText,
        files: [],
      };
    }

    case 'antigravity_read_chat': {
      let targetConvId = String(args.conversationId || '').trim();
      const uuidRegex = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
      if (!uuidRegex.test(targetConvId)) {
        const candidates = await listAntigravityChats({
          project: args.project || targetConvId || undefined,
          query: args.query || args.chatQuery || undefined,
          limit: 5,
        });
        if (candidates.length > 0) {
          targetConvId = candidates[0].conversationId;
        }
      }
      const chat = await readAntigravityChat(targetConvId);
      const sharedArtifacts: SharedFileItem[] = [];
      for (const artPath of chat.artifacts || []) {
        try {
          const ext = extname(artPath).toLowerCase();
          if (ext === '.md') {
            const mdRaw = readFileSync(artPath, 'utf8');
            if (mdRaw.trim().length > 20) {
              const item = await generateSharedDocument({
                title: `${chat.project || 'Antigravity'}_${basename(artPath, '.md')}`,
                format: 'html',
                content: mdRaw,
                project: chat.project,
                conversationId: chat.conversationId,
              });
              sharedArtifacts.push(item);
            }
          } else if (['.pdf', '.docx', '.xlsx', '.html', '.htm', '.csv', '.png', '.jpg'].includes(ext)) {
            const item = registerSharedFile({
              filePath: artPath,
              title: `${chat.project || 'Antigravity'} · ${basename(artPath)}`,
              project: chat.project,
              conversationId: chat.conversationId,
            });
            sharedArtifacts.push(item);
          }
        } catch {}
      }

      const lastMsgs = (chat.recentMessages || [])
        .slice(-4)
        .map((m) => `• **${m.role === 'user' ? 'Usuario' : 'Antigravity'}**: ${m.text.slice(0, 500)}`)
        .join('\n\n');
      const summaryText = `📖 **Resumen del Chat en Antigravity**: "${chat.title || chat.conversationId}" (Proyecto: **${chat.project || 'General'}**)\n\n${lastMsgs || 'Sin mensajes recientes.'}${
        sharedArtifacts.length > 0
          ? `\n\n📎 **Documentos / Artefactos transmitidos al celular (${sharedArtifacts.length})**:\n` +
            sharedArtifacts.map((f) => `- [${f.fileName}](${f.lanUrl})`).join('\n')
          : ''
      }`;

      appendSharedChatMessage({
        role: 'assistant',
        content: summaryText,
        source: 'antigravity',
        project: chat.project,
        conversationId: chat.conversationId,
        files: sharedArtifacts,
      });

      return {
        resultText: summaryText,
        files: sharedArtifacts,
      };
    }

    case 'open_window':
    case 'antigravity_open_window': {
      const opened = await openAntigravityInMac({
        project: args.project ? String(args.project) : undefined,
        conversationId: args.conversationId ? String(args.conversationId) : undefined,
      });
      appendSharedChatMessage({
        role: 'assistant',
        content: `🖥️ ${opened.message}`,
        source: 'antigravity',
        project: args.project,
      });
      return {
        resultText: opened.message,
        files: [],
      };
    }

    case 'antigravity_run_task': {
      const resolvedFormat = args.outputFormat || args.output_format || args.format || 'none';
      const resolvedTitle = args.outputTitle || args.output_title || args.title;
      const res = await runAntigravityTask({
        prompt: String(args.prompt || ''),
        project: args.project ? String(args.project) : undefined,
        conversationId: (args.conversationId || args.conversation_id)
          ? String(args.conversationId || args.conversation_id)
          : undefined,
        chatQuery: (args.chatQuery || args.chat_query || args.query)
          ? String(args.chatQuery || args.chat_query || args.query)
          : undefined,
        continueLatest: Boolean(args.continueLatest ?? args.continue_latest),
        openInMac: args.openInMac !== false && args.open_in_mac !== false,
        outputFormat: resolvedFormat,
        outputTitle: resolvedTitle ? String(resolvedTitle) : undefined,
      });
      return {
        resultText: res.responseText,
        files: res.generatedFiles,
      };
    }

    case 'antigravity_generate_document': {
      const file = await generateSharedDocument({
        title: String(args.title || 'Documento Antigravity'),
        format: (args.format as any) || 'pdf',
        content: String(args.content || ''),
        project: args.project ? String(args.project) : undefined,
      });
      appendSharedChatMessage({
        role: 'assistant',
        content: `He generado tu archivo **${file.title}** (${file.format.toUpperCase()}):\n\n📎 [${file.fileName}](${file.localUrl})\n🌐 Enlace móvil: [Abrir en celular](${file.lanUrl})`,
        source: 'antigravity',
        project: args.project,
        files: [file],
      });
      return {
        resultText: JSON.stringify(
          {
            ok: true,
            fileName: file.fileName,
            format: file.format,
            filePath: file.filePath,
            localUrl: file.localUrl,
            lanUrl: file.lanUrl,
            instructionForAssistant: `Incluye obligatoriamente en tu respuesta al usuario este enlace Markdown exacto para que pueda abrir o descargar el archivo desde su chat en Mac o celular: [📄 Abrir ${file.fileName}](${file.localUrl}) (y para celular en red local: [📱 Abrir en Celular](${file.lanUrl}))`,
          },
          null,
          2,
        ),
        files: [file],
      };
    }

    case 'wappy_agent_team': {
      const resp = await fetch('http://127.0.0.1:3001/api/gemini-tunnel/agent-team/run', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          goal: args.goal || args.prompt || '',
          agents: args.agents,
          dynamicSubagents: args.dynamicSubagents || args.dynamic_subagents,
          project: args.project,
          openBrowser: args.openBrowser ?? args.open_browser,
          outputFormat: args.outputFormat || args.output_format || 'none',
          outputTitle: args.outputTitle || args.output_title,
        }),
      });
      const data: any = await resp.json();
      const summary = `🤝 **Team de Agentes Wappy Dots (${(data.agentsUsed || []).join(' · ')})**\n\n${data.synthesis || data.spokenSummary || 'Misión completada.'}`;
      return {
        resultText: summary,
        files: [],
      };
    }

    case 'wappy_memory_skills': {
      const action = String(args.action || 'get_memory');
      if (action === 'search_history') {
        const resp = await fetch(
          `http://127.0.0.1:3001/api/gemini-tunnel/history/search?q=${encodeURIComponent(String(args.query || args.content || ''))}`,
        );
        const data: any = await resp.json();
        return { resultText: JSON.stringify(data, null, 2), files: [] };
      }
      if (action === 'save_memory') {
        const resp = await fetch('http://127.0.0.1:3001/api/gemini-tunnel/memory', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            target: args.target || 'memory',
            action: 'add',
            content: args.content || '',
          }),
        });
        const data: any = await resp.json();
        return { resultText: JSON.stringify(data, null, 2), files: [] };
      }
      if (action === 'dream_memory') {
        const resp = await fetch('http://127.0.0.1:3001/api/gemini-tunnel/memory/dream', {
          method: 'POST',
        });
        const data: any = await resp.json();
        return { resultText: JSON.stringify(data, null, 2), files: [] };
      }
      if (action === 'list_skills') {
        const resp = await fetch('http://127.0.0.1:3001/api/gemini-tunnel/skills');
        const data: any = await resp.json();
        return { resultText: JSON.stringify(data, null, 2), files: [] };
      }
      if (action === 'save_skill') {
        const resp = await fetch('http://127.0.0.1:3001/api/gemini-tunnel/skills', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            slug: args.slug || 'nueva-skill',
            title: args.title || 'Nueva Skill',
            description: args.description || '',
            content: args.content || '',
          }),
        });
        const data: any = await resp.json();
        return { resultText: JSON.stringify(data, null, 2), files: [] };
      }
      const resp = await fetch('http://127.0.0.1:3001/api/gemini-tunnel/memory');
      const data: any = await resp.json();
      return { resultText: JSON.stringify(data, null, 2), files: [] };
    }

    case 'wappy_cron_schedule': {
      const action = String(args.action || 'list');
      if (action === 'create') {
        const resp = await fetch('http://127.0.0.1:3001/api/gemini-tunnel/cron', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: args.name || 'Tarea Programada',
            goal: args.goal || '',
            everyMinutes: args.everyMinutes,
            dailyAt: args.dailyAt,
          }),
        });
        const data: any = await resp.json();
        return { resultText: JSON.stringify(data, null, 2), files: [] };
      }
      if (action === 'run_now' && args.id) {
        const resp = await fetch(
          `http://127.0.0.1:3001/api/gemini-tunnel/cron/${encodeURIComponent(String(args.id))}/run`,
          { method: 'POST' },
        );
        const data: any = await resp.json();
        return { resultText: JSON.stringify(data, null, 2), files: [] };
      }
      if (action === 'delete' && args.id) {
        const resp = await fetch(
          `http://127.0.0.1:3001/api/gemini-tunnel/cron/${encodeURIComponent(String(args.id))}`,
          { method: 'DELETE' },
        );
        const data: any = await resp.json();
        return { resultText: JSON.stringify(data, null, 2), files: [] };
      }
      const resp = await fetch('http://127.0.0.1:3001/api/gemini-tunnel/cron');
      const data: any = await resp.json();
      return { resultText: JSON.stringify(data, null, 2), files: [] };
    }

    case 'wappy_external_agent': {
      if (args.action === 'delegate' && args.target) {
        const resp = await fetch('http://127.0.0.1:3001/api/gemini-tunnel/connectors/delegate', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            target: args.target,
            goal: args.goal || '',
          }),
        });
        const data: any = await resp.json();
        return { resultText: JSON.stringify(data, null, 2), files: [] };
      }
      const resp = await fetch('http://127.0.0.1:3001/api/gemini-tunnel/connectors');
      const data: any = await resp.json();
      return { resultText: JSON.stringify(data, null, 2), files: [] };
    }

    default:
      return {
        resultText: JSON.stringify({ error: `Herramienta desconocida: ${name}` }),
        files: [],
      };
  }
}
