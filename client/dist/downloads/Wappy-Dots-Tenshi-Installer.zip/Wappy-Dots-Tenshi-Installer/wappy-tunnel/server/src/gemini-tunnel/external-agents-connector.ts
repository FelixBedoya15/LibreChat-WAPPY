import * as fs from 'fs';
import * as net from 'net';
import * as os from 'os';
import * as path from 'path';

const WAPPY_DIR = path.join(os.homedir(), '.wappy');
const CONNECTORS_CONFIG_PATH = path.join(WAPPY_DIR, 'external-connectors.json');
const NOTCH_SOCKET_PATH = path.join(
  os.homedir(),
  'Library/Application Support/NotchBuddy/nb.sock',
);

export type ExternalAgentId = 'openclaw' | 'hermes' | 'openmausbot';

export interface ExternalConnectorConfig {
  mode: 'standalone' | 'hybrid'; // 'standalone' = Wappy Dots nativo; 'hybrid' = permite delegar si el usuario lo pide
  openclaw: {
    enabled: boolean;
    gatewayUrl: string; // ej. ws://127.0.0.1:18789 o http://127.0.0.1:18789
    token?: string;
    configPath: string;
  };
  hermes: {
    enabled: boolean;
    apiUrl: string; // ej. http://127.0.0.1:8642/v1
    apiKey?: string;
    configPath: string;
  };
  openmausbot: {
    enabled: boolean;
    apiUrl: string; // ej. http://127.0.0.1:4120
    token?: string;
    configPath: string;
  };
}

export interface ExternalConnectorStatus {
  id: ExternalAgentId;
  name: string;
  enabled: boolean;
  installedLocally: boolean;
  reachable: boolean;
  endpoint: string;
  configPath: string;
  details: string;
}

const DEFAULT_CONNECTORS_CONFIG: ExternalConnectorConfig = {
  mode: 'standalone',
  openclaw: {
    enabled: false,
    gatewayUrl: 'http://127.0.0.1:18789',
    configPath: path.join(os.homedir(), '.openclaw/openclaw.json'),
  },
  hermes: {
    enabled: false,
    apiUrl: 'http://127.0.0.1:8642/v1',
    configPath: path.join(os.homedir(), '.hermes/config.yaml'),
  },
  openmausbot: {
    enabled: false,
    apiUrl: 'http://127.0.0.1:4120',
    configPath: path.join(os.homedir(), '.openmausbot/config.json'),
  },
};

function emitNotchExternalEvent(payload: Record<string, any>): Promise<void> {
  return new Promise((resolve) => {
    if (!fs.existsSync(NOTCH_SOCKET_PATH)) {
      resolve();
      return;
    }
    const socket = net.createConnection(NOTCH_SOCKET_PATH);
    const timer = setTimeout(() => {
      try {
        socket.destroy();
      } catch {}
      resolve();
    }, 1000);

    socket.on('connect', () => {
      socket.write(`${JSON.stringify(payload)}\n`, () => {
        clearTimeout(timer);
        try {
          socket.end();
        } catch {}
        resolve();
      });
    });

    socket.on('error', () => {
      clearTimeout(timer);
      resolve();
    });
  });
}

export function getExternalConnectorsConfig(): ExternalConnectorConfig {
  try {
    if (fs.existsSync(CONNECTORS_CONFIG_PATH)) {
      const parsed = JSON.parse(fs.readFileSync(CONNECTORS_CONFIG_PATH, 'utf8'));
      return {
        mode: parsed.mode || DEFAULT_CONNECTORS_CONFIG.mode,
        openclaw: { ...DEFAULT_CONNECTORS_CONFIG.openclaw, ...(parsed.openclaw || {}) },
        hermes: { ...DEFAULT_CONNECTORS_CONFIG.hermes, ...(parsed.hermes || {}) },
        openmausbot: { ...DEFAULT_CONNECTORS_CONFIG.openmausbot, ...(parsed.openmausbot || {}) },
      };
    }
  } catch {}

  // Auto-descubrir tokens locales si existen los archivos de configuración
  const cfg = structuredClone(DEFAULT_CONNECTORS_CONFIG);
  try {
    if (fs.existsSync(cfg.openclaw.configPath)) {
      const raw = JSON.parse(fs.readFileSync(cfg.openclaw.configPath, 'utf8'));
      const token = raw?.gateway?.auth?.token || raw?.auth?.token;
      if (token) cfg.openclaw.token = token;
      const port = raw?.gateway?.port;
      if (port) cfg.openclaw.gatewayUrl = `http://127.0.0.1:${port}`;
    }
  } catch {}

  return cfg;
}

export function saveExternalConnectorsConfig(
  patch: Partial<ExternalConnectorConfig>,
): ExternalConnectorConfig {
  if (!fs.existsSync(WAPPY_DIR)) {
    fs.mkdirSync(WAPPY_DIR, { recursive: true });
  }
  const current = getExternalConnectorsConfig();
  const next: ExternalConnectorConfig = {
    mode: patch.mode ?? current.mode,
    openclaw: { ...current.openclaw, ...(patch.openclaw || {}) },
    hermes: { ...current.hermes, ...(patch.hermes || {}) },
    openmausbot: { ...current.openmausbot, ...(patch.openmausbot || {}) },
  };
  fs.writeFileSync(CONNECTORS_CONFIG_PATH, JSON.stringify(next, null, 2), 'utf8');
  return next;
}

async function probeEndpoint(url: string, headers?: Record<string, string>): Promise<boolean> {
  try {
    const httpUrl = url.replace(/^ws:/i, 'http:').replace(/^wss:/i, 'https:');
    const resp = await fetch(httpUrl, {
      method: 'GET',
      headers,
      signal: AbortSignal.timeout(1800),
    });
    return resp.status < 500;
  } catch {
    return false;
  }
}

export async function getExternalConnectorsStatus(): Promise<{
  mode: 'standalone' | 'hybrid';
  nativeCapabilitiesActive: boolean;
  connectors: ExternalConnectorStatus[];
}> {
  const cfg = getExternalConnectorsConfig();

  const [openclawReachable, hermesReachable, mausReachable] = await Promise.all([
    probeEndpoint(cfg.openclaw.gatewayUrl),
    probeEndpoint(`${cfg.hermes.apiUrl.replace(/\/$/, '')}/models`),
    probeEndpoint(`${cfg.openmausbot.apiUrl.replace(/\/$/, '')}/health`),
  ]);

  const openclawRepoExists =
    fs.existsSync(cfg.openclaw.configPath) ||
    fs.existsSync('/Users/venta/Documents/Somos SST/openclaw');
  const hermesInstalled =
    fs.existsSync(cfg.hermes.configPath) ||
    fs.existsSync(path.join(os.homedir(), '.hermes'));
  const mausInstalled = fs.existsSync(cfg.openmausbot.configPath);

  return {
    mode: cfg.mode,
    nativeCapabilitiesActive: true,
    connectors: [
      {
        id: 'openclaw',
        name: 'OpenClaw Gateway',
        enabled: cfg.openclaw.enabled,
        installedLocally: openclawRepoExists,
        reachable: openclawReachable,
        endpoint: cfg.openclaw.gatewayUrl,
        configPath: cfg.openclaw.configPath,
        details: openclawReachable
          ? 'Gateway OpenClaw activo en local y listo para delegación opcional.'
          : 'Modo autónomo Wappy Dots activo (todas las habilidades de OpenClaw corren nativas en Wappy Dots). Puedes encender el Gateway externo cuando quieras.',
      },
      {
        id: 'hermes',
        name: 'Hermes Agent (Nous Research)',
        enabled: cfg.hermes.enabled,
        installedLocally: hermesInstalled,
        reachable: hermesReachable,
        endpoint: cfg.hermes.apiUrl,
        configPath: cfg.hermes.configPath,
        details: hermesReachable
          ? 'API Server de Hermes detectado en línea.'
          : 'Modo autónomo Wappy Dots activo (Memoria dual USER/MEMORY, FTS5 BM25 y Auto-Skills de Hermes corren nativos en Wappy Dots).',
      },
      {
        id: 'openmausbot',
        name: 'OpenMausBot Companion',
        enabled: cfg.openmausbot.enabled,
        installedLocally: mausInstalled,
        reachable: mausReachable,
        endpoint: cfg.openmausbot.apiUrl,
        configPath: cfg.openmausbot.configPath,
        details: mausReachable
          ? 'Servicio OpenMausBot detectado en línea.'
          : 'Modo autónomo Wappy Dots activo (Políticas de aprobación y triggers corren nativos en Wappy Dots).',
      },
    ],
  };
}

/**
 * Permite delegar explícitamente una tarea a un agente externo (OpenClaw, Hermes u OpenMausBot)
 * si el usuario decide conectarse a ellos, reflejando el progreso en el Notch de Wappy Dots.
 */
export async function delegateToExternalAgent(params: {
  target: ExternalAgentId;
  goal: string;
}): Promise<{
  ok: boolean;
  target: ExternalAgentId;
  usedExternal: boolean;
  output: string;
}> {
  const cfg = getExternalConnectorsConfig();
  const sessionId = `ext_${params.target}_${Date.now().toString(36)}`;

  await emitNotchExternalEvent({
    hook_event_name: 'SessionStart',
    coucou_agent: 'openclaw',
    session_id: sessionId,
    cwd: `Conector · ${params.target.toUpperCase()}`,
  });

  await emitNotchExternalEvent({
    hook_event_name: 'PreToolUse',
    coucou_agent: 'openclaw',
    session_id: sessionId,
    cwd: `Conector · ${params.target.toUpperCase()}`,
    tool_name: 'Task',
    tool_input: { command: `Conectando con ${params.target}: ${params.goal.slice(0, 60)}` },
  });

  try {
    if (params.target === 'hermes') {
      const baseUrl = cfg.hermes.apiUrl.replace(/\/$/, '');
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (cfg.hermes.apiKey) headers.Authorization = `Bearer ${cfg.hermes.apiKey}`;

      const resp = await fetch(`${baseUrl}/chat/completions`, {
        method: 'POST',
        headers,
        signal: AbortSignal.timeout(25000),
        body: JSON.stringify({
          model: 'hermes-agent',
          messages: [{ role: 'user', content: params.goal }],
        }),
      });

      if (resp.ok) {
        const data: any = await resp.json();
        const text =
          data?.choices?.[0]?.message?.content ||
          data?.output ||
          JSON.stringify(data).slice(0, 800);

        await emitNotchExternalEvent({
          hook_event_name: 'Stop',
          coucou_agent: 'openclaw',
          session_id: sessionId,
          cwd: 'Conector · HERMES',
          last_assistant_message: text.slice(0, 100),
        });

        return { ok: true, target: 'hermes', usedExternal: true, output: text };
      }
    }

    if (params.target === 'openclaw') {
      const httpBase = cfg.openclaw.gatewayUrl
        .replace(/^ws:/i, 'http:')
        .replace(/^wss:/i, 'https:')
        .replace(/\/$/, '');
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (cfg.openclaw.token) headers.Authorization = `Bearer ${cfg.openclaw.token}`;

      const resp = await fetch(`${httpBase}/v1/chat/completions`, {
        method: 'POST',
        headers,
        signal: AbortSignal.timeout(25000),
        body: JSON.stringify({
          model: 'openclaw',
          messages: [{ role: 'user', content: params.goal }],
        }),
      });

      if (resp.ok) {
        const data: any = await resp.json();
        const text =
          data?.choices?.[0]?.message?.content ||
          data?.output ||
          JSON.stringify(data).slice(0, 800);

        await emitNotchExternalEvent({
          hook_event_name: 'Stop',
          coucou_agent: 'openclaw',
          session_id: sessionId,
          cwd: 'Conector · OPENCLAW',
          last_assistant_message: text.slice(0, 100),
        });

        return { ok: true, target: 'openclaw', usedExternal: true, output: text };
      }
    }

    if (params.target === 'openmausbot') {
      const baseUrl = cfg.openmausbot.apiUrl.replace(/\/$/, '');
      const headers: Record<string, string> = { 'Content-Type': 'application/json' };
      if (cfg.openmausbot.token) headers.Authorization = `Bearer ${cfg.openmausbot.token}`;

      const resp = await fetch(`${baseUrl}/api/agent/run`, {
        method: 'POST',
        headers,
        signal: AbortSignal.timeout(25000),
        body: JSON.stringify({ prompt: params.goal }),
      });

      if (resp.ok) {
        const data: any = await resp.json();
        const text = data?.reply || data?.output || JSON.stringify(data).slice(0, 800);

        await emitNotchExternalEvent({
          hook_event_name: 'Stop',
          coucou_agent: 'openclaw',
          session_id: sessionId,
          cwd: 'Conector · OPENMAUSBOT',
          last_assistant_message: text.slice(0, 100),
        });

        return { ok: true, target: 'openmausbot', usedExternal: true, output: text };
      }
    }
  } catch {}

  await emitNotchExternalEvent({
    hook_event_name: 'Stop',
    coucou_agent: 'openclaw',
    session_id: sessionId,
    cwd: `Nativo · Wappy Dots`,
    last_assistant_message: `Ejecutando en motor autónomo nativo de Wappy Dots (${params.target} externo apagado)`,
  });

  return {
    ok: false,
    target: params.target,
    usedExternal: false,
    output: `El servidor externo de ${params.target} no está encendido en este momento; Wappy Dots resolverá la misión directamente con su motor autónomo nativo.`,
  };
}
