@echo off
powershell -ExecutionPolicy Bypass -File "%~dp0Instalar-Wappy-Dots-Windows.ps1"
pause
