export { default as TermsAndConditionsModal } from './TermsAndConditionsModal';
