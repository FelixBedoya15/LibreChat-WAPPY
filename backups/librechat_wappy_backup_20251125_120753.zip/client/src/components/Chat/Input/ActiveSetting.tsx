export default function ActiveSetting() {
  return (
    <div className="text-token-text-tertiary space-x-2 overflow-hidden text-ellipsis text-sm font-light">
      Talking to{' '}
      <span className="text-token-text-secondary font-medium">[latest] Tailwind CSS GPT</span>
    </div>
  );
}
