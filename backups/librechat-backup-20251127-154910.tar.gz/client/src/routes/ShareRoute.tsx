import ShareView from '~/components/Share/ShareView';

export default function ShareRoute() {
  return <ShareView />;
}
