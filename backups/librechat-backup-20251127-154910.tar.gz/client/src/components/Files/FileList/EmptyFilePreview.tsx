import React from 'react';

export default function EmptyFilePreview() {
  return (
    <div className="h-full w-full content-center text-center font-bold">
      Select a file to view details.
    </div>
  );
}
