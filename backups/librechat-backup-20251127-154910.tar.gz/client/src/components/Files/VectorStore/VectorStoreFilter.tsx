import React from 'react';

const VectorStoreFilter = () => {
  return <div>VectorStoreFilter</div>;
};

export default VectorStoreFilter;
