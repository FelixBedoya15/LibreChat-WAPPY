import React from 'react';

export default function EmptyVectorStorePreview() {
  return (
    <div className="h-full w-full content-center text-center font-bold">
      Select a vector store to view details.
    </div>
  );
}
