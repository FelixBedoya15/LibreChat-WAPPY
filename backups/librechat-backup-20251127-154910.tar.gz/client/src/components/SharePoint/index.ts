export { default as SharePointPickerDialog } from './SharePointPickerDialog';
