export { default as useHasAccess } from './useHasAccess';
