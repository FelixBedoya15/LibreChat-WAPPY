# Librechat RAG API Helm CHart

> [!WARNING]  
> This Helm-Chart is needed for LibreChat and Deployment information is documented in (the librechat chart)[../librechat/readme.md]