export { default as CloudBrowserVoicesSwitch } from './CloudBrowserVoicesSwitch';
export { default as AutomaticPlaybackSwitch } from './AutomaticPlaybackSwitch';
export { default as TextToSpeechSwitch } from './TextToSpeechSwitch';
export { default as EngineTTSDropdown } from './EngineTTSDropdown';
export { default as CacheTTSSwitch } from './CacheTTSSwitch';
export { default as VoiceDropdown } from './VoiceDropdown';
export { default as PlaybackRate } from './PlaybackRate';
